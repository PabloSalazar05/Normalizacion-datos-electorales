# Mexico Electoral Analytics

Plataforma interactiva de análisis geoespacial de datos electorales de México. Descarga shapefiles del INE, limpia CSVs del PREP, construye una API REST con FastAPI y sirve un mapa choroplético con análisis espacial (Moran's I, LISA, densidad electoral) usando React + MapLibre GL JS.

---

## Tabla de contenidos

1. [Arquitectura](#arquitectura)
2. [Requisitos previos](#requisitos-previos)
3. [Compatibilidad con Windows](#compatibilidad-con-windows)
4. [Instalación](#instalación)
5. [Paso 1 — Descargar shapefiles del INE](#paso-1--descargar-shapefiles-del-ine)
6. [Paso 2 — Obtener los CSVs electorales](#paso-2--obtener-los-csvs-electorales)
7. [Paso 3 — Procesar datos electorales (CSV → SQLite)](#paso-3--procesar-datos-electorales-csv--sqlite)
8. [Paso 4 — Calcular áreas por sección (densidad electoral)](#paso-4--calcular-áreas-por-sección-densidad-electoral)
9. [Paso 5 — Auditar y construir capas geográficas](#paso-5--auditar-y-construir-capas-geográficas)
10. [Paso 6 — Ejecutar la API](#paso-6--ejecutar-la-api)
11. [Paso 7 — Ejecutar el frontend](#paso-7--ejecutar-el-frontend)
12. [Referencia rápida](#referencia-rápida)
13. [Endpoints de la API](#endpoints-de-la-api)
14. [Solución de problemas](#solución-de-problemas)

---

## Arquitectura

```
ine-shapefiles-downloader/
├── ingestion/    # Descarga shapefiles del INE (Selenium + Boto3)
├── analytics/    # Limpieza de CSVs electorales → SQLite (GeoPandas + Shapely)
├── dashboard/    # API FastAPI + scripts de geometría
└── frontend/     # SPA React + MapLibre GL JS (choropleth interactivo)
```

**Flujo de datos completo:**

```
1. Ingestion   — Selenium descarga shapefiles INE           → data/geo/
2. Analytics   — CSVs PREP → limpieza → SQLite              → data/processed/electoral_data.db
3. Area        — Shapefiles PEEPJF → área km² por sección   → data/processed/area_km2/
4. Audit       — Shapefiles → validación → GeoJSONs         → data/processed/layers/
5. FastAPI     — carga GeoJSONs en memoria al arrancar      → /api/layers/*
6. React SPA   — polling /api/layers/status → choropleth MapLibre
```

> Los pasos 1–5 son de preparación de datos y se ejecutan **una sola vez** (o cuando llegan nuevos datos). Los pasos 6–7 son el servidor y el cliente que se ejecutan continuamente.

---

## Requisitos previos

| Herramienta | Versión mínima | Notas |
|-------------|---------------|-------|
| Python | 3.11 – 3.12 | No compatible con 3.13+ todavía |
| [`uv`](https://docs.astral.sh/uv/) | ≥ 0.4 | Gestor de paquetes/entornos Python |
| Node.js | ≥ 18 | Para el frontend React |
| Google Chrome | Cualquier versión reciente | Solo para descargar shapefiles (Selenium) |

**Instalar `uv` (macOS / Linux):**
```bash
curl -LsSf https://astral.sh/uv/install.sh | sh
```

**Instalar `uv` (Windows — PowerShell):**
```powershell
powershell -c "irm https://astral.sh/uv/install.ps1 | iex"
```

---

## Compatibilidad con Windows

El proyecto funciona en **macOS, Linux y Windows**. En Windows hay dos opciones:

### Opción A — WSL2 (recomendada)

Ejecuta todo dentro de Ubuntu en WSL2 y el resto del README aplica sin cambios.

1. Instala WSL2 desde PowerShell (requiere reinicio):
   ```powershell
   wsl --install
   ```
2. Abre la terminal de Ubuntu que se instaló y sigue el README desde el paso de instalación de `uv` en adelante.

> Con WSL2 no hay diferencias de comandos ni de dependencias respecto a macOS/Linux.

### Opción B — Windows nativo

Si prefieres no usar WSL2, necesitas resolver tres diferencias antes de seguir el README:

**1. Instalar GDAL y dependencias geoespaciales**

GeoPandas requiere GDAL, que en Windows no viene incluido. La forma más sencilla es instalarlas con conda antes de ejecutar `uv sync`:

```powershell
# Instalar Miniconda si no lo tienes: https://docs.conda.io/en/latest/miniconda.html
conda install -c conda-forge gdal libspatialindex
```

Alternativamente, descarga los wheels precompilados de GDAL desde [github.com/cgohlke/geospatial-wheels](https://github.com/cgohlke/geospatial-wheels) e instálalos con `pip` antes de `uv sync`.

**2. Reemplazar `python3` por `python`**

Los snippets de verificación del README usan `python3 -c "..."`. En Windows el comando es `python`:

```powershell
# En lugar de:  python3 -c "..."
# Usa:          python -c "..."
```

**3. `grep` / `cat` no existen en PowerShell**

Los comandos de diagnóstico que usan `grep` o `cat` (por ejemplo en la verificación de `audit_report.json`) deben adaptarse:

```powershell
# En lugar de: cat audit_report.json | python3 -m json.tool | grep error
# Usa:
python -c "
import json
r = json.load(open('data/processed/layers/audit_report.json'))
errors = [x for x in r if x.get('error')]
print(f'Errores: {len(errors)}')
"
```

> Todos los demás comandos del README (`uv run`, `npm`, `uvicorn`) funcionan idéntico en PowerShell.

---

## Instalación

```bash
# 1. Clonar el repositorio
git clone https://github.com/HectorCorro/ine-shapefiles-downloader.git
cd ine-shapefiles-downloader

# 2. Instalar todas las dependencias Python del workspace
uv sync

# 3. Instalar dependencias del frontend
cd frontend && npm install && cd ..

# 4. Copiar archivo de variables de entorno
cp .env.example .env
# Las credenciales AWS solo son necesarias si quieres subir datos a S3.
# Para uso local puedes dejar el .env sin modificar.
```

---

## Paso 1 — Descargar shapefiles del INE

Los shapefiles contienen la geometría de las 5 capas geográficas (sección, municipio, distrito federal, distrito local, entidad). Son la base cartográfica de todos los mapas.

> **Requiere:** Google Chrome instalado y conexión a internet.

```bash
# Descargar Marco Geográfico Seccional (PEEPJF) — todos los estados
# Destino: data/geo/shapefiles_peepjf/
uv run python -m ingestion.download_peepjf

# Descargar shapefiles nacionales (fuente alternativa para corrección de geometría)
# Destino: data/geo/productos_ine_nacional/
uv run python -m ingestion.download_nacional

# Re-descargar estados con geometría incorrecta detectada automáticamente
# (Los 21 estados que en PEEPJF traían el shapefile de Baja California)
uv run python -m ingestion.download_missing

# Opción: re-descargar solo estados específicos (IDs del 1 al 32)
uv run python -m ingestion.download_missing --states 9 14 15
```

> **¿Por qué tres scripts?** `download_peepjf` descarga el formato primario; `download_missing` corrige un bug del portal del INE que devuelve el shapefile de Baja California para cualquier estado solicitado. Si ya tienes los shapefiles correctos puedes omitir `download_missing`.

> **Problema con Chrome Driver:** Si el script falla con un error de Selenium:
> ```bash
> uv add webdriver-manager --package ingestion --force
> ```

---

## Paso 2 — Obtener los CSVs electorales

El pipeline de analytics espera los CSVs del PREP/COFIPE en la siguiente estructura dentro del repositorio:

```
data/raw/electoral/
├── 2018/
│   ├── 20180708_2130_CW_presidencia/presidencia.csv
│   ├── 20180708_2130_CW_diputaciones/diputaciones.csv
│   └── 20180708_2130_CW_senadurias/senadurias.csv
├── 2021/
│   └── 20210611_1000_CW_diputaciones/diputaciones.csv
└── 2024/
    ├── 20240603_2005_PREP_PRES/PRES_2024.csv
    ├── 20240603_2005_PREP_DIP_FED/DIP_FED_2024.csv
    └── 20240603_2005_PREP_SEN/SEN_2024.csv
```

**Fuente oficial:** Los CSVs se descargan del portal del INE / PREP:
- [PREP 2024 — INE](https://prep2024.ine.mx/)
- [PREP 2021 — INE](https://prep2021.ine.mx/)
- [PREP 2018 — INE](https://prep2018.ine.mx/)

Coloca los archivos respetando exactamente la estructura de carpetas mostrada arriba. El nombre del archivo (e.g. `PRES_2024.csv`) es el que se usa como `election_name` en toda la plataforma.

---

## Paso 3 — Procesar datos electorales (CSV → SQLite)

Transforma los CSVs crudos en tablas SQLite limpias con votos por sección electoral, porcentajes por partido y participación ciudadana (`PARTICIPACION_PCT = TOTAL_VOTOS_SUM / LISTA_NOMINAL × 100`).

```bash
# Procesar todas las elecciones registradas (recomendado para primera instalación)
uv run python -m analytics.ingest_all

# Omitir elecciones ya presentes en la DB (seguro de re-ejecutar tras falla parcial)
uv run python -m analytics.ingest_all --skip-existing

# Ver qué se procesaría sin escribir nada
uv run python -m analytics.ingest_all --dry-run

# Procesar solo elecciones específicas
uv run python -m analytics.ingest_all --election PRES_2024 --election DIP_FED_2024
```

**Salidas generadas por cada elección procesada:**

Por cada elección se crean **33 tablas** en `data/processed/electoral_data.db`:
- 32 tablas por estado con el patrón `election_{nombre}_{entidad_id:02d}` — por ejemplo `election_pres_2024_09` para Ciudad de México.
- 1 tabla nacional que consolida los 32 estados: `election_{nombre}_all` — por ejemplo `election_pres_2024_all`.

Además se exporta un CSV nacional en:
```
data/processed/electoral/
├── pres_2024_all.csv
├── dip_fed_2024_all.csv
└── …
```

**Verificar que la DB se creó correctamente:**
```bash
python3 -c "
import sqlite3
con = sqlite3.connect('data/processed/electoral_data.db')
tables = con.execute(\"SELECT name FROM sqlite_master WHERE type='table'\").fetchall()
print(f'{len(tables)} tablas creadas:')
for t in sorted(tables): print(' ', t[0])
"
```

**Consultar los datos desde cualquier script Python:**
```python
import sqlite3, pandas as pd

# Una entidad específica
with sqlite3.connect('data/processed/electoral_data.db') as con:
    df = pd.read_sql('SELECT * FROM election_pres_2024_09', con)  # CDMX

# Todo el país (tabla nacional consolidada)
with sqlite3.connect('data/processed/electoral_data.db') as con:
    df = pd.read_sql('SELECT * FROM election_pres_2024_all', con)

# O directo desde el CSV
df = pd.read_csv('data/processed/electoral/pres_2024_all.csv')
```

---

## Paso 4 — Calcular áreas por sección (densidad electoral)

Genera los archivos Parquet con el área en km² de cada sección electoral. Son necesarios para la función de **densidad electoral** (votos/km²).

```bash
# Ejecutar desde la raíz del repositorio
uv run python analytics/utils/add_area_km2.py
```

Genera un archivo Parquet por estado en `data/processed/area_km2/`:
```
data/processed/area_km2/
├── 01_seccion_area.parquet
├── 02_seccion_area.parquet
…
└── 32_seccion_area.parquet
```

> **Requiere:** Haber completado el Paso 1 (shapefiles PEEPJF en `data/geo/shapefiles_peepjf/`).

---

## Paso 5 — Auditar y construir capas geográficas

Valida la geometría de cada shapefile, repara polígonos inválidos, reprojecta a EPSG:4326, simplifica por tolerancia y genera los GeoJSONs optimizados que la API carga al arrancar.

**Este paso es obligatorio antes de iniciar la API por primera vez**, y debe re-ejecutarse si descargas nuevos shapefiles.

```bash
# Procesar todos los estados × 5 capas (160 archivos en total)
uv run python dashboard/src/dashboard/scripts/audit_geometries.py

# Solo ciertos estados
uv run python dashboard/src/dashboard/scripts/audit_geometries.py --states 9 14 15

# Solo una capa específica
uv run python dashboard/src/dashboard/scripts/audit_geometries.py --layer seccion
```

Genera en `data/processed/layers/`:
```
data/processed/layers/
├── seccion/          01.geojson … 32.geojson
├── municipio/        01.geojson … 32.geojson
├── distrito_federal/ 01.geojson … 32.geojson
├── distrito_local/   01.geojson … 32.geojson
├── entidad/          01.geojson … 32.geojson
└── audit_report.json
```

**Verificar que no hay errores:**
```bash
python3 -c "
import json
r = json.load(open('data/processed/layers/audit_report.json'))
errors = [x for x in r if x.get('error')]
print(f'Total: {len(r)} registros | Errores: {len(errors)}')
if not errors:
    print('OK — todos los estados procesados correctamente.')
else:
    for e in errors: print(' ERROR:', e)
"
```

La salida esperada es `Total: 160 registros | Errores: 0`.

---

## Paso 6 — Ejecutar la API

```bash
cd dashboard
uv run uvicorn dashboard.api.main:app \
  --reload \
  --reload-dir src \
  --reload-dir ../analytics/src \
  --port 8000
```

Al arrancar, la API precarga los 160 GeoJSONs en memoria (~1–2 s). Hasta que termina devuelve `{"ready": false}` en `/api/layers/status`; el frontend espera automáticamente.

| URL | Descripción |
|-----|-------------|
| `http://localhost:8000/health` | Health check — debe devolver `{"status": "ok"}` |
| `http://localhost:8000/api/docs` | Swagger UI interactivo con todos los endpoints |
| `http://localhost:8000/api/layers/status` | Estado de precarga de capas geográficas |
| `http://localhost:8000/` | SPA React (solo disponible tras `npm run build`) |

---

## Paso 7 — Ejecutar el frontend

### Modo desarrollo (recomendado para desarrollo local)

Abre una **segunda terminal** con la API ya corriendo en el puerto 8000:

```bash
cd frontend
npm run dev
# → http://localhost:5173
```

Vite proxea automáticamente las peticiones `/api/*` al puerto 8000, así que no necesitas ninguna configuración adicional.

### Build de producción

Si quieres servir todo desde un solo proceso (FastAPI sirve la SPA compilada en `/`):

```bash
# 1. Compilar el frontend
cd frontend
npm run build
# Genera frontend/dist/

# 2. Iniciar FastAPI (sirve la SPA automáticamente)
cd ../dashboard
uv run uvicorn dashboard.api.main:app --port 8000
# → http://localhost:8000
```

---

## Referencia rápida

Resumen de todos los comandos en el orden correcto para una instalación desde cero:

```bash
# ── Instalación ──────────────────────────────────────────────────────────────
git clone https://github.com/HectorCorro/ine-shapefiles-downloader.git
cd ine-shapefiles-downloader
uv sync
cd frontend && npm install && cd ..

# ── Datos geográficos ────────────────────────────────────────────────────────
uv run python -m ingestion.download_peepjf          # ~30–60 min (Selenium)
uv run python -m ingestion.download_nacional        # ~30–60 min (Selenium)
uv run python -m ingestion.download_missing         # ~15 min (corrección geometría)

# ── Datos electorales ────────────────────────────────────────────────────────
# (colocar los CSVs del PREP en data/raw/electoral/ según la estructura indicada)
uv run python -m analytics.ingest_all               # ~5–10 min

# ── Procesamiento adicional ──────────────────────────────────────────────────
uv run python analytics/utils/add_area_km2.py       # ~2 min (necesario para densidad)
uv run python dashboard/src/dashboard/scripts/audit_geometries.py  # ~3–5 min

# ── Ejecutar ─────────────────────────────────────────────────────────────────
# Terminal 1 — API:
cd dashboard && uv run uvicorn dashboard.api.main:app --reload --reload-dir src --reload-dir ../analytics/src --port 8000

# Terminal 2 — Frontend dev:
cd frontend && npm run dev
# → Abrir http://localhost:5173
```

---

## Endpoints de la API

| Método | Ruta | Descripción |
|--------|------|-------------|
| GET | `/health` | Health check |
| GET | `/api/layers/status` | Estado de precarga `{ready, progress}` |
| GET | `/api/layers/config` | Registro de capas (`layers.config.json`) |
| GET | `/api/layers/{layer}?entidad_id=N` | GeoJSON de capa (estatal o nacional) |
| GET | `/api/layers/{layer}/labels?entidad_id=N` | Centroides para etiquetas |
| GET | `/api/layers/{layer}/precomputed?election_name=&entidad_id=N` | PCT por partido sin geometría (caché) |
| POST | `/api/layers/{layer}/electoral-join` | GeoJSON enriquecido con `{PARTIDO}_PCT` |
| GET | `/api/data/elections` | Lista de elecciones disponibles |
| GET | `/api/data/states` | Estados con datos en la DB |
| GET | `/api/spatial/variables/{election}/{entidad_id}` | Variables disponibles para análisis |
| POST | `/api/spatial/moran` | Índice de Moran's I global |
| POST | `/api/spatial/lisa` | Análisis LISA (Moran's I local) |
| GET | `/api/viz/density-precomputed?election_name=&entidad_id=N` | Densidad normalizada por sección (caché) |
| POST | `/api/viz/density-map` | Mapa de densidad electoral (HTML Folium) |
| POST | `/api/viz/density-export` | Exportar secciones de umbral a `.xlsx` |
| POST | `/api/viz/density-cumulative` | Mapa de concentración acumulada (Folium) |
| POST | `/api/viz/density-cumulative/stats` | Estadísticas de concentración (sin mapa) |
| GET | `/api/docs` | Swagger UI completo |

---

## Elecciones disponibles

| `election_name` | Tipo | Año |
|-----------------|------|-----|
| `PRES_2024` | Presidencial | 2024 |
| `DIP_FED_2024` | Diputados Federales | 2024 |
| `SEN_2024` | Senadores | 2024 |
| `PRES_2018` | Presidencial | 2018 |
| `DIP_FED_2018` | Diputados Federales | 2018 |
| `SEN_2018` | Senadores | 2018 |
| `DIP_FED_2021` | Diputados Federales | 2021 |

---

## Capas geográficas

| Capa | Shapefile | Simplificación | Columna etiqueta |
|------|-----------|----------------|-----------------|
| `seccion` | SECCION.shp | 0.0001° (~11 m) | SECCION |
| `municipio` | MUNICIPIO.shp | 0.001° (~111 m) | NOMBRE |
| `distrito_federal` | DISTRITO_FEDERAL.shp | 0.001° | DISTRITO_F |
| `distrito_local` | DISTRITO_LOCAL.shp | 0.001° | DISTRITO_L |
| `entidad` | ENTIDAD.shp | 0.005° (~550 m) | NOMBRE |

---

## Variables de entorno

Copia `.env.example` a `.env`. Para uso local sin S3 ninguna variable es obligatoria.

| Variable | Descripción | Requerida |
|----------|-------------|-----------|
| `AWS_REGION` | Región S3 | Solo para subida a S3 |
| `AWS_ACCESS_KEY_ID` | Credencial AWS | Solo para subida a S3 |
| `AWS_SECRET_ACCESS_KEY` | Credencial AWS | Solo para subida a S3 |
| `S3_BUCKET_NAME` | Bucket S3 destino | Solo para subida a S3 |
| `API_BASE_URL` | URL base de la API | Default: `http://localhost:8000` |
| `LOG_LEVEL` | Verbosidad de logs | Default: `INFO` |

---

## Solución de problemas

**`ModuleNotFoundError` al ejecutar cualquier script Python**
```bash
uv sync
```

**La API devuelve 503 en `/api/layers/*`**
Las capas están cargando en background. Espera unos segundos y consulta `/api/layers/status`.

**`data/processed/layers/` vacío o incompleto**
Ejecutar el script de auditoría (Paso 5). Asegúrate de haber completado el Paso 1 primero.

**El tab de Densidad electoral no muestra datos**
El directorio `data/processed/area_km2/` debe estar poblado. Ejecutar el Paso 4:
```bash
uv run python analytics/utils/add_area_km2.py
```

**Error de Chrome Driver (Selenium)**
```bash
uv add webdriver-manager --package ingestion --force
```
O bien instala manualmente ChromeDriver y agrega su directorio al `PATH`.

**macOS — error con GDAL/GeoPandas**
```bash
brew install gdal
uv sync
```

**Linux — bibliotecas espaciales faltantes**
```bash
sudo apt install gdal-bin libgdal-dev libspatialindex-dev
uv sync
```

**Moran's I o LISA falla para ciertos estados**
La geometría del estado puede ser inválida. Re-ejecutar el audit solo para ese estado y revisar el reporte:
```bash
uv run python dashboard/src/dashboard/scripts/audit_geometries.py --states <N>
cat data/processed/layers/audit_report.json | python3 -m json.tool | grep -A5 '"entidad_id": <N>'
```

**El frontend muestra "Selecciona un estado" en el tab Densidad individual**
Este tab requiere que hayas seleccionado un estado en la barra lateral izquierda antes de mostrar el mapa.

---

**Repositorio:** [github.com/HectorCorro/ine-shapefiles-downloader](https://github.com/HectorCorro/ine-shapefiles-downloader)
