"""
download_missing.py
===================

Focused script to (re-)download Shapefile format from INE Nacional for the 21
states that lack valid geometry due to the PEEPJF Baja California bug.

Usage:
    cd ingestion
    uv run python -m ingestion.download_missing
    uv run python -m ingestion.download_missing --states 9 14 15

Output: data/geo/productos_ine_nacional/{N_State}/Shapefile/{NN STATE}/SECCION.shp

Skips states that already have a SECCION.shp with WGS84 centroid lon > -113°.
"""

import argparse
import time
import zipfile
import shutil
from pathlib import Path
from selenium import webdriver
from selenium.webdriver.common.by import By
from selenium.webdriver.support.ui import Select
from selenium.webdriver.chrome.options import Options
from webdriver_manager.chrome import ChromeDriverManager
from selenium.webdriver.chrome.service import Service
from selenium.webdriver.support.ui import WebDriverWait
from selenium.webdriver.support import expected_conditions as EC
from ingestion.utils.s3_utils import upload_folder_to_s3


ENTIDADES = {
    "1": "Aguascalientes",
    "2": "Baja_California",
    "3": "Baja_California_Sur",
    "4": "Campeche",
    "5": "Coahuila",
    "6": "Colima",
    "7": "Chiapas",
    "8": "Chihuahua",
    "9": "CDMX",
    "10": "Durango",
    "11": "Guanajuato",
    "12": "Guerrero",
    "13": "Hidalgo",
    "14": "Jalisco",
    "15": "Mexico",
    "16": "Michoacan",
    "17": "Morelos",
    "18": "Nayarit",
    "19": "Nuevo_Leon",
    "20": "Oaxaca",
    "21": "Puebla",
    "22": "Queretaro",
    "23": "Quintana_Roo",
    "24": "San_Luis_Potosi",
    "25": "Sinaloa",
    "26": "Sonora",
    "27": "Tabasco",
    "28": "Tamaulipas",
    "29": "Tlaxcala",
    "30": "Veracruz",
    "31": "Yucatan",
    "32": "Zacatecas",
}

# States known to lack valid nacional shapefiles (discovered via geographic validation)
DEFAULT_MISSING_STATES = ["5", "7", "8", "9", "11", "12", "13", "14", "15",
                          "16", "17", "19", "20", "21", "22", "23", "24",
                          "26", "28", "30", "32"]

BASE_URL = "https://cartografia.ine.mx/sige8/productosCartograficos/bases"

PROJECT_ROOT = Path(__file__).resolve().parents[3]
DATA_DIR = PROJECT_ROOT / "data"
GEO_DIR = DATA_DIR / "geo"
DOWNLOAD_DIR = GEO_DIR / "downloads_missing"
PRODUCTOS_DIR = GEO_DIR / "productos_ine_nacional"


def _is_shapefile_valid(carpeta: Path, entidad_id: int) -> bool:
    """Return True if the folder already contains a geographically correct SECCION.shp."""
    try:
        import geopandas as gpd
        shp_files = list(carpeta.rglob("SECCION.shp"))
        if not shp_files:
            return False
        gdf = gpd.read_file(shp_files[0])
        if gdf.crs is None:
            return False
        gdf_wgs = gdf.to_crs("EPSG:4326")
        centroid_lon = float(gdf_wgs.geometry.centroid.x.mean())
        # Baja California is legitimately west of -113; all others should be east
        if entidad_id == 2:
            return True
        return centroid_lon > -113.0
    except Exception:
        return False


def configurar_navegador(download_dir: Path):
    chrome_options = Options()
    chrome_options.add_argument("--headless=new")
    chrome_options.add_argument("--disable-gpu")
    chrome_options.add_argument("--no-sandbox")
    chrome_options.add_argument("--disable-popup-blocking")
    chrome_options.add_argument("--disable-dev-shm-usage")

    chrome_options.add_experimental_option("prefs", {
        "download.default_directory": str(download_dir),
        "download.prompt_for_download": False,
        "download.directory_upgrade": True,
        "safebrowsing.enabled": True,
    })

    service = Service(ChromeDriverManager().install())
    return webdriver.Chrome(service=service, options=chrome_options)


def descomprimir_recursivo(carpeta: Path):
    for archivo_path in carpeta.rglob("*"):
        if not archivo_path.is_file():
            continue
        if archivo_path.suffix.lower() == ".zip":
            try:
                with zipfile.ZipFile(archivo_path, "r") as z:
                    z.extractall(archivo_path.parent)
                archivo_path.unlink()
            except Exception as e:
                print(f"   Error descomprimiendo {archivo_path}: {e}")


def seleccionar_opcion_parcial(sel, texto_parcial: str) -> bool:
    for opt in sel.options:
        if texto_parcial.lower() in opt.text.lower():
            opt.click()
            return True
    return False


def download_state_shapefile(ent_id: str, nombre: str) -> bool:
    """
    Download the Shapefile format for one state using a fresh browser session.
    Returns True on success, False on failure.
    """
    carpeta_destino = PRODUCTOS_DIR / f"{ent_id}_{nombre}" / "Shapefile"

    if carpeta_destino.exists() and _is_shapefile_valid(carpeta_destino, int(ent_id)):
        print(f"⏭️  {ent_id} {nombre}: already valid, skipping.")
        return True

    print(f"\n📥 Downloading {ent_id} - {nombre} (Shapefile)")

    driver = configurar_navegador(DOWNLOAD_DIR)
    try:
        driver.get(BASE_URL)
        time.sleep(2)

        wait = WebDriverWait(driver, 10)

        # select[1] = product type; select[2] = state; select[3] = format.
        # Select product "MGS - MARCO GEOGRÁFICO SECCIONAL (POR ENTIDAD FEDERATIVA)" first
        # so the format dropdown is populated with all options including Shapefile.
        producto_select = wait.until(
            EC.presence_of_element_located((By.XPATH, "(//select)[1]"))
        )
        Select(producto_select).select_by_value("3")
        time.sleep(1)

        # Select the state (second select on the page, 1-indexed XPath = [2])
        selector_entidad = wait.until(
            EC.presence_of_element_located((By.XPATH, "(//select)[2]"))
        )
        Select(selector_entidad).select_by_value(ent_id)
        time.sleep(1)

        # Wait for format dropdown to populate, then select Shapefile
        formato_select = WebDriverWait(driver, 10).until(
            EC.presence_of_element_located((
                By.XPATH,
                "//select[option[normalize-space(text())='Seleccionar formato']]",
            ))
        )
        ok = seleccionar_opcion_parcial(Select(formato_select), "Shapefile")
        if not ok:
            print(f"⛔ 'Shapefile' option not found for state {ent_id}.")
            return False
        time.sleep(1)

        boton = wait.until(
            EC.presence_of_element_located(
                (By.XPATH, "//button[normalize-space(text())='Descargar']")
            )
        )
        driver.execute_script("arguments[0].scrollIntoView(true);", boton)
        driver.execute_script("arguments[0].click();", boton)
        print("  Button clicked, waiting for download…")
        time.sleep(2)

        archivo_descargado = None
        for _ in range(30):
            archivos = list(DOWNLOAD_DIR.glob("*.zip")) + list(DOWNLOAD_DIR.glob("*.7z"))
            if archivos:
                archivo_descargado = max(archivos, key=lambda p: p.stat().st_ctime)
                break
            time.sleep(1)

        if not archivo_descargado:
            print(f"⛔ No download detected for state {ent_id}.")
            return False

    finally:
        driver.quit()

    ext = archivo_descargado.suffix
    nuevo_path = DOWNLOAD_DIR / f"{ent_id}_{nombre}_Shapefile{ext}"
    archivo_descargado.rename(nuevo_path)

    carpeta_destino.mkdir(parents=True, exist_ok=True)
    if ext.lower() == ".zip":
        with zipfile.ZipFile(nuevo_path, "r") as z:
            z.extractall(carpeta_destino)
    else:
        print(f"⚠️  Unexpected extension {ext} for state {ent_id}; skipping extraction.")
        return False

    descomprimir_recursivo(carpeta_destino)
    print(f"✅ Extracted to: {carpeta_destino}")

    try:
        upload_folder_to_s3(
            str(carpeta_destino),
            f"productos_ine_nacional/{ent_id}_{nombre}/Shapefile",
            cleanup=False,
        )
    except Exception as e:
        print(f"⚠️  S3 upload skipped (no credentials or bucket not configured): {e}")
    return True


def main():
    parser = argparse.ArgumentParser(
        description="Download missing nacional Shapefiles for states lacking valid geometry."
    )
    parser.add_argument(
        "--states", nargs="+", metavar="ID",
        help=(
            "State IDs to download (default: 21 known-missing states). "
            "E.g. --states 9 14 15"
        ),
    )
    args = parser.parse_args()

    state_ids = args.states if args.states else DEFAULT_MISSING_STATES

    # Validate provided IDs
    invalid = [s for s in state_ids if s not in ENTIDADES]
    if invalid:
        print(f"⛔ Unknown state IDs: {invalid}. Valid range: 1–32.")
        return

    DOWNLOAD_DIR.mkdir(parents=True, exist_ok=True)
    PRODUCTOS_DIR.mkdir(parents=True, exist_ok=True)

    success, failed = [], []
    for ent_id in state_ids:
        nombre = ENTIDADES[ent_id]
        ok = download_state_shapefile(ent_id, nombre)
        (success if ok else failed).append(f"{ent_id}_{nombre}")

    print(f"\n🎉 Done. {len(success)} succeeded, {len(failed)} failed.")
    if failed:
        print(f"   Failed: {', '.join(failed)}")

    # Clean up temp downloads folder
    try:
        shutil.rmtree(DOWNLOAD_DIR)
    except Exception:
        pass


if __name__ == "__main__":
    main()
