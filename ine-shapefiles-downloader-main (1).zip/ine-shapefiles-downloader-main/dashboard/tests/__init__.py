"""
Tests for Electoral Dashboard
==============================
"""
