"""
Dashboard Configuration
=======================

Central configuration for the electoral dashboard application.
"""

from pathlib import Path
from typing import Dict, List
import os

# Import canonical party colors from theme to avoid duplication
from dashboard.theme import (
    PARTY_MORENA, PARTY_PAN, PARTY_PRI, PARTY_PRD,
    PARTY_PVEM, PARTY_PT, PARTY_MC,
)

# API Configuration
API_BASE_URL = os.getenv("API_BASE_URL", "http://localhost:8000")
API_VERSION = "v1"

# Database Configuration
PROJECT_ROOT = Path(__file__).parents[3]
DEFAULT_DB_PATH = PROJECT_ROOT / "data" / "processed" / "electoral_data.db"

# Shapefile Configuration
SHAPEFILE_BASE_DIR = PROJECT_ROOT / "data" / "geo"

# Cache Configuration
CACHE_TTL_SECONDS = 3600  # 1 hour
MAX_CACHE_SIZE = 100  # Maximum number of cached items

# Political Parties
MAJOR_PARTIES: List[str] = [
    "MORENA",
    "PAN", 
    "PRI",
    "PRD",
    "PVEM",
    "PT",
    "MC"
]

# Election Type Mappings
ELECTION_TYPE_DISPLAY: Dict[str, str] = {
    "PRES": "Presidential",
    "DIP_FED": "Federal Deputies",
    "SEN": "Senators",
    "GOB": "Gubernatorial",
    "DIP_LOC": "Local Deputies"
}

# Color schemes for parties (sourced from theme.py — do not duplicate here)
PARTY_COLORS: Dict[str, str] = {
    "MORENA": PARTY_MORENA,
    "PAN": PARTY_PAN,
    "PRI": PARTY_PRI,
    "PRD": PARTY_PRD,
    "PVEM": PARTY_PVEM,
    "PT": PARTY_PT,
    "MC": PARTY_MC,
}

# Visualization Styles
VISUALIZATION_STYLES: List[str] = ["static", "interactive"]

# Map Configuration
DEFAULT_MAP_CRS = "EPSG:4326"  # WGS84 for web maps
PLOT_CRS = "EPSG:3857"  # Web Mercator for better visualization

# Default States for Comparison
DEFAULT_COMPARISON_STATES: List[int] = [
    1,   # Aguascalientes
    9,   # CDMX
    15,  # Estado de México
    19   # Nuevo León
]

# API Pagination
DEFAULT_PAGE_SIZE = 100
MAX_PAGE_SIZE = 1000

# Logging Configuration
LOG_LEVEL = os.getenv("LOG_LEVEL", "INFO")
LOG_FORMAT = "%(asctime)s - %(name)s - %(levelname)s - %(message)s"

# CORS Configuration (for FastAPI)
CORS_ORIGINS = [
    "http://localhost",
    "http://localhost:8000",
    "http://localhost:5173",  # Vite dev server
]

# Layer Configuration
LAYERS_CONFIG_PATH = Path(__file__).parent / "api" / "layers.config.json"
PROCESSED_LAYERS_DIR = PROJECT_ROOT / "data" / "processed" / "layers"

# All 32 states — audit confirmed valid shapefiles (2026-04-22)
VALID_ENTIDAD_IDS: List[int] = [
    1, 2, 3, 4, 5, 6, 7, 8, 9, 10,
    11, 12, 13, 14, 15, 16, 17, 18, 19, 20,
    21, 22, 23, 24, 25, 26, 27, 28, 29, 30,
    31, 32
]

# Streamlit Configuration
STREAMLIT_PAGE_TITLE = "Electoral Data Dashboard"
STREAMLIT_PAGE_ICON = "📊"
STREAMLIT_LAYOUT = "wide"
STREAMLIT_INITIAL_SIDEBAR_STATE = "expanded"
