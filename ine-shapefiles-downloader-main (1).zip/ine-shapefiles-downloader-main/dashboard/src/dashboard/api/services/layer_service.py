"""
Layer Service
=============

Owns the process-level GeoJSON cache for all pre-built map layers.
Layers are loaded from disk at FastAPI startup in a background task;
never re-processed per request.

Usage:
    from dashboard.api.services.layer_service import get_layer_service, preload_all_layers

    # In FastAPI startup:
    asyncio.create_task(preload_all_layers(VALID_ENTIDAD_IDS))

    # In route handlers:
    svc = get_layer_service()
    if not svc.is_ready():
        raise HTTPException(503, ...)
    geojson = svc.get_layer_geojson("seccion", entidad_id=1)
"""

import asyncio
import json
import logging
from pathlib import Path
from typing import Any, Optional

import pandas as pd

logger = logging.getLogger(__name__)

# ── Module-level state ────────────────────────────────────────────────────────
# Keyed as "{layer_name}:{entidad_id:02d}" or "{layer_name}:national"
_cache: dict[str, dict] = {}
_labels_cache: dict[str, dict] = {}

# Pre-computed electoral aggregations (lazy, cached after first computation).
# Key: "{election_name}:{layer_name}:{entidad_id:02d|national}"
# Value: {composite_feature_key: {PARTY_PCT: float, ...}}
_electoral_precomputed: dict[str, dict[str, dict]] = {}

# Async event set when preload_all_layers() finishes
_ready: asyncio.Event = asyncio.Event()

# Progress tracking for the loading screen
_progress: dict[str, int] = {"processed": 0, "total": 0}

# ── Paths ─────────────────────────────────────────────────────────────────────
_PROJECT_ROOT = Path(__file__).parents[5]
PROCESSED_LAYERS_DIR = _PROJECT_ROOT / "data" / "processed" / "layers"
CONFIG_PATH = Path(__file__).parents[1] / "layers.config.json"


# ── Helpers ───────────────────────────────────────────────────────────────────

def _build_label_geojson(
    geojson: dict[str, Any],
    layer_cfg: dict[str, Any],
) -> dict[str, Any]:
    """
    Compute the centroid of each polygon feature and return a Point
    FeatureCollection. Properties are copied from the original feature
    and enriched with a 'label' key.
    """
    from shapely.geometry import shape

    label_col = layer_cfg["label_column"]
    features: list[dict] = []

    for feat in geojson.get("features", []):
        try:
            geom = shape(feat["geometry"])
            centroid = geom.centroid
            props = dict(feat.get("properties") or {})
            props["label"] = str(props.get(label_col, ""))
            features.append(
                {
                    "type": "Feature",
                    "geometry": {
                        "type": "Point",
                        "coordinates": [centroid.x, centroid.y],
                    },
                    "properties": props,
                }
            )
        except Exception:
            pass

    return {"type": "FeatureCollection", "features": features}


def _get_pct_cols(df: pd.DataFrame) -> list[str]:
    return [c for c in df.columns if c.endswith("_PCT")]


def _get_raw_vote_cols(df: pd.DataFrame) -> list[str]:
    pct_cols = _get_pct_cols(df)
    return [c.replace("_PCT", "") for c in pct_cols if c.replace("_PCT", "") in df.columns]


def _weighted_aggregate(
    df: pd.DataFrame,
    group_col: str,
    votes_col: str = "TOTAL_VOTOS_SUM",
) -> pd.DataFrame:
    """
    Aggregate section-level electoral data by group_col using weighted-mean
    for party percentages.  Mirrors the logic in aggregation_service._weighted_dissolve
    but operates on a plain DataFrame (no geometry needed here).
    """
    if group_col not in df.columns:
        raise ValueError(f"Column '{group_col}' not found in DataFrame")

    raw_cols = _get_raw_vote_cols(df)
    agg: dict[str, str] = {}
    if votes_col in df.columns:
        agg[votes_col] = "sum"
    for col in raw_cols:
        if col in df.columns:
            agg[col] = "sum"

    grouped = df.groupby(group_col, as_index=False).agg(agg)

    if votes_col in grouped.columns:
        safe_total = grouped[votes_col].replace(0, float("nan"))
        for raw_col in raw_cols:
            if raw_col in grouped.columns:
                grouped[f"{raw_col}_PCT"] = (grouped[raw_col] / safe_total * 100).round(4)

    return grouped


# ── Background preloader ──────────────────────────────────────────────────────

def _normalize_feature_props(geojson: dict[str, Any]) -> dict[str, Any]:
    """
    Return a new GeoJSON FeatureCollection where every feature's property
    key is uppercased.  Needed because national shapefiles use lowercase
    column names while PEEPJF shapefiles use uppercase.
    """
    features = []
    for feat in geojson.get("features", []):
        props = feat.get("properties") or {}
        features.append({**feat, "properties": {k.upper(): v for k, v in props.items()}})
    return {**geojson, "features": features}


async def preload_all_layers(valid_entidad_ids: list[int]) -> None:
    """
    Background coroutine called from FastAPI startup_event.

    Reads pre-built GeoJSON files from disk into _cache and _labels_cache.
    Does NOT re-process shapefiles — that is audit_geometries.py's job.
    Sets _ready when complete.
    """
    config = json.loads(CONFIG_PATH.read_text())
    enabled_layers = [k for k, v in config["layers"].items() if v["enabled"]]

    _progress["total"] = len(valid_entidad_ids) * len(enabled_layers)
    _progress["processed"] = 0

    logger.info(
        "Layer preload started: %d states × %d layers = %d total",
        len(valid_entidad_ids), len(enabled_layers), _progress["total"],
    )

    for layer_name in enabled_layers:
        layer_cfg = config["layers"][layer_name]
        national_features: list[dict] = []
        national_label_features: list[dict] = []

        for entidad_id in valid_entidad_ids:
            path = PROCESSED_LAYERS_DIR / layer_name / f"{entidad_id:02d}.geojson"
            if not path.exists():
                logger.warning("Missing pre-built GeoJSON: %s", path)
                _progress["processed"] += 1
                await asyncio.sleep(0)
                continue

            try:
                geojson = _normalize_feature_props(
                    json.loads(path.read_text(encoding="utf-8"))
                )
                _cache[f"{layer_name}:{entidad_id:02d}"] = geojson

                labels = _build_label_geojson(geojson, layer_cfg)
                _labels_cache[f"{layer_name}:{entidad_id:02d}"] = labels

                national_features.extend(geojson.get("features", []))
                national_label_features.extend(labels.get("features", []))

                logger.debug(
                    "Loaded layer=%s entidad_id=%d (%d features)",
                    layer_name, entidad_id, len(geojson.get("features", [])),
                )
            except Exception as exc:
                logger.error(
                    "Failed loading %s: %s", path, exc, exc_info=True
                )

            _progress["processed"] += 1
            await asyncio.sleep(0)  # yield to event loop

        _cache[f"{layer_name}:national"] = {
            "type": "FeatureCollection",
            "features": national_features,
        }
        _labels_cache[f"{layer_name}:national"] = {
            "type": "FeatureCollection",
            "features": national_label_features,
        }
        logger.info(
            "Layer '%s' loaded: %d national features", layer_name, len(national_features)
        )

    _ready.set()
    logger.info(
        "All layers loaded. Cache: %d entries, Labels: %d entries",
        len(_cache), len(_labels_cache),
    )


# ── Service class ─────────────────────────────────────────────────────────────

class LayerService:
    """
    Provides access to the process-level GeoJSON layer cache.
    Instantiated once via get_layer_service(); call preload_all_layers()
    at startup to populate the cache.
    """

    # ── Status ────────────────────────────────────────────────────────────────

    def is_ready(self) -> bool:
        return _ready.is_set()

    def get_progress(self) -> dict[str, int]:
        return dict(_progress)

    # ── Config ────────────────────────────────────────────────────────────────

    def get_layer_config(self) -> dict[str, Any]:
        """Return the layers.config.json content (the extensible layer registry)."""
        return json.loads(CONFIG_PATH.read_text())

    # ── GeoJSON access ────────────────────────────────────────────────────────

    def get_layer_geojson(
        self,
        layer_name: str,
        entidad_id: Optional[int] = None,
    ) -> Optional[dict[str, Any]]:
        """
        Return the pre-built GeoJSON FeatureCollection for a layer.

        If entidad_id is None, returns the national merged collection.
        Returns None if the key is absent (missing or unprocessed state).
        """
        key = (
            f"{layer_name}:{entidad_id:02d}"
            if entidad_id is not None
            else f"{layer_name}:national"
        )
        return _cache.get(key)

    def get_labels_geojson(
        self,
        layer_name: str,
        entidad_id: Optional[int] = None,
    ) -> Optional[dict[str, Any]]:
        """Return centroid-point GeoJSON for label rendering."""
        key = (
            f"{layer_name}:{entidad_id:02d}"
            if entidad_id is not None
            else f"{layer_name}:national"
        )
        return _labels_cache.get(key)

    # ── Electoral join ────────────────────────────────────────────────────────

    def join_electoral_data(
        self,
        layer_name: str,
        election_name: str,
        entidad_ids: Optional[list[int]],
        data_service: Any,
    ) -> dict[str, Any]:
        """
        Merge cached layer GeoJSON with electoral PCT data from SQLite.

        For section-level layers the join is a direct lookup by (ENTIDAD, SECCION).
        For coarser layers (municipio, distrito_*) the section-level DB rows are
        first aggregated by the district column using weighted-mean percentages.

        Args:
            layer_name:   One of the enabled layer names (e.g. "seccion").
            election_name: e.g. "PRES_2024".
            entidad_ids:  State IDs to include; None means all cached states.
            data_service: DataService instance (provides load_election_data).

        Returns:
            GeoJSON FeatureCollection with party PCT properties on each feature,
            plus a "warnings" list for skipped states.
        """
        config = self.get_layer_config()
        layer_cfg = config["layers"].get(layer_name)
        if layer_cfg is None:
            raise ValueError(f"Unknown layer: {layer_name}")

        shp_join_keys: list[str] = layer_cfg["join_keys"]["shapefile"]
        db_join_keys: list[str] = layer_cfg["join_keys"]["db"]
        db_granularity: str = layer_cfg.get("db_granularity", "section")

        # Resolve state list
        if entidad_ids is None:
            entidad_ids = [
                int(k.split(":")[1])
                for k in _cache
                if k.startswith(f"{layer_name}:") and k.split(":")[1] != "national"
            ]

        all_features: list[dict] = []
        warnings: list[str] = []

        for entidad_id in sorted(entidad_ids):
            cache_key = f"{layer_name}:{entidad_id:02d}"
            geojson = _cache.get(cache_key)
            if geojson is None:
                warnings.append(
                    f"No pre-built GeoJSON for layer='{layer_name}' entidad_id={entidad_id}"
                )
                continue

            try:
                df = data_service.load_election_data(
                    election_name=election_name,
                    entidad_id=entidad_id,
                    as_geodataframe=False,
                )
            except Exception as exc:
                warnings.append(
                    f"DB load failed entidad_id={entidad_id}: {exc}"
                )
                continue

            if df is None or (hasattr(df, "empty") and df.empty):
                warnings.append(
                    f"No electoral data for election='{election_name}' entidad_id={entidad_id}"
                )
                continue

            pct_cols = _get_pct_cols(df)

            # For coarser layers, aggregate section-level data by district column
            if db_granularity != "section" and len(db_join_keys) > 1:
                group_col = db_join_keys[1]  # second key is the district column (e.g. MUNICIPIO)

                # The DB stores section-level data only; coarser columns (MUNICIPIO,
                # DISTRITO_F, DISTRITO_L) are NOT persisted by the analytics pipeline.
                # Derive them from the cached seccion GeoJSON, which carries these
                # attributes from the shapefile.
                if group_col not in df.columns:
                    crosswalk = _build_seccion_crosswalk(entidad_id, group_col)
                    if crosswalk:
                        df = df.copy()
                        df[group_col] = [
                            crosswalk.get(
                                (_coerce_key(row["ID_ENTIDAD"]), _coerce_key(row["SECCION"]))
                            )
                            for _, row in df.iterrows()
                        ]
                    else:
                        warnings.append(
                            f"Cannot aggregate to '{group_col}': not in DB and no seccion crosswalk "
                            f"for entidad_id={entidad_id}"
                        )
                        continue

                if group_col in df.columns:
                    try:
                        df = _weighted_aggregate(df, group_col)
                        # groupby drops ID_ENTIDAD — restore it so the lookup key matches
                        df["ID_ENTIDAD"] = entidad_id
                        pct_cols = _get_pct_cols(df)
                    except Exception as exc:
                        warnings.append(
                            f"Aggregation failed entidad_id={entidad_id} group_col={group_col}: {exc}"
                        )
                        continue

            # Build lookup: (db_key_values...) → {pct_col: value}
            lookup: dict[tuple, dict[str, Any]] = {}
            for _, row in df.iterrows():
                key_vals = tuple(
                    _coerce_key(row.get(dbk))
                    for dbk in db_join_keys
                )
                lookup[key_vals] = {col: _safe_float(row.get(col)) for col in pct_cols}

            # Enrich GeoJSON features
            for feat in geojson.get("features", []):
                props = dict(feat.get("properties") or {})
                shp_key_vals = tuple(
                    _coerce_key(props.get(shpk))
                    for shpk in shp_join_keys
                )
                matched = lookup.get(shp_key_vals, {})
                props.update(matched)
                all_features.append({**feat, "properties": props})

        return {
            "type": "FeatureCollection",
            "features": all_features,
            "warnings": warnings,
        }


    def get_or_compute_precomputed(
        self,
        layer_name: str,
        election_name: str,
        entidad_id: Optional[int],
        data_service: Any,
    ) -> dict[str, dict]:
        """
        Return a pre-computed {composite_key → {PARTY_PCT}} lookup for the given
        election + layer + state combination.  Results are cached in
        _electoral_precomputed and reused on subsequent calls (lazy memoisation).

        The composite key format matches the join_keys.shapefile config:
          - entidad:           "9"
          - municipio:         "9_1"
          - distrito_federal:  "9_1"
          - seccion:           "9_1404"
        """
        scope = f"{entidad_id:02d}" if entidad_id is not None else "national"
        cache_key = f"{election_name}:{layer_name}:{scope}"

        if cache_key in _electoral_precomputed:
            return _electoral_precomputed[cache_key]

        from dashboard.config import VALID_ENTIDAD_IDS
        entidad_ids = [entidad_id] if entidad_id is not None else list(VALID_ENTIDAD_IDS)

        try:
            result = self.join_electoral_data(
                layer_name=layer_name,
                election_name=election_name,
                entidad_ids=entidad_ids,
                data_service=data_service,
            )
        except Exception as exc:
            logger.warning("Precomputed join failed %s/%s/%s: %s",
                           election_name, layer_name, scope, exc)
            _electoral_precomputed[cache_key] = {}
            return {}

        config = self.get_layer_config()
        shp_keys: list[str] = config["layers"][layer_name]["join_keys"]["shapefile"]

        lookup: dict[str, dict] = {}
        for feat in result.get("features", []):
            props = feat.get("properties") or {}
            parts: list[str] = []
            for k in shp_keys:
                v = props.get(k)
                try:
                    parts.append(str(int(v)))   # type: ignore[arg-type]
                except (TypeError, ValueError):
                    parts.append(str(v) if v is not None else "")
            key = "_".join(parts)
            pct_data = {k: v for k, v in props.items() if k.endswith("_PCT")}
            if pct_data:
                lookup[key] = pct_data

        _electoral_precomputed[cache_key] = lookup
        logger.info("Precomputed %s/%s/%s → %d features cached",
                    election_name, layer_name, scope, len(lookup))
        return lookup


def _build_seccion_crosswalk(entidad_id: int, group_col: str) -> dict[tuple, Any]:
    """
    Build a {(entidad_int, seccion_int) → group_col_value} mapping from the
    cached seccion GeoJSON for entidad_id.

    Used when the DB data lacks the coarser-grain grouping column (e.g. MUNICIPIO,
    DISTRITO_F, DISTRITO_L) because the analytics pipeline was run without the
    --geometry flag.  The seccion shapefile carries these attributes even though
    the DB rows do not.
    """
    sec_geojson = _cache.get(f"seccion:{entidad_id:02d}")
    if not sec_geojson:
        logger.warning(
            "Seccion cache missing for entidad_id=%d — crosswalk unavailable", entidad_id
        )
        return {}

    crosswalk: dict[tuple, Any] = {}
    for feat in sec_geojson.get("features", []):
        props = feat.get("properties") or {}
        entidad = _coerce_key(props.get("ENTIDAD"))
        seccion = _coerce_key(props.get("SECCION"))
        group_val = _coerce_key(props.get(group_col))
        if entidad is not None and seccion is not None and group_val is not None:
            crosswalk[(entidad, seccion)] = group_val

    logger.debug(
        "Crosswalk built: entidad_id=%d group_col=%s → %d entries",
        entidad_id, group_col, len(crosswalk),
    )
    return crosswalk


def _coerce_key(val: Any) -> Any:
    """Coerce join key values to int where possible for consistent matching."""
    if val is None:
        return None
    try:
        return int(val)
    except (TypeError, ValueError):
        return val


def _safe_float(val: Any) -> Any:
    """Return float if val is numeric, else None."""
    if val is None:
        return None
    try:
        f = float(val)
        return None if (f != f) else round(f, 4)  # NaN check
    except (TypeError, ValueError):
        return None


# ── Singleton factory ─────────────────────────────────────────────────────────

_layer_service_instance: Optional[LayerService] = None


def get_layer_service() -> LayerService:
    global _layer_service_instance
    if _layer_service_instance is None:
        _layer_service_instance = LayerService()
    return _layer_service_instance
