"""
Working Layer Service
=====================

In-memory store + business logic for user-created working layers.

A working layer is a GeoDataFrame snapshot created from one of:
  - Moran's I result  → sections annotated with global Moran's I statistics
  - LISA clusters     → sections annotated with per-feature cluster type (HH/LL/HL/LH/NS)
  - Density analysis  → sections annotated with density_normalized + above_threshold flag

Two or more working layers can be combined via attribute join on (ENTIDAD, SECCION) keys to
produce a Combined layer that can be exported to a formatted Excel file.

All data lives in module-level dicts and does NOT survive API restarts.
"""

from __future__ import annotations

import io
import json
import logging
import uuid
from dataclasses import dataclass, field
from datetime import datetime
from typing import Any, Dict, List, Literal, Optional

import geopandas as gpd
import pandas as pd
from openpyxl.styles import Alignment, Font, PatternFill
from openpyxl.utils import get_column_letter

logger = logging.getLogger(__name__)

WorkingLayerType = Literal["moran", "lisa", "density", "combined", "intersection"]

STATES_BY_ID: Dict[int, str] = {
    1: "Aguascalientes", 2: "Baja California", 3: "Baja California Sur",
    4: "Campeche", 5: "Coahuila", 6: "Colima", 7: "Chiapas", 8: "Chihuahua",
    9: "Ciudad de México", 10: "Durango", 11: "Guanajuato", 12: "Guerrero",
    13: "Hidalgo", 14: "Jalisco", 15: "Estado de México", 16: "Michoacán",
    17: "Morelos", 18: "Nayarit", 19: "Nuevo León", 20: "Oaxaca", 21: "Puebla",
    22: "Querétaro", 23: "Quintana Roo", 24: "San Luis Potosí", 25: "Sinaloa",
    26: "Sonora", 27: "Tabasco", 28: "Tamaulipas", 29: "Tlaxcala", 30: "Veracruz",
    31: "Yucatán", 32: "Zacatecas",
}

# Excel fill colours for LISA cluster types (openpyxl ARGB format, no alpha prefix)
_CLUSTER_EXCEL_FILL: Dict[str, str] = {
    "HH": "FFCC0000",  # red
    "LL": "FF0000CC",  # blue
    "HL": "FFFF8800",  # orange
    "LH": "FF88CCFF",  # light blue
    "NS": "FFEEEEEE",  # light grey
}

# ------------------------------------------------------------------
# Data model
# ------------------------------------------------------------------

@dataclass
class WorkingLayer:
    id: str
    name: str
    type: WorkingLayerType
    election_name: str
    variable: str
    entidad_id: Optional[int]
    granularity: str
    created_at: datetime
    feature_count: int
    features: List[Dict[str, Any]]   # GeoJSON Feature dicts (geometry included)
    metadata: Dict[str, Any]          # type-specific extra info


# Module-level in-memory store  ─ shared across all requests within one process
_working_layers: Dict[str, WorkingLayer] = {}


# ------------------------------------------------------------------
# Helper utilities
# ------------------------------------------------------------------

def _meta(wl: WorkingLayer) -> Dict[str, Any]:
    """Return a JSON-serialisable metadata dict (no geometry payload)."""
    return {
        "id": wl.id,
        "name": wl.name,
        "type": wl.type,
        "election_name": wl.election_name,
        "variable": wl.variable,
        "entidad_id": wl.entidad_id,
        "entidad_name": STATES_BY_ID.get(wl.entidad_id) if wl.entidad_id else None,
        "granularity": wl.granularity,
        "created_at": wl.created_at.isoformat(),
        "feature_count": wl.feature_count,
        "metadata": wl.metadata,
    }


def _gdf_to_features(gdf: gpd.GeoDataFrame) -> List[Dict[str, Any]]:
    """Reproject to WGS84 and extract GeoJSON Feature list."""
    if gdf.crs and gdf.crs.to_epsg() != 4326:
        gdf = gdf.to_crs(epsg=4326)
    fc = json.loads(gdf.to_json())
    return fc.get("features", [])


def _native(v: Any) -> Any:
    """Convert numpy scalar to Python native for JSON serialisation."""
    return v.item() if hasattr(v, "item") else v


# ------------------------------------------------------------------
# Service class
# ------------------------------------------------------------------

class WorkingLayerService:
    """CRUD + business logic for working layers."""

    # ── Read operations ───────────────────────────────────────────

    @staticmethod
    def list_layers() -> List[Dict[str, Any]]:
        return [_meta(wl) for wl in _working_layers.values()]

    @staticmethod
    def get_meta(layer_id: str) -> Optional[Dict[str, Any]]:
        wl = _working_layers.get(layer_id)
        return _meta(wl) if wl else None

    @staticmethod
    def get_geojson(layer_id: str) -> Optional[Dict[str, Any]]:
        wl = _working_layers.get(layer_id)
        if not wl:
            return None
        return {"type": "FeatureCollection", "features": wl.features}

    # ── Mutation operations ───────────────────────────────────────

    @staticmethod
    def delete_layer(layer_id: str) -> bool:
        if layer_id in _working_layers:
            del _working_layers[layer_id]
            return True
        return False

    @staticmethod
    def rename_layer(layer_id: str, name: str) -> Optional[Dict[str, Any]]:
        wl = _working_layers.get(layer_id)
        if not wl:
            return None
        wl.name = name
        return _meta(wl)

    # ── Layer creation ────────────────────────────────────────────

    @staticmethod
    def create_from_moran(
        election_name: str,
        variable: str,
        entidad_id: Optional[int],
        granularity: str,
        analysis_level: str,
        moran_result: Dict[str, Any],
        name: Optional[str],
        data_service: Any,
        aggregation_service: Any,
    ) -> Dict[str, Any]:
        """
        Snapshot a working layer from a Moran's I result.

        Loads the section-level GDF for the analysis scope and stamps the
        global Moran's I statistics (same value on every row) so the layer
        can be cross-joined with LISA / Density layers later.
        """
        # Load sections GDF
        if analysis_level == "national":
            gdf = aggregation_service.load_national_geodataframe(election_name, data_service)
        elif entidad_id:
            gdf = aggregation_service.load_state_geodataframe(
                election_name, entidad_id, data_service
            )
            gdf = aggregation_service.apply_granularity(gdf, granularity, entidad_id)
        else:
            raise ValueError("entidad_id required for non-national Moran's I layer")

        gdf = gdf.copy()
        gdf["moran_i_value"]    = float(moran_result.get("moran_i", 0))
        gdf["moran_p_value"]    = float(moran_result.get("p_value", 1))
        gdf["moran_significant"] = bool(moran_result.get("significant", False))
        gdf["moran_z_score"]    = float(moran_result.get("z_score", 0))

        features = _gdf_to_features(gdf)

        state_name = STATES_BY_ID.get(entidad_id, f"E{entidad_id}") if entidad_id else "Nacional"
        var_short  = variable.replace("_PCT", "")
        layer_name = name or f"Moran_{var_short}_{state_name}"

        wl = WorkingLayer(
            id=str(uuid.uuid4()),
            name=layer_name,
            type="moran",
            election_name=election_name,
            variable=variable,
            entidad_id=entidad_id,
            granularity=granularity,
            created_at=datetime.now(),
            feature_count=len(features),
            features=features,
            metadata={
                "moran_i":       float(moran_result.get("moran_i", 0)),
                "p_value":       float(moran_result.get("p_value", 1)),
                "significant":   bool(moran_result.get("significant", False)),
                "z_score":       float(moran_result.get("z_score", 0)),
                "n_observations": int(moran_result.get("n_observations", 0)),
                "analysis_level": analysis_level,
            },
        )
        _working_layers[wl.id] = wl
        logger.info("Created Moran's I working layer %s (%d features)", wl.id, len(features))
        return _meta(wl)

    @staticmethod
    def create_from_lisa(
        election_name: str,
        variable: str,
        entidad_id: int,
        granularity: str,
        analysis_level: str,
        significance: float,
        name: Optional[str],
        # Pre-computed features sent from frontend (avoids re-running LISA)
        geojson_features: Optional[List[Dict[str, Any]]] = None,
        n_significant: int = 0,
        n_observations: int = 0,
        cluster_counts: Optional[Dict[str, int]] = None,
        # Fallback: services for re-computation if geojson_features not provided
        data_service: Any = None,
        aggregation_service: Any = None,
        spatial_service: Any = None,
    ) -> Dict[str, Any]:
        """
        Snapshot a working layer from a LISA computation.

        If ``geojson_features`` is provided, uses those directly (fast path —
        the client already has the result from a prior LISA computation).
        Otherwise re-runs LISA via the spatial service (slow path).
        """
        if geojson_features is not None:
            # Fast path: use features supplied by the frontend
            raw_features = geojson_features
            lisa_meta: Dict[str, Any] = {
                "n_significant":  n_significant,
                "n_observations": n_observations,
                "cluster_counts": cluster_counts or {},
            }
        else:
            # Slow path: re-run LISA computation
            if data_service is None or aggregation_service is None or spatial_service is None:
                raise ValueError("data_service/aggregation_service/spatial_service required when geojson_features not provided")

            if analysis_level == "municipality":
                gdf = aggregation_service.load_state_geodataframe(
                    election_name, entidad_id, data_service
                )
            else:
                gdf = aggregation_service.load_state_geodataframe(
                    election_name, entidad_id, data_service
                )
            gdf = aggregation_service.apply_granularity(gdf, granularity, entidad_id)

            lisa = spatial_service.compute_lisa(
                gdf=gdf,
                variable=variable,
                significance=significance,
            )
            raw_features = lisa.get("geojson", {}).get("features", [])
            lisa_meta = {
                "n_significant":  int(lisa.get("n_significant", 0)),
                "n_observations": int(lisa.get("n_observations", 0)),
                "cluster_counts": lisa.get("cluster_counts", {}),
            }

        # Normalise cluster_type → lisa_cluster_type for unambiguous column names
        features = []
        for feat in raw_features:
            f = dict(feat)
            props = dict(f.get("properties") or {})
            if "cluster_type" in props:
                props["lisa_cluster_type"] = props.pop("cluster_type")
            f["properties"] = props
            features.append(f)

        state_name = STATES_BY_ID.get(entidad_id, f"E{entidad_id}")
        var_short  = variable.replace("_PCT", "")
        layer_name = name or f"LISA_{var_short}_{state_name}"

        wl = WorkingLayer(
            id=str(uuid.uuid4()),
            name=layer_name,
            type="lisa",
            election_name=election_name,
            variable=variable,
            entidad_id=entidad_id,
            granularity=granularity,
            created_at=datetime.now(),
            feature_count=len(features),
            features=features,
            metadata={
                "significance":   significance,
                "analysis_level": analysis_level,
                **lisa_meta,
            },
        )
        _working_layers[wl.id] = wl
        logger.info("Created LISA working layer %s (%d features)", wl.id, len(features))
        return _meta(wl)

    @staticmethod
    def create_from_density(
        election_name: str,
        entidad_id: int,
        granularity: str,
        threshold_pct: float,
        name: Optional[str],
        data_service: Any,
        aggregation_service: Any,
        municipio_id: Optional[int] = None,
    ) -> Dict[str, Any]:
        """
        Snapshot a working layer from a density analysis.

        Uses DensityService.compute_density() and flags each feature as
        above/below the cumulative-vote-share threshold.
        """
        from dashboard.api.services.density_service import DensityService

        gdf = DensityService.compute_density(
            election_name=election_name,
            analysis_level="state",
            granularity=granularity,
            data_service=data_service,
            aggregation_service=aggregation_service,
            entidad_id=entidad_id,
        )

        # Filter to a single municipality when requested
        if municipio_id is not None and "MUNICIPIO" in gdf.columns:
            gdf = gdf[gdf["MUNICIPIO"] == municipio_id].copy()
            if len(gdf) == 0:
                raise ValueError(
                    f"No sections found for municipio_id={municipio_id} "
                    f"in entidad_id={entidad_id}."
                )

        # Re-normalise density within this scope (municipality or state) so the
        # work layer color scale spans 0–1 rather than reflecting state-wide values.
        if "electoral_density" in gdf.columns:
            gdf["density_normalized"] = DensityService._normalize(gdf["electoral_density"])

        votes_col = "TOTAL_VOTOS_SUM"
        gdf = gdf.sort_values("density_normalized", ascending=False).copy()

        if votes_col in gdf.columns:
            total_votes = gdf[votes_col].sum()
            if total_votes > 0:
                gdf["cumulative_share"] = gdf[votes_col].cumsum() / total_votes * 100
                gdf["above_density_threshold"] = gdf["cumulative_share"] <= threshold_pct
            else:
                gdf["above_density_threshold"] = False
        else:
            # Fallback to density percentile
            cutoff = gdf["density_normalized"].quantile(1 - threshold_pct / 100)
            gdf["above_density_threshold"] = gdf["density_normalized"] >= cutoff

        gdf["above_density_threshold"] = gdf["above_density_threshold"].astype(bool)
        gdf["density_threshold_pct"] = threshold_pct
        features = _gdf_to_features(gdf)

        state_name = STATES_BY_ID.get(entidad_id, f"E{entidad_id}")
        mun_suffix = f"_M{municipio_id}" if municipio_id is not None else ""
        layer_name = name or f"Density_{state_name}{mun_suffix}_{int(threshold_pct)}pct"

        wl = WorkingLayer(
            id=str(uuid.uuid4()),
            name=layer_name,
            type="density",
            election_name=election_name,
            variable="density_normalized",
            entidad_id=entidad_id,
            granularity=granularity,
            created_at=datetime.now(),
            feature_count=len(features),
            features=features,
            metadata={"threshold_pct": threshold_pct},
        )
        _working_layers[wl.id] = wl
        logger.info("Created density working layer %s (%d features)", wl.id, len(features))
        return _meta(wl)

    # ── Combine layers ────────────────────────────────────────────

    @staticmethod
    def combine_layers(layer_ids: List[str], name: Optional[str]) -> Dict[str, Any]:
        """
        Merge two or more working layers into one Combined layer.

        Strategy: attribute join on (ENTIDAD/ID_ENTIDAD, SECCION) keys using
        the first layer's features as the left side.  Columns from each layer
        are disambiguated by appending _{layer_type} suffix.
        """
        layers = [_working_layers[lid] for lid in layer_ids if lid in _working_layers]
        if len(layers) < 2:
            raise ValueError("At least 2 valid working layers are required to combine.")

        # Keys to join on (try SECCION + ENTIDAD variant)
        _JOIN_KEYS = ["ID_ENTIDAD", "ENTIDAD", "SECCION", "MUNICIPIO"]

        def _features_to_df(wl: WorkingLayer) -> pd.DataFrame:
            rows = []
            for feat in wl.features:
                row: Dict[str, Any] = {"__geom__": feat.get("geometry")}
                for k, v in (feat.get("properties") or {}).items():
                    row[k] = _native(v)
                rows.append(row)
            return pd.DataFrame(rows)

        # Build DataFrames; suffix type-specific columns per layer
        def _suffix_df(df: pd.DataFrame, suffix: str, join_keys: List[str]) -> pd.DataFrame:
            rename = {
                c: f"{c}_{suffix}"
                for c in df.columns
                if c not in join_keys and c != "__geom__"
                and not c.endswith(f"_{suffix}")
            }
            return df.rename(columns=rename)

        # Determine which join keys exist across all layers
        first_df  = _features_to_df(layers[0])
        join_keys = [k for k in _JOIN_KEYS if k in first_df.columns]
        if not join_keys:
            join_keys = [c for c in ("SECCION",) if c in first_df.columns]
        if not join_keys:
            raise ValueError("No common join keys (ENTIDAD/SECCION) found in layers.")

        merged = _suffix_df(first_df, layers[0].type, join_keys)

        for wl in layers[1:]:
            right_df = _features_to_df(wl)
            available = [k for k in join_keys if k in right_df.columns]
            if not available:
                logger.warning("Layer %s has no join keys — skipping.", wl.id)
                continue
            right_df = _suffix_df(right_df, wl.type, available)
            right_df = right_df.drop(columns=["__geom__"], errors="ignore")
            # LEFT join: keep all geometry rows from the first layer
            merged = merged.merge(right_df, on=available, how="left")

        # Rebuild GeoJSON features from merged DataFrame
        features: List[Dict[str, Any]] = []
        for _, row in merged.iterrows():
            geom = row.get("__geom__")
            # Skip rows with no valid geometry (shouldn't happen with left join, but guard anyway)
            if geom is None or (isinstance(geom, float) and pd.isna(geom)):
                continue
            props = {
                k: _native(v)
                for k, v in row.items()
                if k != "__geom__" and not (isinstance(v, float) and pd.isna(v))
            }
            features.append({"type": "Feature", "geometry": geom, "properties": props})

        first = layers[0]
        combined_name = name or ("Combinado_" + "+".join(wl.name[:12] for wl in layers[:2]))

        wl_combined = WorkingLayer(
            id=str(uuid.uuid4()),
            name=combined_name,
            type="combined",
            election_name=first.election_name,
            variable=first.variable,
            entidad_id=first.entidad_id,
            granularity=first.granularity,
            created_at=datetime.now(),
            feature_count=len(features),
            features=features,
            metadata={"source_layer_ids": layer_ids, "source_layer_names": [wl.name for wl in layers]},
        )
        _working_layers[wl_combined.id] = wl_combined
        logger.info(
            "Created combined working layer %s (%d features) from %s",
            wl_combined.id, len(features), layer_ids,
        )
        return _meta(wl_combined)

    # ── Excel export ──────────────────────────────────────────────

    @staticmethod
    def export_to_excel(layer_id: str) -> Optional[bytes]:
        """
        Export a working layer to a formatted .xlsx file.

        Columns: estado, municipio, seccion, election, variable,
                 lisa_cluster_type, moran_i_value, moran_significant,
                 density_value, above_density_threshold, significance_level.

        Formatting: frozen header, auto column widths, bold header,
                    conditional cell fill on lisa_cluster_type.
        """
        wl = _working_layers.get(layer_id)
        if not wl:
            return None

        rows = []
        for feat in wl.features:
            props = feat.get("properties") or {}
            entidad_raw = props.get("ID_ENTIDAD") or props.get("ENTIDAD")
            try:
                entidad_int = int(entidad_raw) if entidad_raw is not None else None
            except (ValueError, TypeError):
                entidad_int = None

            rows.append({
                "estado":                  STATES_BY_ID.get(entidad_int, "") if entidad_int else "",
                "municipio":               props.get("MUNICIPIO", ""),
                "seccion":                 props.get("SECCION", ""),
                "election":                wl.election_name,
                "variable":                wl.variable.replace("_PCT", ""),
                "lisa_cluster_type":       props.get("lisa_cluster_type", ""),
                "moran_i_value":           props.get("moran_i_value", ""),
                "moran_significant":       props.get("moran_significant", ""),
                "density_value":           props.get("density_normalized", ""),
                "above_density_threshold": props.get("above_density_threshold", ""),
                "significance_level":      wl.metadata.get("significance", wl.metadata.get("p_value", "")),
            })

        ordered_cols = [
            "estado", "municipio", "seccion", "election", "variable",
            "lisa_cluster_type", "moran_i_value", "moran_significant",
            "density_value", "above_density_threshold", "significance_level",
        ]
        df = pd.DataFrame(rows, columns=ordered_cols)

        buf = io.BytesIO()
        with pd.ExcelWriter(buf, engine="openpyxl") as writer:
            df.to_excel(writer, index=False, sheet_name="Working Layer")
            ws = writer.sheets["Working Layer"]

            # Freeze header
            ws.freeze_panes = "A2"

            # Auto column widths (cap at 40)
            for col_idx, col in enumerate(df.columns, 1):
                col_vals = df[col].astype(str)
                max_len = max(len(str(col)), col_vals.str.len().max() if len(df) > 0 else 0)
                ws.column_dimensions[get_column_letter(col_idx)].width = min(int(max_len) + 2, 40)

            # Bold, centred header row
            header_font = Font(bold=True)
            header_align = Alignment(horizontal="center")
            for cell in ws[1]:
                cell.font = header_font
                cell.alignment = header_align

            # Conditional fill on lisa_cluster_type column
            lisa_col = ordered_cols.index("lisa_cluster_type") + 1  # 1-based
            for row_idx in range(2, len(df) + 2):
                cell = ws.cell(row=row_idx, column=lisa_col)
                cluster = str(cell.value) if cell.value else ""
                fill_color = _CLUSTER_EXCEL_FILL.get(cluster)
                if fill_color:
                    cell.fill = PatternFill(
                        start_color=fill_color,
                        end_color=fill_color,
                        fill_type="solid",
                    )

        buf.seek(0)
        return buf.read()


# ------------------------------------------------------------------
# Intersection helpers (module-level, used by WorkingLayerService)
# ------------------------------------------------------------------

def _features_to_gdf(features: List[Dict[str, Any]]) -> gpd.GeoDataFrame:
    """Convert a list of GeoJSON Feature dicts → GeoDataFrame (EPSG:4326)."""
    fc = {"type": "FeatureCollection", "features": features}
    return gpd.GeoDataFrame.from_features(fc, crs="EPSG:4326")


def _significant_keys(wl: "WorkingLayer") -> set:
    """
    Return the set of 'ENTIDAD_SECCION' string keys for features that are
    considered 'significant' for each layer type:
      - lisa    : cluster_type in HH/LL/HL/LH (not NS / not-significant)
      - density : above_density_threshold == True
      - moran   : moran_significant == True
      - combined: above_density_threshold OR LISA cluster significant
      - intersection: all features (already filtered when created)
    """
    keys: set = set()
    for feat in wl.features:
        props = feat.get("properties") or {}
        entidad = props.get("ID_ENTIDAD") or props.get("ENTIDAD")
        seccion = props.get("SECCION")
        if entidad is None or seccion is None:
            continue
        key = f"{int(entidad)}_{int(seccion)}"

        if wl.type == "lisa":
            cluster = props.get("lisa_cluster_type", "NS")
            if cluster in ("HH", "LL", "HL", "LH"):
                keys.add(key)
        elif wl.type == "density":
            if props.get("above_density_threshold") is True:
                keys.add(key)
        elif wl.type == "moran":
            if props.get("moran_significant") is True:
                keys.add(key)
        else:
            # combined / intersection — include all features
            keys.add(key)
    return keys


# Add intersection methods to WorkingLayerService
class _IntersectionMixin:

    @staticmethod
    def create_from_intersection(
        layer_ids: List[str],
        name: Optional[str] = None,
    ) -> Dict[str, Any]:
        """
        Create a new working layer whose features are the sections that are
        'significant' in ALL of the given layers simultaneously.

        Significance per type:
          lisa      → cluster_type in [HH, LL, HL, LH]
          density   → above_density_threshold == True
          moran     → moran_significant == True
          combined/intersection → all features

        The geometry and first-layer attributes form the base; each subsequent
        layer's non-geometry properties are merged in (suffixed by _{type}).
        """
        layers = [_working_layers[lid] for lid in layer_ids if lid in _working_layers]
        if len(layers) < 2:
            raise ValueError("At least 2 valid working layers are required for intersection.")

        # Find common section keys (sections significant in ALL layers)
        key_sets = [_significant_keys(wl) for wl in layers]
        common_keys: set = key_sets[0]
        for ks in key_sets[1:]:
            common_keys = common_keys & ks

        if not common_keys:
            raise ValueError(
                "No sections found that meet the significance criteria in all selected layers."
            )

        # Build result from first layer's features + attrs from subsequent layers
        attr_lookup: List[Dict[str, Dict[str, Any]]] = []
        for wl in layers[1:]:
            lut: Dict[str, Dict[str, Any]] = {}
            for feat in wl.features:
                props = feat.get("properties") or {}
                entidad = props.get("ID_ENTIDAD") or props.get("ENTIDAD")
                seccion = props.get("SECCION")
                if entidad is None or seccion is None:
                    continue
                k = f"{int(entidad)}_{int(seccion)}"
                lut[k] = {f"{pk}_{wl.type}": pv for pk, pv in props.items()}
            attr_lookup.append(lut)

        features: List[Dict[str, Any]] = []
        for feat in layers[0].features:
            props = feat.get("properties") or {}
            entidad = props.get("ID_ENTIDAD") or props.get("ENTIDAD")
            seccion = props.get("SECCION")
            if entidad is None or seccion is None:
                continue
            key = f"{int(entidad)}_{int(seccion)}"
            if key not in common_keys:
                continue
            merged_props = dict(props)
            for lut in attr_lookup:
                merged_props.update(lut.get(key, {}))
            features.append({**feat, "properties": merged_props})

        layer_names = [wl.name for wl in layers]
        layer_name = name or f"Intersección_{' ∩ '.join(layer_names)}"

        wl = WorkingLayer(
            id=str(uuid.uuid4()),
            name=layer_name,
            type="intersection",
            election_name=layers[0].election_name,
            variable="intersection",
            entidad_id=layers[0].entidad_id,
            granularity=layers[0].granularity,
            created_at=datetime.now(),
            feature_count=len(features),
            features=features,
            metadata={"source_layer_ids": layer_ids, "source_layer_names": layer_names},
        )
        _working_layers[wl.id] = wl
        logger.info(
            "Created intersection working layer %s (%d features) from %s",
            wl.id, len(features), layer_ids,
        )
        return _meta(wl)


# Patch the mixin into WorkingLayerService
WorkingLayerService.create_from_intersection = staticmethod(  # type: ignore[attr-defined]
    _IntersectionMixin.create_from_intersection
)
