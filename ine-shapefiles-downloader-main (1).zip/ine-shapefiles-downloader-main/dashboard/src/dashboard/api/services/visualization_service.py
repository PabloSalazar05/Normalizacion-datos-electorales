"""
Visualization Service
=====================

Service for creating static and interactive visualizations.
"""

import io
import base64
import logging
from typing import Literal, Optional, Tuple, Dict, Any
import geopandas as gpd
import pandas as pd
import matplotlib.pyplot as plt
import matplotlib
matplotlib.use('Agg')  # Non-interactive backend
import plotly.express as px
import plotly.graph_objects as go
from dashboard.config import PARTY_COLORS, PLOT_CRS
from dashboard.theme import get_party_colormap

logger = logging.getLogger(__name__)


class VisualizationService:
    """
    Service for creating visualizations.

    Supports both static (matplotlib) and interactive (plotly/folium) styles.
    """

    # Thresholds for automatic geometry simplification before Folium rendering.
    # Keeps the resulting HTML well under Streamlit's 200 MB message limit.
    _SIMPLIFY_THRESHOLD = 2_000   # features — start simplifying above this
    _SIMPLIFY_TOLERANCE_MEDIUM = 0.005  # degrees (~500 m) for 2k–10k features
    _SIMPLIFY_TOLERANCE_HIGH   = 0.02   # degrees (~2 km)  for >10k features

    @staticmethod
    def _simplify_for_render(gdf: gpd.GeoDataFrame) -> gpd.GeoDataFrame:
        """
        Return a copy of *gdf* with simplified geometries if the feature count
        is large enough to risk exceeding Streamlit's message-size limit.

        No-op when len(gdf) <= _SIMPLIFY_THRESHOLD.
        Simplification is done in WGS84 (degrees) with preserve_topology=True.
        """
        n = len(gdf)
        if n <= VisualizationService._SIMPLIFY_THRESHOLD:
            return gdf
        tolerance = (
            VisualizationService._SIMPLIFY_TOLERANCE_HIGH
            if n > 10_000
            else VisualizationService._SIMPLIFY_TOLERANCE_MEDIUM
        )
        logger.info(
            f"Simplifying {n} features with tolerance={tolerance} before rendering"
        )
        gdf = gdf.copy()
        gdf["geometry"] = gdf.geometry.simplify(tolerance, preserve_topology=True)
        return gdf

    @staticmethod
    def create_spatial_lag_comparison(
        gdf: gpd.GeoDataFrame,
        variable: str,
        lag_variable: str,
        style: Literal["static", "interactive"] = "static",
        title: Optional[str] = None,
        party_cmap=None,
    ) -> str:
        """
        Create side-by-side comparison of original values and spatial lag.

        Args:
            gdf: GeoDataFrame with data and spatial lag
            variable: Original variable column name
            lag_variable: Spatial lag column name
            style: Visualization style ('static' or 'interactive')
            title: Optional title for the plot
            party_cmap: Optional matplotlib colormap derived from party color.
                        When None, falls back to 'Reds'.

        Returns:
            Base64 encoded image (static) or HTML (interactive)
        """
        logger.info(f"Creating spatial lag comparison: {variable} vs {lag_variable}, style={style}")

        if style == "static":
            return VisualizationService._create_static_lag_comparison(
                gdf, variable, lag_variable, title, party_cmap
            )
        else:
            return VisualizationService._create_interactive_lag_comparison(
                gdf, variable, lag_variable, title, party_cmap
            )
    
    @staticmethod
    def _create_static_lag_comparison(
        gdf: gpd.GeoDataFrame,
        variable: str,
        lag_variable: str,
        title: Optional[str] = None,
        party_cmap=None,
    ) -> str:
        """Create static matplotlib comparison."""
        cmap = party_cmap if party_cmap is not None else "Reds"

        fig, axes = plt.subplots(1, 2, figsize=(20, 10))

        # Convert to Web Mercator for better visualization
        gdf_plot = gdf.to_crs(epsg=3857) if gdf.crs and str(gdf.crs) != "EPSG:3857" else gdf

        # Left plot: Original values
        gdf_plot.plot(
            column=variable,
            ax=axes[0],
            cmap=cmap,
            legend=True,
            edgecolor="black",
            linewidth=0.3,
            legend_kwds={"label": variable, "shrink": 0.8},
        )
        axes[0].set_title(f"{variable} (Original Values)", fontsize=14, fontweight="bold", pad=15)
        axes[0].set_axis_off()

        # Right plot: Spatial Lag
        gdf_plot.plot(
            column=lag_variable,
            ax=axes[1],
            cmap=cmap,
            legend=True,
            edgecolor="black",
            linewidth=0.3,
            legend_kwds={"label": lag_variable, "shrink": 0.8},
        )
        axes[1].set_title(f"{lag_variable} (Average of Neighbors)", fontsize=14, fontweight="bold", pad=15)
        axes[1].set_axis_off()

        if title:
            plt.suptitle(title, fontsize=16, fontweight="bold", y=0.98)

        plt.tight_layout()

        buffer = io.BytesIO()
        plt.savefig(buffer, format="png", dpi=150, bbox_inches="tight")
        buffer.seek(0)
        image_base64 = base64.b64encode(buffer.read()).decode()
        plt.close(fig)

        return image_base64
    
    @staticmethod
    def _create_interactive_lag_comparison(
        gdf: gpd.GeoDataFrame,
        variable: str,
        lag_variable: str,
        title: Optional[str] = None,
        party_cmap=None,
    ) -> str:
        """Create interactive Folium map with spatial lag comparison."""
        try:
            # Resolve colormap: use registered name string if available, else fallback
            if party_cmap is not None:
                cmap_arg = party_cmap.name  # registered name string
            else:
                cmap_arg = "Reds"

            gdf_wgs84 = gdf.to_crs(epsg=4326) if gdf.crs and str(gdf.crs) != "EPSG:4326" else gdf.copy()
            gdf_wgs84 = VisualizationService._simplify_for_render(gdf_wgs84)

            # Build tooltip columns based on available data
            tooltip_cols = []
            for col in ["entidad_name", "ID_ENTIDAD", "ENTIDAD", "MUNICIPIO", "SECCION",
                        variable, lag_variable, "TOTAL_VOTOS_SUM", "TOTAL_VOTOS"]:
                if col in gdf_wgs84.columns:
                    tooltip_cols.append(col)

            logger.info(f"Creating interactive map with tooltip columns: {tooltip_cols}")

            m = gdf_wgs84.explore(
                column=lag_variable,
                cmap=cmap_arg,
                legend=True,
                tooltip=tooltip_cols if tooltip_cols else True,
                popup=tooltip_cols if tooltip_cols else True,
                tiles="CartoDB positron",
                style_kwds={"fillOpacity": 0.7},
                legend_kwds={
                    "caption": f"{lag_variable} (Spatial Lag — Average of Neighbors)",
                    "scale": True,
                },
            )

            from io import BytesIO
            buffer = BytesIO()
            m.save(buffer, close_file=False)
            buffer.seek(0)
            html_content = buffer.getvalue().decode()
            logger.info(f"Interactive map HTML generated, length: {len(html_content)}")
            return html_content

        except Exception as e:
            logger.error(f"Error creating interactive map: {e}")
            import traceback
            logger.error(traceback.format_exc())
            raise
    
    @staticmethod
    def create_choropleth_map(
        gdf: gpd.GeoDataFrame,
        variable: str,
        style: Literal["static", "interactive"] = "static",
        title: Optional[str] = None,
        color_scale: str = "Reds",
        party_cmap=None,
    ) -> str:
        """
        Create a choropleth map of a variable.

        Args:
            gdf: GeoDataFrame with data
            variable: Variable to map
            style: Visualization style
            title: Plot title
            color_scale: Color scale name (used when party_cmap is None)
            party_cmap: Optional matplotlib colormap derived from party color.
                        When provided, overrides color_scale.

        Returns:
            Base64 encoded image or HTML
        """
        logger.info(f"Creating choropleth map for {variable}, style={style}")

        if style == "static":
            return VisualizationService._create_static_choropleth(
                gdf, variable, title, color_scale, party_cmap
            )
        else:
            return VisualizationService._create_interactive_choropleth(
                gdf, variable, title, color_scale, party_cmap
            )
    
    @staticmethod
    def _create_static_choropleth(
        gdf: gpd.GeoDataFrame,
        variable: str,
        title: Optional[str] = None,
        color_scale: str = "Reds",
        party_cmap=None,
    ) -> str:
        """Create static matplotlib choropleth."""
        cmap = party_cmap if party_cmap is not None else color_scale

        fig, ax = plt.subplots(1, 1, figsize=(12, 10))

        # Convert to Web Mercator
        gdf_plot = gdf.to_crs(epsg=3857) if gdf.crs and str(gdf.crs) != 'EPSG:3857' else gdf

        gdf_plot.plot(
            column=variable,
            ax=ax,
            cmap=cmap,
            legend=True,
            edgecolor='black',
            linewidth=0.3,
            legend_kwds={'label': variable, 'shrink': 0.8}
        )
        
        if title:
            ax.set_title(title, fontsize=14, fontweight='bold', pad=15)
        
        ax.set_axis_off()
        plt.tight_layout()
        
        # Convert to base64
        buffer = io.BytesIO()
        plt.savefig(buffer, format='png', dpi=150, bbox_inches='tight')
        buffer.seek(0)
        image_base64 = base64.b64encode(buffer.read()).decode()
        plt.close(fig)
        
        return image_base64
    
    @staticmethod
    def _create_interactive_choropleth(
        gdf: gpd.GeoDataFrame,
        variable: str,
        title: Optional[str] = None,
        color_scale: str = "Reds",
        party_cmap=None,
    ) -> str:
        """Create interactive Folium choropleth."""
        cmap_arg = party_cmap.name if party_cmap is not None else color_scale

        gdf_wgs84 = gdf.to_crs(epsg=4326) if gdf.crs and str(gdf.crs) != 'EPSG:4326' else gdf
        gdf_wgs84 = VisualizationService._simplify_for_render(gdf_wgs84)

        tooltip_cols = [c for c in ["entidad_name", "ID_ENTIDAD", "ENTIDAD", "MUNICIPIO", "SECCION", variable]
                        if c in gdf_wgs84.columns]

        m = gdf_wgs84.explore(
            column=variable,
            cmap=cmap_arg,
            legend=True,
            tooltip=tooltip_cols if tooltip_cols else True,
            popup=tooltip_cols if tooltip_cols else True,
            tiles="CartoDB positron",
            style_kwds={"fillOpacity": 0.7},
            legend_kwds={"caption": variable, "scale": True},
        )

        from io import BytesIO
        buffer = BytesIO()
        m.save(buffer, close_file=False)
        buffer.seek(0)
        return buffer.getvalue().decode()

    @staticmethod
    def create_winner_map(
        gdf: gpd.GeoDataFrame,
        title: Optional[str] = None,
    ) -> str:
        """
        Create a categorical winner-takes-all map colored by the winning party.

        The winning party per geometry is determined as argmax of the _PCT columns.
        Each party gets its canonical color from PARTY_COLORS.

        Returns:
            HTML string (Folium interactive map)
        """
        import folium
        from io import BytesIO

        pct_cols = [c for c in gdf.columns if c.endswith("_PCT")]
        if not pct_cols:
            raise ValueError("No _PCT columns found to determine winner")

        gdf = gdf.copy()
        gdf["WINNER"] = gdf[pct_cols].idxmax(axis=1).str.replace("_PCT", "")

        gdf_wgs84 = gdf.to_crs(epsg=4326) if gdf.crs and gdf.crs.to_epsg() != 4326 else gdf
        gdf_wgs84 = VisualizationService._simplify_for_render(gdf_wgs84)

        bounds = gdf_wgs84.total_bounds  # [minx, miny, maxx, maxy]
        center = [(bounds[1] + bounds[3]) / 2, (bounds[0] + bounds[2]) / 2]

        m = folium.Map(location=center, zoom_start=5, tiles="CartoDB positron")

        tooltip_cols = [c for c in ["entidad_name", "MUNICIPIO", "SECCION", "WINNER"]
                        if c in gdf_wgs84.columns]
        # Add top-3 PCT columns to tooltip
        tooltip_cols += pct_cols[:6]
        tooltip_cols = [c for c in tooltip_cols if c in gdf_wgs84.columns]

        def _style(feature):
            party = feature["properties"].get("WINNER", "")
            color = PARTY_COLORS.get(party, "#AAAAAA")
            return {
                "fillColor": color,
                "color": "#33333366",
                "weight": 0.4,
                "fillOpacity": 0.75,
            }

        folium.GeoJson(
            gdf_wgs84.__geo_interface__,
            style_function=_style,
            tooltip=folium.GeoJsonTooltip(fields=tooltip_cols, labels=True)
            if tooltip_cols else None,
        ).add_to(m)

        # Legend
        parties_present = sorted(gdf["WINNER"].dropna().unique())
        legend_items = "".join(
            f'<div><span style="background:{PARTY_COLORS.get(p,"#AAAAAA")};'
            f'display:inline-block;width:14px;height:14px;margin-right:6px;'
            f'border:1px solid #666;vertical-align:middle"></span>{p}</div>'
            for p in parties_present
        )
        legend_html = (
            '<div style="position:fixed;bottom:30px;right:30px;z-index:9999;'
            'background:white;padding:10px 14px;border-radius:6px;'
            'border:1px solid #ccc;font-family:sans-serif;font-size:12px;">'
            f"<b>Partido Ganador</b><br>{legend_items}</div>"
        )
        m.get_root().html.add_child(folium.Element(legend_html))

        if title:
            title_html = (
                '<div style="position:fixed;top:10px;left:50%;transform:translateX(-50%);'
                'z-index:9999;background:white;padding:6px 14px;border-radius:5px;'
                'border:1px solid #ccc;font-family:sans-serif;font-size:13px;font-weight:bold;">'
                f"{title}</div>"
            )
            m.get_root().html.add_child(folium.Element(title_html))

        buf = BytesIO()
        m.save(buf, close_file=False)
        buf.seek(0)
        return buf.getvalue().decode()

    @staticmethod
    def create_bar_chart(
        df: pd.DataFrame,
        x: str,
        y: str,
        style: Literal["static", "interactive"] = "static",
        title: Optional[str] = None,
        color: Optional[str] = None
    ) -> str:
        """
        Create a bar chart.
        
        Args:
            df: DataFrame with data
            x: Column for x-axis
            y: Column for y-axis
            style: Visualization style
            title: Chart title
            color: Column for color encoding (optional)
            
        Returns:
            Base64 encoded image or HTML
        """
        logger.info(f"Creating bar chart: x={x}, y={y}, style={style}")
        
        if style == "static":
            return VisualizationService._create_static_bar(df, x, y, title, color)
        else:
            return VisualizationService._create_interactive_bar(df, x, y, title, color)
    
    @staticmethod
    def _create_static_bar(
        df: pd.DataFrame,
        x: str,
        y: str,
        title: Optional[str] = None,
        color: Optional[str] = None
    ) -> str:
        """Create static matplotlib bar chart."""
        fig, ax = plt.subplots(figsize=(12, 6))
        
        if color:
            # Group by color column
            for name, group in df.groupby(color):
                ax.bar(group[x], group[y], label=name, alpha=0.8)
            ax.legend()
        else:
            ax.bar(df[x], df[y], alpha=0.8)
        
        ax.set_xlabel(x, fontsize=12)
        ax.set_ylabel(y, fontsize=12)
        
        if title:
            ax.set_title(title, fontsize=14, fontweight='bold', pad=15)
        
        plt.xticks(rotation=45, ha='right')
        plt.tight_layout()
        
        # Convert to base64
        buffer = io.BytesIO()
        plt.savefig(buffer, format='png', dpi=150, bbox_inches='tight')
        buffer.seek(0)
        image_base64 = base64.b64encode(buffer.read()).decode()
        plt.close(fig)
        
        return image_base64
    
    @staticmethod
    def _create_interactive_bar(
        df: pd.DataFrame,
        x: str,
        y: str,
        title: Optional[str] = None,
        color: Optional[str] = None
    ) -> str:
        """Create interactive plotly bar chart."""
        fig = px.bar(
            df,
            x=x,
            y=y,
            color=color,
            title=title,
            height=500
        )
        
        fig.update_layout(
            xaxis_tickangle=-45,
            margin={"r": 0, "t": 50, "l": 0, "b": 100}
        )
        
        return fig.to_html(full_html=False, include_plotlyjs='cdn')
    
    @staticmethod
    def create_line_chart(
        df: pd.DataFrame,
        x: str,
        y: str,
        style: Literal["static", "interactive"] = "static",
        title: Optional[str] = None,
        color: Optional[str] = None
    ) -> str:
        """
        Create a line chart for temporal analysis.
        
        Args:
            df: DataFrame with data
            x: Column for x-axis (usually election or time)
            y: Column for y-axis
            style: Visualization style
            title: Chart title
            color: Column for color encoding (optional)
            
        Returns:
            Base64 encoded image or HTML
        """
        logger.info(f"Creating line chart: x={x}, y={y}, style={style}")
        
        if style == "static":
            return VisualizationService._create_static_line(df, x, y, title, color)
        else:
            return VisualizationService._create_interactive_line(df, x, y, title, color)
    
    @staticmethod
    def _create_static_line(
        df: pd.DataFrame,
        x: str,
        y: str,
        title: Optional[str] = None,
        color: Optional[str] = None
    ) -> str:
        """Create static matplotlib line chart."""
        fig, ax = plt.subplots(figsize=(12, 6))
        
        if color:
            for name, group in df.groupby(color):
                ax.plot(group[x], group[y], marker='o', label=name, linewidth=2)
            ax.legend()
        else:
            ax.plot(df[x], df[y], marker='o', linewidth=2)
        
        ax.set_xlabel(x, fontsize=12)
        ax.set_ylabel(y, fontsize=12)
        ax.grid(True, alpha=0.3)
        
        if title:
            ax.set_title(title, fontsize=14, fontweight='bold', pad=15)
        
        plt.xticks(rotation=45, ha='right')
        plt.tight_layout()
        
        # Convert to base64
        buffer = io.BytesIO()
        plt.savefig(buffer, format='png', dpi=150, bbox_inches='tight')
        buffer.seek(0)
        image_base64 = base64.b64encode(buffer.read()).decode()
        plt.close(fig)
        
        return image_base64
    
    @staticmethod
    def _create_interactive_line(
        df: pd.DataFrame,
        x: str,
        y: str,
        title: Optional[str] = None,
        color: Optional[str] = None
    ) -> str:
        """Create interactive plotly line chart."""
        fig = px.line(
            df,
            x=x,
            y=y,
            color=color,
            markers=True,
            title=title,
            height=500
        )
        
        fig.update_layout(
            xaxis_tickangle=-45,
            margin={"r": 0, "t": 50, "l": 0, "b": 100}
        )
        
        return fig.to_html(full_html=False, include_plotlyjs='cdn')
