"""
Aggregation Service
===================

Service for loading and aggregating electoral GeoDataFrames at multiple
geographic levels:

  national    — all electoral sections from every available state concatenated
                into one GeoDataFrame (finest resolution, full-country view).
  municipality— sections dissolved by MUNICIPIO within a single state.

All aggregations that involve dissolving use weighted means for party percentages:
    party_pct = sum(party_raw_votes) / sum(total_votes) * 100
to avoid the distortion of simple mean when section sizes differ.
"""

import logging
from functools import lru_cache
from typing import Optional, List, Dict
import geopandas as gpd
import pandas as pd

logger = logging.getLogger(__name__)

# Canonical state ID → name mapping (from geometry.py entidad_folders)
ENTIDAD_NAMES: Dict[int, str] = {
    1: "Aguascalientes", 2: "Baja California", 3: "Baja California Sur",
    4: "Campeche", 5: "Coahuila", 6: "Colima", 7: "Chiapas",
    8: "Chihuahua", 9: "Ciudad de México", 10: "Durango",
    11: "Guanajuato", 12: "Guerrero", 13: "Hidalgo", 14: "Jalisco",
    15: "Estado de México", 16: "Michoacán", 17: "Morelos", 18: "Nayarit",
    19: "Nuevo León", 20: "Oaxaca", 21: "Puebla", 22: "Querétaro",
    23: "Quintana Roo", 24: "San Luis Potosí", 25: "Sinaloa",
    26: "Sonora", 27: "Tabasco", 28: "Tamaulipas", 29: "Tlaxcala",
    30: "Veracruz", 31: "Yucatán", 32: "Zacatecas",
}


def _get_party_vote_cols(gdf: gpd.GeoDataFrame) -> List[str]:
    """Return raw-vote column names inferred from the _PCT columns present."""
    pct_cols = [c for c in gdf.columns if c.endswith("_PCT")]
    return [c.replace("_PCT", "") for c in pct_cols
            if c.replace("_PCT", "") in gdf.columns]


def _weighted_dissolve(
    gdf: gpd.GeoDataFrame,
    by: str,
    votes_col: str = "TOTAL_VOTOS_SUM"
) -> gpd.GeoDataFrame:
    """
    Dissolve GeoDataFrame by `by` column, aggregating:
      - votes_col: sum
      - raw party vote columns: sum
      - geometry: union (handled by dissolve)
    Then recompute {PARTY}_PCT columns as
      (sum of raw party votes / sum of total votes) * 100.

    Args:
        gdf: Section-level GeoDataFrame with geometry, vote totals, and party cols.
        by: Column to group by (e.g. 'ENTIDAD' or 'MUNICIPIO').
        votes_col: Column name for total votes per section.

    Returns:
        Dissolved GeoDataFrame with correct weighted-mean party percentages.
    """
    if by not in gdf.columns:
        raise ValueError(f"Column '{by}' not found in GeoDataFrame for dissolve")

    party_raw_cols = _get_party_vote_cols(gdf)
    agg_dict: Dict[str, str] = {}

    if votes_col in gdf.columns:
        agg_dict[votes_col] = "sum"

    for col in party_raw_cols:
        if col in gdf.columns:
            agg_dict[col] = "sum"

    # dissolve performs geometry union automatically
    dissolved = gdf.dissolve(by=by, aggfunc=agg_dict)
    dissolved = dissolved.reset_index()

    # Recompute percentage columns
    total = dissolved[votes_col] if votes_col in dissolved.columns else None
    for raw_col in party_raw_cols:
        pct_col = f"{raw_col}_PCT"
        if raw_col in dissolved.columns and total is not None:
            safe_total = total.replace(0, float("nan"))
            dissolved[pct_col] = (dissolved[raw_col] / safe_total * 100).round(4)

    return dissolved


_GRANULARITY_COLUMN = {
    "section": None,               # no dissolve needed
    "distrito_federal": "DISTRITO_F",
    "municipio": "MUNICIPIO",
}

_GRANULARITY_LABEL = {
    "section": "Secciones electorales",
    "distrito_federal": "Distritos federales",
    "municipio": "Municipios",
}


class AggregationService:
    """
    Loads election data at national or state level, then optionally dissolves
    by granularity (section / distrito_federal / municipio).

    Results are cached at the process level (lru_cache) keyed on
    election_name to avoid reloading 32 shapefiles on every request.
    Call `clear_cache()` after re-ingesting data or restarting the server.
    """

    def __init__(self):
        pass

    # ------------------------------------------------------------------
    # Granularity dissolve helper
    # ------------------------------------------------------------------

    @staticmethod
    def apply_granularity(
        gdf: gpd.GeoDataFrame,
        granularity: str,
        entidad_id: Optional[int] = None,
    ) -> gpd.GeoDataFrame:
        """
        Dissolve a section-level GeoDataFrame to the requested granularity.

        Args:
            gdf: Section-level GeoDataFrame.
            granularity: 'section' | 'distrito_federal' | 'municipio'.
            entidad_id: If provided, used to tag the result with the state ID
                        when dissolving (for label/tooltip use).

        Returns:
            GeoDataFrame at the requested granularity.
        """
        by_col = _GRANULARITY_COLUMN.get(granularity)
        if by_col is None:
            return gdf  # section: no dissolve

        if by_col not in gdf.columns:
            raise ValueError(
                f"Column '{by_col}' not found. "
                f"Granularity '{granularity}' is not available for this dataset."
            )

        dissolved = _weighted_dissolve(gdf, by=by_col)

        # Re-attach state identifier for tooltips
        id_val = entidad_id
        if id_val is None and "ID_ENTIDAD" in gdf.columns:
            id_val = int(gdf["ID_ENTIDAD"].iloc[0])
        if id_val is not None:
            dissolved["ID_ENTIDAD"] = id_val
            dissolved["entidad_name"] = ENTIDAD_NAMES.get(id_val, f"Estado {id_val}")
        elif "entidad_name" in gdf.columns:
            dissolved["entidad_name"] = gdf["entidad_name"].iloc[0]

        return dissolved

    # ------------------------------------------------------------------
    # National (all sections from every available state)
    # ------------------------------------------------------------------

    def load_national_geodataframe(
        self,
        election_name: str,
        data_service,
    ) -> gpd.GeoDataFrame:
        """
        Load all available states and return every electoral section as a
        single GeoDataFrame (no dissolve).

        States that cannot be loaded (missing shapefiles, empty merge) are
        skipped with a warning so partial data is always returned.

        Args:
            election_name: E.g. 'PRES_2024'.
            data_service: DataService instance for DB access.

        Returns:
            GeoDataFrame with one row per section, geometry, TOTAL_VOTOS_SUM,
            ID_ENTIDAD / ENTIDAD, MUNICIPIO, SECCION and {PARTY}_PCT columns.
        """
        return _load_national_cached(election_name, data_service)

    # ------------------------------------------------------------------
    # State (section-level for one state)
    # ------------------------------------------------------------------

    def load_state_geodataframe(
        self,
        election_name: str,
        entidad_id: int,
        data_service,
    ) -> gpd.GeoDataFrame:
        """
        Load section-level data for one state as a GeoDataFrame.

        Args:
            election_name: E.g. 'PRES_2024'.
            entidad_id: State ID (1–32).
            data_service: DataService instance for DB access.

        Returns:
            Section-level GeoDataFrame for the state.
        """
        gdf = data_service.load_election_data(
            election_name=election_name,
            entidad_id=entidad_id,
            as_geodataframe=True,
        )
        if not isinstance(gdf, gpd.GeoDataFrame) or len(gdf) == 0:
            raise ValueError(
                f"Could not load GeoDataFrame for entidad {entidad_id}. "
                "Ensure shapefiles are present and data has been ingested."
            )
        # Tag with state info
        if "ID_ENTIDAD" not in gdf.columns:
            gdf = gdf.copy()
            gdf["ID_ENTIDAD"] = entidad_id
        gdf["entidad_name"] = ENTIDAD_NAMES.get(entidad_id, f"Estado {entidad_id}")
        return gdf

    # ------------------------------------------------------------------
    # Municipality (section-level for one municipality within a state)
    # ------------------------------------------------------------------

    def load_municipality_geodataframe(
        self,
        election_name: str,
        entidad_id: int,
        municipio_id: int,
        data_service,
    ) -> gpd.GeoDataFrame:
        """
        Load section-level data for one municipality within a state.
        Filters the state GeoDataFrame to sections where MUNICIPIO == municipio_id.
        """
        gdf = self.load_state_geodataframe(election_name, entidad_id, data_service)

        muni_col = next((c for c in ["MUNICIPIO", "municipio"] if c in gdf.columns), None)
        if muni_col is None:
            raise ValueError(
                f"MUNICIPIO column not found in state {entidad_id} data. "
                "Ensure shapefiles include the MUNICIPIO attribute."
            )

        filtered = gdf[gdf[muni_col] == municipio_id].copy()
        if len(filtered) == 0:
            raise ValueError(
                f"No sections found for municipio {municipio_id} "
                f"in state {entidad_id}."
            )

        filtered["municipio_id"] = municipio_id
        return filtered

    # ------------------------------------------------------------------
    # Utility
    # ------------------------------------------------------------------

    @staticmethod
    def clear_cache():
        """Clear the process-level national data cache."""
        _load_national_cached.cache_clear()
        logger.info("National GeoDataFrame cache cleared.")


# ------------------------------------------------------------------
# Module-level cached loader (lru_cache requires a free function)
# ------------------------------------------------------------------

@lru_cache(maxsize=16)
def _load_national_cached(election_name: str, data_service) -> gpd.GeoDataFrame:
    """
    Cached national loader. Returns ALL sections from every available state
    concatenated into one GeoDataFrame — no dissolve.

    Loading all 32 states is expensive (~30–90 s cold); this cache ensures
    subsequent requests within the same server process are fast.
    """
    logger.info(
        f"[CACHE MISS] Loading national sections GeoDataFrame for {election_name}"
    )
    frames = []
    for entidad_id in range(1, 33):
        try:
            gdf_state = data_service.load_election_data(
                election_name=election_name,
                entidad_id=entidad_id,
                as_geodataframe=True,
            )
            if isinstance(gdf_state, gpd.GeoDataFrame) and len(gdf_state) > 0:
                # Tag with the correct entidad_id so the national map can use it
                if "ID_ENTIDAD" not in gdf_state.columns:
                    gdf_state = gdf_state.copy()
                    gdf_state["ID_ENTIDAD"] = entidad_id
                frames.append(gdf_state)
                logger.info(
                    f"  entidad {entidad_id}: {len(gdf_state)} sections loaded"
                )
            else:
                logger.warning(
                    f"No GeoDataFrame for entidad {entidad_id} — skipped"
                )
        except Exception as exc:
            logger.warning(
                f"Failed to load entidad {entidad_id}: {exc} — skipped"
            )

    if not frames:
        raise ValueError(
            f"No data found for election '{election_name}'. "
            "Ensure data has been ingested for at least one state."
        )

    # Reproject every state to WGS84 so UTM-zone differences don't block concat
    target_crs = "EPSG:4326"
    frames = [
        f.to_crs(target_crs) if f.crs is not None else f
        for f in frames
    ]

    combined = gpd.GeoDataFrame(
        pd.concat(frames, ignore_index=True), crs=target_crs
    )

    # Add human-readable state name
    id_col = "ID_ENTIDAD" if "ID_ENTIDAD" in combined.columns else "ENTIDAD"
    combined["entidad_name"] = combined[id_col].map(
        lambda eid: ENTIDAD_NAMES.get(int(eid), f"Estado {eid}")
    )

    logger.info(
        f"[CACHE FILL] National GeoDataFrame built: "
        f"{len(combined)} sections across {len(frames)} states"
    )
    return combined
