"""
Pydantic Models for API
========================

Request and response models for API validation.
"""

from .requests import (
    SpatialLagRequest,
    MoranRequest,
    LISARequest,
    CrossStateRequest,
    TemporalRequest,
    VisualizationRequest
)

from .responses import (
    ElectionMetadata,
    StateInfo,
    MoranResult,
    LISAResult,
    SpatialLagResult,
    ComparisonResult,
    HealthCheckResponse
)

__all__ = [
    # Requests
    "SpatialLagRequest",
    "MoranRequest",
    "LISARequest",
    "CrossStateRequest",
    "TemporalRequest",
    "VisualizationRequest",
    # Responses
    "ElectionMetadata",
    "StateInfo",
    "MoranResult",
    "LISAResult",
    "SpatialLagResult",
    "ComparisonResult",
    "HealthCheckResponse"
]
