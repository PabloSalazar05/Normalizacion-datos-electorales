"""
Request Models
==============

Pydantic models for API request validation.
"""

from pydantic import BaseModel, Field, field_validator, model_validator
from typing import List, Literal, Optional

GRANULARITY_TYPE = Literal["section", "distrito_federal", "municipio"]
ANALYSIS_LEVEL_TYPE = Literal["national", "state", "municipality"]


class SpatialLagRequest(BaseModel):
    """Request for computing spatial lag."""

    election_name: str = Field(..., description="Election name (e.g., 'PRES_2024')")
    entidad_id: Optional[int] = Field(
        default=None, ge=1, le=32,
        description="State ID (1-32). Required when analysis_level='state'."
    )
    municipio_id: Optional[int] = Field(
        default=None, ge=1,
        description="Municipality ID. Required when analysis_level='municipality'."
    )
    variable: str = Field(..., description="Variable to analyze (e.g., 'MORENA_PCT')")
    weights_type: Literal["queen", "rook"] = Field(default="queen")
    analysis_level: ANALYSIS_LEVEL_TYPE = Field(default="national")
    granularity: GRANULARITY_TYPE = Field(
        default="section",
        description="Geographic granularity within the analysis level."
    )

    @field_validator("election_name")
    @classmethod
    def validate_election_name(cls, v: str) -> str:
        if not v or not v.strip():
            raise ValueError("Election name cannot be empty")
        return v.strip().upper()

    @field_validator("variable")
    @classmethod
    def validate_variable(cls, v: str) -> str:
        if not v or not v.strip():
            raise ValueError("Variable name cannot be empty")
        return v.strip()

    @model_validator(mode="after")
    def require_entidad_for_state(self):
        if self.analysis_level == "state" and self.entidad_id is None:
            raise ValueError("entidad_id is required when analysis_level='state'")
        if self.analysis_level == "municipality" and (
            self.entidad_id is None or self.municipio_id is None
        ):
            raise ValueError(
                "entidad_id and municipio_id are both required when analysis_level='municipality'"
            )
        return self


class MoranRequest(BaseModel):
    """Request for computing Moran's I statistic."""

    election_name: str = Field(..., description="Election name (e.g., 'PRES_2024')")
    entidad_id: Optional[int] = Field(
        default=None, ge=1, le=32,
        description="State ID (1-32). Required when analysis_level='state'."
    )
    municipio_id: Optional[int] = Field(
        default=None, ge=1,
        description="Municipality ID. Required when analysis_level='municipality'."
    )
    variable: str = Field(..., description="Variable to analyze (e.g., 'MORENA_PCT')")
    weights_type: Literal["queen", "rook"] = Field(default="queen")
    permutations: int = Field(default=999, ge=99, le=9999)
    analysis_level: ANALYSIS_LEVEL_TYPE = Field(default="national")
    granularity: GRANULARITY_TYPE = Field(default="section")

    @field_validator("election_name")
    @classmethod
    def validate_election_name(cls, v: str) -> str:
        return v.strip().upper()

    @field_validator("variable")
    @classmethod
    def validate_variable(cls, v: str) -> str:
        return v.strip()

    @model_validator(mode="after")
    def require_entidad_for_state(self):
        if self.analysis_level == "state" and self.entidad_id is None:
            raise ValueError("entidad_id is required when analysis_level='state'")
        if self.analysis_level == "municipality" and (
            self.entidad_id is None or self.municipio_id is None
        ):
            raise ValueError(
                "entidad_id and municipio_id are both required when analysis_level='municipality'"
            )
        return self


class LISARequest(BaseModel):
    """Request for computing Local Moran's I (LISA) clusters."""

    election_name: str = Field(..., description="Election name (e.g., 'PRES_2024')")
    entidad_id: Optional[int] = Field(
        default=None, ge=1, le=32,
        description="State ID (1-32). Required when analysis_level='state'."
    )
    municipio_id: Optional[int] = Field(
        default=None, ge=1,
        description="Municipality ID. Required when analysis_level='municipality'."
    )
    variable: str = Field(..., description="Variable to analyze (e.g., 'MORENA_PCT')")
    weights_type: Literal["queen", "rook"] = Field(default="queen")
    permutations: int = Field(default=999, ge=99, le=9999)
    significance: float = Field(default=0.05, gt=0, lt=1)
    analysis_level: ANALYSIS_LEVEL_TYPE = Field(default="state")
    granularity: GRANULARITY_TYPE = Field(default="section")

    @field_validator("election_name")
    @classmethod
    def validate_election_name(cls, v: str) -> str:
        return v.strip().upper()

    @field_validator("variable")
    @classmethod
    def validate_variable(cls, v: str) -> str:
        return v.strip()

    @model_validator(mode="after")
    def require_entidad_for_state(self):
        if self.analysis_level == "state" and self.entidad_id is None:
            raise ValueError("entidad_id is required when analysis_level='state'")
        if self.analysis_level == "municipality" and (
            self.entidad_id is None or self.municipio_id is None
        ):
            raise ValueError(
                "entidad_id and municipio_id are both required when analysis_level='municipality'"
            )
        return self


class CrossStateRequest(BaseModel):
    """Request for cross-state comparison."""

    election_name: str = Field(..., description="Election name (e.g., 'PRES_2024')")
    entidad_ids: List[int] = Field(..., min_length=2, max_length=32)
    variables: Optional[List[str]] = Field(default=None)

    @field_validator("entidad_ids")
    @classmethod
    def validate_entidad_ids(cls, v: List[int]) -> List[int]:
        for state_id in v:
            if state_id < 1 or state_id > 32:
                raise ValueError(f"Invalid state ID: {state_id}. Must be between 1 and 32.")
        return list(set(v))

    @field_validator("election_name")
    @classmethod
    def validate_election_name(cls, v: str) -> str:
        return v.strip().upper()


class TemporalRequest(BaseModel):
    """Request for temporal analysis (same state, multiple elections)."""

    entidad_id: int = Field(..., ge=1, le=32)
    election_names: List[str] = Field(..., min_length=2)
    variables: Optional[List[str]] = Field(default=None)

    @field_validator("election_names")
    @classmethod
    def validate_election_names(cls, v: List[str]) -> List[str]:
        if not v or len(v) < 2:
            raise ValueError("At least two elections are required for temporal comparison")
        normalized = [name.strip().upper() for name in v if name.strip()]
        return list(dict.fromkeys(normalized))


class VisualizationRequest(BaseModel):
    """Request for generating visualizations."""

    election_name: str = Field(..., description="Election name")
    entidad_id: Optional[int] = Field(
        default=None, ge=1, le=32,
        description="State ID (1-32). Required when analysis_level='state'."
    )
    variable: str = Field(..., description="Variable to visualize")
    style: Literal["static", "interactive"] = Field(default="interactive")
    chart_type: Optional[Literal["map", "bar", "line", "scatter"]] = Field(default="map")
    include_spatial_lag: bool = Field(default=False)
    analysis_level: ANALYSIS_LEVEL_TYPE = Field(default="national")
    granularity: GRANULARITY_TYPE = Field(default="section")

    @field_validator("election_name")
    @classmethod
    def validate_election_name(cls, v: str) -> str:
        return v.strip().upper()

    @field_validator("variable")
    @classmethod
    def validate_variable(cls, v: str) -> str:
        return v.strip()

    @model_validator(mode="after")
    def require_entidad_for_state(self):
        if self.analysis_level == "state" and self.entidad_id is None:
            raise ValueError("entidad_id is required when analysis_level='state'")
        return self
