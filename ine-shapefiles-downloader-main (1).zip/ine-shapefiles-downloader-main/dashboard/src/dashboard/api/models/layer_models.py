"""
Layer API Models
================

Pydantic request/response models for /api/layers/* endpoints.
"""

from typing import Any, Optional
from pydantic import BaseModel, Field


class LayerStatusResponse(BaseModel):
    ready: bool
    progress: dict[str, int]


class ElectoralJoinRequest(BaseModel):
    election_name: str = Field(..., description="Election name, e.g. 'PRES_2024'")
    entidad_ids: Optional[list[int]] = Field(
        default=None,
        description="State entidad_ids to include. Null = all states in cache.",
    )
    party: Optional[str] = Field(
        default=None,
        description="If set, only this party's PCT column is returned on each feature.",
    )
