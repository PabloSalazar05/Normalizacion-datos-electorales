"""
Layers Router
=============

/api/layers/* endpoints for pre-built GeoJSON layer serving.

All layer endpoints return HTTP 503 + Retry-After: 5 while the background
preload task is still running.  Poll GET /api/layers/status to track progress.
"""

import logging
from typing import Any, Optional

from fastapi import APIRouter, Depends, HTTPException, Query
from fastapi.responses import JSONResponse

from dashboard.api.services.layer_service import (
    LayerService,
    get_layer_service,
    _ready,
)
from dashboard.api.services.data_service import get_data_service, DataService
from dashboard.api.models.layer_models import ElectoralJoinRequest, LayerStatusResponse

logger = logging.getLogger(__name__)

router = APIRouter(prefix="/api/layers", tags=["layers"])


# ── Dependency ────────────────────────────────────────────────────────────────

def _require_ready() -> None:
    """FastAPI dependency — raises 503 if layers haven't finished loading."""
    if not _ready.is_set():
        raise HTTPException(
            status_code=503,
            headers={"Retry-After": "5"},
            detail="Layers are still pre-processing. Retry in a few seconds.",
        )


# ── Endpoints ─────────────────────────────────────────────────────────────────

@router.get("/status", response_model=LayerStatusResponse, summary="Layer preload status")
async def get_layer_status(
    svc: LayerService = Depends(get_layer_service),
) -> dict[str, Any]:
    """
    Returns the current pre-processing status and progress counters.
    Poll this endpoint every 2 seconds until ready=true before showing the map.
    """
    return {
        "ready": svc.is_ready(),
        "progress": svc.get_progress(),
    }


@router.get("/config", summary="Layer registry")
async def get_layer_config(
    svc: LayerService = Depends(get_layer_service),
) -> dict[str, Any]:
    """
    Return the full layer registry from layers.config.json.
    The React app uses this to discover available layers dynamically.
    Adding a new layer only requires updating this file and running
    the audit script.
    """
    return svc.get_layer_config()


@router.get(
    "/{layer_name}/precomputed",
    summary="Pre-computed party PCT aggregations for a layer (lightweight, no geometry)",
    responses={
        200: {"description": "Dict mapping composite feature key → party PCT values"},
        404: {"description": "Unknown layer"},
        503: {"description": "Layers are still pre-processing"},
    },
)
async def get_layer_precomputed(
    layer_name: str,
    election_name: str = Query(..., description="Election name, e.g. PRES_2024"),
    entidad_id: Optional[int] = Query(
        default=None,
        ge=1, le=32,
        description="State entidad_id. Omit for national scope (all states).",
    ),
    _ready_check: None = Depends(_require_ready),
    svc: LayerService = Depends(get_layer_service),
    data_svc: DataService = Depends(get_data_service),
) -> JSONResponse:
    """
    Return a pre-computed {composite_key → {PARTY_PCT}} lookup for the
    given election + layer combination.  Results are memoised server-side
    after the first computation — subsequent calls are instant.

    Composite key format matches the layer join_keys (shapefile side):
    - seccion:          "ENTIDAD_SECCION"   e.g. "9_1404"
    - municipio:        "ENTIDAD_MUNICIPIO" e.g. "9_1"
    - distrito_federal: "ENTIDAD_DISTRITO_F"
    - distrito_local:   "ENTIDAD_DISTRITO_L"
    - entidad:          "ENTIDAD"           e.g. "9"
    """
    config = svc.get_layer_config()
    if layer_name not in config["layers"]:
        raise HTTPException(status_code=404, detail=f"Unknown layer: '{layer_name}'")

    try:
        data = svc.get_or_compute_precomputed(layer_name, election_name, entidad_id, data_svc)
    except Exception as exc:
        logger.error("Precomputed aggregation failed: %s", exc, exc_info=True)
        raise HTTPException(status_code=500, detail="Aggregation failed")

    return JSONResponse(content={
        "election_name": election_name,
        "layer": layer_name,
        "entidad_id": entidad_id,
        "data": data,
    })


@router.get(
    "/{layer_name}",
    summary="Get pre-built GeoJSON for a layer",
    responses={
        200: {"description": "GeoJSON FeatureCollection"},
        404: {"description": "Unknown layer or state has no data"},
        503: {"description": "Layers are still pre-processing"},
    },
)
async def get_layer(
    layer_name: str,
    entidad_id: Optional[int] = Query(
        default=None,
        ge=1, le=32,
        description="State entidad_id. Omit for the national merged collection.",
    ),
    _ready_check: None = Depends(_require_ready),
    svc: LayerService = Depends(get_layer_service),
) -> JSONResponse:
    """
    Return the pre-built GeoJSON FeatureCollection for a layer.

    If entidad_id is omitted, the national merged collection is returned.
    The response is a raw JSONResponse to avoid Pydantic serialisation overhead
    on potentially large GeoJSON payloads.
    """
    config = svc.get_layer_config()
    if layer_name not in config["layers"]:
        raise HTTPException(status_code=404, detail=f"Unknown layer: '{layer_name}'")

    geojson = svc.get_layer_geojson(layer_name, entidad_id)
    if geojson is None:
        detail = (
            f"No data for layer '{layer_name}', entidad_id={entidad_id}"
            if entidad_id is not None
            else f"No national data for layer '{layer_name}'"
        )
        raise HTTPException(status_code=404, detail=detail)

    return JSONResponse(content=geojson)


@router.get(
    "/{layer_name}/labels",
    summary="Get centroid-point GeoJSON for label rendering",
    responses={
        200: {"description": "Point GeoJSON FeatureCollection"},
        404: {"description": "Unknown layer or state has no data"},
        503: {"description": "Layers are still pre-processing"},
    },
)
async def get_layer_labels(
    layer_name: str,
    entidad_id: Optional[int] = Query(
        default=None,
        ge=1, le=32,
        description="State entidad_id. Omit for national labels.",
    ),
    _ready_check: None = Depends(_require_ready),
    svc: LayerService = Depends(get_layer_service),
) -> JSONResponse:
    """
    Return centroid Point GeoJSON for label rendering.
    Each feature has a 'label' property with the human-readable name
    (taken from the layer's label_column).  Labels are zoom-adaptive
    in MapLibre via symbol layer layout expressions.
    """
    config = svc.get_layer_config()
    if layer_name not in config["layers"]:
        raise HTTPException(status_code=404, detail=f"Unknown layer: '{layer_name}'")

    labels = svc.get_labels_geojson(layer_name, entidad_id)
    if labels is None:
        detail = (
            f"No labels for layer '{layer_name}', entidad_id={entidad_id}"
            if entidad_id is not None
            else f"No national labels for layer '{layer_name}'"
        )
        raise HTTPException(status_code=404, detail=detail)

    return JSONResponse(content=labels)


@router.post(
    "/{layer_name}/electoral-join",
    summary="Merge layer geometry with electoral results",
    responses={
        200: {"description": "GeoJSON FeatureCollection with party PCT properties"},
        404: {"description": "Unknown layer"},
        503: {"description": "Layers are still pre-processing"},
    },
)
async def electoral_join(
    layer_name: str,
    request: ElectoralJoinRequest,
    _ready_check: None = Depends(_require_ready),
    svc: LayerService = Depends(get_layer_service),
    data_svc: DataService = Depends(get_data_service),
) -> JSONResponse:
    """
    Join pre-built layer geometry with electoral PCT data from SQLite.

    For the 'seccion' layer the join is a direct lookup by (ENTIDAD, SECCION).
    For coarser layers (municipio, distrito_federal, distrito_local) the
    section-level DB rows are first aggregated by the district column using
    weighted-mean party percentages before joining.

    The response always returns 200 with partial data; states without cached
    geometry or DB data are listed in the 'warnings' array.
    """
    config = svc.get_layer_config()
    if layer_name not in config["layers"]:
        raise HTTPException(status_code=404, detail=f"Unknown layer: '{layer_name}'")

    try:
        result = svc.join_electoral_data(
            layer_name=layer_name,
            election_name=request.election_name,
            entidad_ids=request.entidad_ids,
            data_service=data_svc,
        )
    except ValueError as exc:
        raise HTTPException(status_code=404, detail=str(exc))
    except Exception as exc:
        logger.error("Electoral join failed: %s", exc, exc_info=True)
        raise HTTPException(status_code=500, detail="Electoral join failed")

    # Optionally filter to a single party's PCT column
    if request.party:
        pct_col = f"{request.party.upper()}_PCT"
        for feat in result.get("features", []):
            props = feat.get("properties") or {}
            feat["properties"] = {
                k: v for k, v in props.items()
                if not k.endswith("_PCT") or k == pct_col
            }

    return JSONResponse(content=result)
