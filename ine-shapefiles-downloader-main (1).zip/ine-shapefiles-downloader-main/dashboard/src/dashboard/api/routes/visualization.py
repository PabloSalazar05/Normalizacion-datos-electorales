"""
Visualization Router
====================

API endpoints for generating visualizations.
"""

from fastapi import APIRouter, HTTPException
from fastapi.responses import Response
from pydantic import BaseModel, field_validator
from typing import Optional
import logging
import geopandas as gpd
import pandas as pd

from dashboard.api.models import VisualizationRequest
from dashboard.api.services import DataService, SpatialService, VisualizationService, AggregationService
from dashboard.theme import get_party_colormap

logger = logging.getLogger(__name__)

router = APIRouter(prefix="/api/viz", tags=["visualization"])

# Initialize services
data_service = DataService()
spatial_service = SpatialService()
viz_service = VisualizationService()
aggregation_service = AggregationService()


def _load_gdf_for_viz(
    election_name: str,
    entidad_id,
    analysis_level: str,
    granularity: str = "section",
):
    """Load section-level GeoDataFrame and apply granularity dissolve."""
    if analysis_level == "national":
        gdf = aggregation_service.load_national_geodataframe(election_name, data_service)
    else:  # "state"
        gdf = aggregation_service.load_state_geodataframe(
            election_name, entidad_id, data_service
        )
    return aggregation_service.apply_granularity(gdf, granularity, entidad_id)


def _level_title(analysis_level: str, granularity: str, entidad_id, gdf) -> str:
    """Build a human-readable title."""
    from dashboard.api.services.aggregation_service import _GRANULARITY_LABEL
    gran_label = _GRANULARITY_LABEL.get(granularity, granularity)
    if analysis_level == "national":
        return f"Nacional — {gran_label}"
    if "entidad_name" in gdf.columns:
        name = str(gdf["entidad_name"].iloc[0])
    elif "ENTIDAD" in gdf.columns:
        name = str(gdf["ENTIDAD"].iloc[0])
    else:
        name = f"Estado {entidad_id}"
    return f"{name} — {gran_label}"


@router.post("/spatial-lag-map")
async def create_spatial_lag_map(request: VisualizationRequest):
    """
    Generate side-by-side maps comparing original values and spatial lag.

    Supports analysis_level: 'national' | 'state' | 'municipality'.

    Returns:
        Base64 encoded image (static) or HTML (interactive)
    """
    try:
        logger.info(
            f"Creating spatial lag map: {request.election_name}, "
            f"level={request.analysis_level}, entidad={request.entidad_id}, "
            f"style={request.style}"
        )

        gdf = _load_gdf_for_viz(
            request.election_name, request.entidad_id,
            request.analysis_level, request.granularity,
        )

        logger.info(f"Got data type: {type(gdf)}")

        gdf_lag = spatial_service.compute_spatial_lag(
            gdf=gdf,
            variable=request.variable,
            weights_type="queen",
        )

        lag_variable = f"{request.variable}_lag"
        title = f"{request.election_name} — {_level_title(request.analysis_level, request.granularity, request.entidad_id, gdf)}"

        party_name = request.variable.replace("_PCT", "") if "_PCT" in request.variable else None
        party_cmap = get_party_colormap(party_name) if party_name else None

        content = viz_service.create_spatial_lag_comparison(
            gdf=gdf_lag,
            variable=request.variable,
            lag_variable=lag_variable,
            style=request.style,
            title=title,
            party_cmap=party_cmap,
        )

        if request.style == "static":
            return {"content": content, "content_type": "image/png", "encoding": "base64"}
        else:
            return {"content": content, "content_type": "text/html", "encoding": "utf-8"}

    except ValueError as e:
        raise HTTPException(status_code=400, detail=str(e))
    except Exception as e:
        logger.error(f"Error creating spatial lag map: {e}")
        import traceback
        traceback.print_exc()
        raise HTTPException(status_code=500, detail=str(e))


@router.post("/choropleth")
async def create_choropleth(request: VisualizationRequest):
    """
    Generate a choropleth map for a variable.

    Supports analysis_level: 'national' | 'state' | 'municipality'.

    Returns:
        Base64 encoded image (static) or HTML (interactive)
    """
    try:
        logger.info(
            f"Creating choropleth: {request.election_name}, "
            f"level={request.analysis_level}, entidad={request.entidad_id}, "
            f"var={request.variable}"
        )

        gdf = _load_gdf_for_viz(
            request.election_name, request.entidad_id,
            request.analysis_level, request.granularity,
        )

        logger.info(f"Got data type: {type(gdf)}")

        level_label = _level_title(request.analysis_level, request.granularity, request.entidad_id, gdf)
        title = f"{request.variable} — {request.election_name} — {level_label}"

        party_name = request.variable.replace("_PCT", "") if "_PCT" in request.variable else None
        party_cmap = get_party_colormap(party_name) if party_name else None

        content = viz_service.create_choropleth_map(
            gdf=gdf,
            variable=request.variable,
            style=request.style,
            title=title,
            party_cmap=party_cmap,
        )

        if request.style == "static":
            return {"content": content, "content_type": "image/png", "encoding": "base64"}
        else:
            return {"content": content, "content_type": "text/html", "encoding": "utf-8"}

    except ValueError as e:
        raise HTTPException(status_code=400, detail=str(e))
    except Exception as e:
        logger.error(f"Error creating choropleth: {e}")
        import traceback
        traceback.print_exc()
        raise HTTPException(status_code=500, detail=str(e))


class WinnerMapRequest(BaseModel):
    """Request model for winner-takes-all map."""
    election_name: str
    analysis_level: str = "national"
    granularity: str = "municipio"
    entidad_id: Optional[int] = None

    @field_validator("election_name")
    @classmethod
    def _norm_election(cls, v: str) -> str:
        return v.strip().upper()


@router.post("/winner-map")
async def create_winner_map(request: WinnerMapRequest):
    """
    Generate a winner-takes-all choropleth: each geometry colored by the
    party with the highest vote share.

    Returns interactive Folium HTML.
    """
    try:
        logger.info(
            f"Creating winner map: {request.election_name}, "
            f"level={request.analysis_level}, gran={request.granularity}, "
            f"entidad={request.entidad_id}"
        )

        gdf = _load_gdf_for_viz(
            request.election_name, request.entidad_id,
            request.analysis_level, request.granularity,
        )

        level_label = _level_title(
            request.analysis_level, request.granularity, request.entidad_id, gdf
        )
        title = f"Partido Ganador — {request.election_name} — {level_label}"

        content = viz_service.create_winner_map(gdf=gdf, title=title)
        return {"content": content, "content_type": "text/html", "encoding": "utf-8"}

    except ValueError as e:
        raise HTTPException(status_code=400, detail=str(e))
    except Exception as e:
        logger.error(f"Error creating winner map: {e}")
        import traceback
        traceback.print_exc()
        raise HTTPException(status_code=500, detail=str(e))


class ChartRequest(BaseModel):
    """Request model for chart generation."""
    data: list
    x: str
    y: str
    style: str = "interactive"
    title: Optional[str] = None
    color: Optional[str] = None


@router.post("/bar-chart")
async def create_bar_chart(request: ChartRequest):
    """
    Generate a bar chart from data.
    
    Args:
        request: ChartRequest with data and chart configuration
        
    Returns:
        Base64 encoded image (static) or HTML (interactive)
    """
    try:
        logger.info(f"Creating bar chart: x={request.x}, y={request.y}, style={request.style}")
        
        # Convert to DataFrame
        df = pd.DataFrame(request.data)
        
        # Create visualization
        content = viz_service.create_bar_chart(
            df=df,
            x=request.x,
            y=request.y,
            style=request.style,
            title=request.title,
            color=request.color
        )
        
        if request.style == "static":
            return {
                "content": content,
                "content_type": "image/png",
                "encoding": "base64"
            }
        else:
            return {
                "content": content,
                "content_type": "text/html",
                "encoding": "utf-8"
            }
    
    except Exception as e:
        logger.error(f"Error creating bar chart: {e}")
        import traceback
        traceback.print_exc()
        raise HTTPException(status_code=500, detail=str(e))


@router.post("/line-chart")
async def create_line_chart(request: ChartRequest):
    """
    Generate a line chart for temporal analysis.
    
    Args:
        request: ChartRequest with data and chart configuration
        
    Returns:
        Base64 encoded image (static) or HTML (interactive)
    """
    try:
        logger.info(f"Creating line chart: x={request.x}, y={request.y}, style={request.style}")
        
        # Convert to DataFrame
        df = pd.DataFrame(request.data)
        
        # Create visualization
        content = viz_service.create_line_chart(
            df=df,
            x=request.x,
            y=request.y,
            style=request.style,
            title=request.title,
            color=request.color
        )
        
        if request.style == "static":
            return {
                "content": content,
                "content_type": "image/png",
                "encoding": "base64"
            }
        else:
            return {
                "content": content,
                "content_type": "text/html",
                "encoding": "utf-8"
            }
    
    except Exception as e:
        logger.error(f"Error creating line chart: {e}")
        import traceback
        traceback.print_exc()
        raise HTTPException(status_code=500, detail=str(e))
