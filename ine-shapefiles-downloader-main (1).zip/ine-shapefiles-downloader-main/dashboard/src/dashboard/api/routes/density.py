"""
Density Router
==============

API endpoints for electoral density visualizations and threshold exports.
Uses the same analysis_level + granularity split as the rest of the dashboard.
"""

import io
import logging
from typing import Optional, Literal

from fastapi import APIRouter, HTTPException, Query
from fastapi.responses import JSONResponse, StreamingResponse
from pydantic import BaseModel, model_validator, Field

from dashboard.api.services import DataService, VisualizationService, AggregationService, DensityService

logger = logging.getLogger(__name__)

router = APIRouter(prefix="/api/viz", tags=["density"])

# Module-level cache for density precomputed lookups
_density_precomputed_cache: dict[str, dict] = {}

data_service = DataService()
viz_service = VisualizationService()
aggregation_service = AggregationService()
density_service = DensityService()

ANALYSIS_LEVEL_TYPE = Literal["national", "state"]
CUMULATIVE_LEVEL_TYPE = Literal["national", "state", "municipal"]
GRANULARITY_TYPE = Literal["section", "distrito_federal", "municipio"]


class DensityMapRequest(BaseModel):
    """Request model for density map generation."""
    election_name: str
    analysis_level: ANALYSIS_LEVEL_TYPE = "national"
    granularity: GRANULARITY_TYPE = "section"
    entidad_id: Optional[int] = None
    style: str = "interactive"
    density_min: float = Field(default=0.0, ge=0.0, le=1.0)

    @model_validator(mode="after")
    def check_entidad_id(self):
        if self.analysis_level == "state" and self.entidad_id is None:
            raise ValueError("entidad_id is required when analysis_level='state'")
        return self


class CumulativeDensityRequest(BaseModel):
    """Request model for cumulative density map and stats."""
    election_name: str
    analysis_level: CUMULATIVE_LEVEL_TYPE = "national"
    entidad_id: Optional[int] = None
    municipio_id: Optional[int] = None
    threshold: float = Field(default=50.0, ge=0.0, le=100.0)
    party: Optional[str] = None
    focus_bbox: Optional[list[float]] = None  # [minLng, minLat, maxLng, maxLat] — overrides auto-zoom


class DensityExportRequest(BaseModel):
    """Request model for density threshold export."""
    election_name: str
    entidad_id: int
    granularity: Literal["section", "municipio"] = "municipio"
    threshold_pct: float = Field(default=80.0, ge=1.0, le=100.0)


@router.get("/density-precomputed")
async def get_density_precomputed(
    election_name: str = Query(..., description="Election name, e.g. PRES_2024"),
    entidad_id: Optional[int] = Query(default=None, ge=1, le=32),
):
    """
    Return a pre-computed {featureKey → density_normalized} lookup for section-level
    electoral density.  Feature key format: "{ENTIDAD}_{SECCION}" e.g. "20_1234".
    Results are cached server-side after first computation.
    """
    scope = f"{entidad_id:02d}" if entidad_id is not None else "national"
    cache_key = f"{election_name}:{scope}"

    if cache_key in _density_precomputed_cache:
        return JSONResponse(content=_density_precomputed_cache[cache_key])

    try:
        gdf = DensityService.compute_density(
            election_name=election_name,
            analysis_level="state" if entidad_id is not None else "national",
            granularity="section",
            data_service=data_service,
            aggregation_service=aggregation_service,
            entidad_id=entidad_id,
        )

        entidad_col = "ID_ENTIDAD" if "ID_ENTIDAD" in gdf.columns else "ENTIDAD"
        data: dict[str, float] = {}
        for _, row in gdf.iterrows():
            try:
                entidad = int(row[entidad_col])
                seccion = int(row["SECCION"])
                key = f"{entidad}_{seccion}"
                data[key] = round(float(row.get("density_normalized") or 0), 4)
            except (TypeError, ValueError):
                continue

        result = {"election_name": election_name, "entidad_id": entidad_id, "data": data}
        _density_precomputed_cache[cache_key] = result
        return JSONResponse(content=result)

    except ValueError as e:
        raise HTTPException(status_code=400, detail=str(e))
    except RuntimeError as e:
        raise HTTPException(status_code=503, detail=str(e))
    except Exception as e:
        logger.error(f"Error computing density precomputed: {e}")
        import traceback
        traceback.print_exc()
        raise HTTPException(status_code=500, detail=str(e))


@router.post("/density-map")
async def create_density_map(request: DensityMapRequest):
    """
    Generate an electoral density choropleth map.

    Density = total_votes / area_km2. The density_min parameter (0–1,
    normalised) filters out low-density areas.

    Returns:
        HTML (interactive) or base64 PNG (static).
    """
    try:
        logger.info(
            f"Density map: {request.election_name}, level={request.analysis_level}, "
            f"gran={request.granularity}, entidad={request.entidad_id}, "
            f"style={request.style}, min={request.density_min}"
        )

        gdf = DensityService.compute_density(
            election_name=request.election_name,
            analysis_level=request.analysis_level,
            granularity=request.granularity,
            data_service=data_service,
            aggregation_service=aggregation_service,
            entidad_id=request.entidad_id,
        )

        if request.density_min > 0:
            gdf = gdf[gdf["density_normalized"] >= request.density_min].copy()

        if len(gdf) == 0:
            raise ValueError(
                f"No areas remain after applying density_min={request.density_min}. "
                "Lower the threshold."
            )

        content = viz_service.create_choropleth_map(
            gdf=gdf,
            variable="density_normalized",
            style=request.style,
            title=f"Electoral Density — {request.election_name}",
            color_scale="YlOrRd",
        )

        if request.style == "static":
            return {"content": content, "content_type": "image/png", "encoding": "base64"}
        else:
            return {"content": content, "content_type": "text/html", "encoding": "utf-8"}

    except ValueError as e:
        raise HTTPException(status_code=400, detail=str(e))
    except RuntimeError as e:
        raise HTTPException(status_code=503, detail=str(e))
    except Exception as e:
        logger.error(f"Error creating density map: {e}")
        import traceback
        traceback.print_exc()
        raise HTTPException(status_code=500, detail=str(e))


@router.post("/density-export")
async def create_density_export(request: DensityExportRequest):
    """
    Generate an .xlsx listing sections/municipalities that accumulate
    *threshold_pct* percent of a state's total votes, sorted by density.
    """
    try:
        logger.info(
            f"Density export: {request.election_name}, entidad={request.entidad_id}, "
            f"gran={request.granularity}, threshold={request.threshold_pct}%"
        )

        df = DensityService.compute_threshold_export(
            election_name=request.election_name,
            entidad_id=request.entidad_id,
            granularity=request.granularity,
            threshold_pct=request.threshold_pct,
            data_service=data_service,
            aggregation_service=aggregation_service,
        )

        buf = io.BytesIO()
        df.to_excel(buf, index=False, engine="openpyxl")
        buf.seek(0)

        filename = (
            f"density_export_{request.election_name}_{request.granularity}"
            f"_{int(request.threshold_pct)}pct.xlsx"
        )

        return StreamingResponse(
            buf,
            media_type="application/vnd.openxmlformats-officedocument.spreadsheetml.sheet",
            headers={"Content-Disposition": f"attachment; filename={filename}"},
        )

    except ValueError as e:
        raise HTTPException(status_code=400, detail=str(e))
    except RuntimeError as e:
        raise HTTPException(status_code=503, detail=str(e))
    except Exception as e:
        logger.error(f"Error creating density export: {e}")
        import traceback
        traceback.print_exc()
        raise HTTPException(status_code=500, detail=str(e))


@router.post("/density-cumulative")
async def create_cumulative_density_map(request: CumulativeDensityRequest):
    """
    Generate a cumulative electoral density map (CDF approach).

    Sorts secciones by votes/km² descending within each group
    (nacional / per-estado / per-municipio), computes running cumulative
    vote share, and highlights only the secciones that together account
    for the requested threshold percentage of total votes.

    Returns:
        HTML Folium map with in-threshold secciones coloured by density
        and out-of-threshold secciones shown as light gray.
    """
    try:
        logger.info(
            f"Cumulative density map: {request.election_name}, "
            f"level={request.analysis_level}, threshold={request.threshold}, "
            f"entidad={request.entidad_id}, party={request.party}"
        )

        gdf = DensityService.compute_cumulative_density(
            election_name=request.election_name,
            cumulative_level=request.analysis_level,
            threshold=request.threshold,
            data_service=data_service,
            aggregation_service=aggregation_service,
            entidad_id=request.entidad_id,
            party=request.party,
            municipio_id=request.municipio_id,
        )

        html = DensityService.create_cumulative_map(
            gdf, request.threshold, focus_bbox=request.focus_bbox
        )
        return {"content": html, "content_type": "text/html", "encoding": "utf-8"}

    except ValueError as e:
        raise HTTPException(status_code=400, detail=str(e))
    except RuntimeError as e:
        raise HTTPException(status_code=503, detail=str(e))
    except Exception as e:
        logger.error(f"Error creating cumulative density map: {e}")
        import traceback
        traceback.print_exc()
        raise HTTPException(status_code=500, detail=str(e))


@router.post("/density-cumulative/stats")
async def get_cumulative_density_stats(request: CumulativeDensityRequest):
    """
    Return summary statistics for a cumulative density query without
    generating the full Folium map (faster).

    Returns:
        JSON with total_secciones, secciones_in_threshold, pct_secciones,
        geographic_concentration, top_municipios, top_estados.
    """
    try:
        logger.info(
            f"Cumulative density stats: {request.election_name}, "
            f"level={request.analysis_level}, threshold={request.threshold}"
        )

        gdf = DensityService.compute_cumulative_density(
            election_name=request.election_name,
            cumulative_level=request.analysis_level,
            threshold=request.threshold,
            data_service=data_service,
            aggregation_service=aggregation_service,
            entidad_id=request.entidad_id,
            party=request.party,
            municipio_id=request.municipio_id,
        )

        return DensityService.compute_cumulative_stats(gdf)

    except ValueError as e:
        raise HTTPException(status_code=400, detail=str(e))
    except RuntimeError as e:
        raise HTTPException(status_code=503, detail=str(e))
    except Exception as e:
        logger.error(f"Error computing cumulative density stats: {e}")
        import traceback
        traceback.print_exc()
        raise HTTPException(status_code=500, detail=str(e))
