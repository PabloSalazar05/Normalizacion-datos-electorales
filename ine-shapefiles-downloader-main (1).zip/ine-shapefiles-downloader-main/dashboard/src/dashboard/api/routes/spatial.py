"""
Spatial Analysis Router
========================

API endpoints for spatial autocorrelation analysis.
Supports three analysis levels:
  - national   : all electoral sections from every available state (entidad_id not required)
  - state      : electoral sections within one state (entidad_id required)
  - municipality: sections dissolved to municipalities (entidad_id required)
"""

from fastapi import APIRouter, HTTPException
import logging
from typing import Optional
import geopandas as gpd

from dashboard.api.models import (
    SpatialLagRequest,
    MoranRequest,
    MoranResult,
    LISARequest,
    LISAResult,
    SpatialLagResult
)
from dashboard.api.services import DataService, SpatialService, AggregationService

logger = logging.getLogger(__name__)

router = APIRouter(prefix="/api/spatial", tags=["spatial"])

# Initialize services
data_service = DataService()
spatial_service = SpatialService()
aggregation_service = AggregationService()


def _load_gdf(
    election_name: str,
    entidad_id,
    analysis_level: str,
    granularity: str = "section",
    municipio_id: Optional[int] = None,
) -> gpd.GeoDataFrame:
    """
    Load the appropriate section-level GeoDataFrame and apply granularity dissolve.

    analysis_level: 'national' | 'state' | 'municipality'
    granularity:    'section' | 'distrito_federal' | 'municipio'
    """
    if analysis_level == "national":
        gdf = aggregation_service.load_national_geodataframe(election_name, data_service)
    elif analysis_level == "municipality":
        gdf = aggregation_service.load_municipality_geodataframe(
            election_name, entidad_id, municipio_id, data_service
        )
    else:  # "state"
        gdf = aggregation_service.load_state_geodataframe(
            election_name, entidad_id, data_service
        )

    return aggregation_service.apply_granularity(gdf, granularity, entidad_id)


@router.post("/lag", response_model=SpatialLagResult)
async def compute_spatial_lag(request: SpatialLagRequest):
    """
    Compute spatial lag for a variable.

    Spatial lag is the weighted average of neighboring values.
    Supports analysis_level: 'national' | 'state' | 'municipality'.
    """
    try:
        logger.info(
            f"Computing spatial lag: {request.election_name}, "
            f"level={request.analysis_level}, entidad={request.entidad_id}, "
            f"var={request.variable}"
        )

        gdf = _load_gdf(
            request.election_name, request.entidad_id,
            request.analysis_level, request.granularity,
            municipio_id=request.municipio_id,
        )
        logger.info(f"GeoDataFrame loaded: {type(gdf)}, rows={len(gdf)}")

        gdf_lag, stats = spatial_service.compute_spatial_lag_with_statistics(
            gdf=gdf,
            variable=request.variable,
            weights_type=request.weights_type,
        )

        gdf_wgs84 = gdf_lag.to_crs(epsg=4326) if gdf_lag.crs else gdf_lag

        import json
        geojson_dict = json.loads(gdf_wgs84.to_json())

        # Derive a label for the area covered
        if request.analysis_level == "national":
            area_label = "Nacional"
        elif "entidad_name" in gdf.columns:
            area_label = str(gdf["entidad_name"].iloc[0])
        elif "ENTIDAD" in gdf.columns:
            area_label = str(gdf["ENTIDAD"].iloc[0])
        else:
            area_label = f"Estado {request.entidad_id}"

        result = {
            "election_name": request.election_name,
            "entidad_id": request.entidad_id or 0,
            "entidad_name": area_label,
            "variable": request.variable,
            "geojson": geojson_dict,
            "statistics": {
                "mean_original": stats["original"]["mean"],
                "mean_lag": stats["lag"]["mean"],
                "correlation": stats["correlation"],
                "std_original": stats["original"]["std"],
                "std_lag": stats["lag"]["std"],
                "n_observations": stats["original"]["count"],
            },
        }

        return result

    except ValueError as e:
        raise HTTPException(status_code=400, detail=str(e))
    except Exception as e:
        logger.error(f"Error computing spatial lag: {e}")
        import traceback
        traceback.print_exc()
        raise HTTPException(status_code=500, detail=str(e))


@router.post("/moran", response_model=MoranResult)
async def compute_moran_i(request: MoranRequest):
    """
    Compute Moran's I spatial autocorrelation statistic.

    - Values near +1: positive autocorrelation (similar values cluster)
    - Values near -1: negative autocorrelation (dissimilar values neighbor)
    - Values near 0: random spatial pattern

    Supports analysis_level: 'national' | 'state' | 'municipality'.
    At national level, all available electoral sections across Mexico are used.
    """
    try:
        logger.info(
            f"Computing Moran's I: {request.election_name}, "
            f"level={request.analysis_level}, entidad={request.entidad_id}, "
            f"var={request.variable}"
        )

        gdf = _load_gdf(
            request.election_name, request.entidad_id,
            request.analysis_level, request.granularity,
            municipio_id=request.municipio_id,
        )

        logger.info(f"Got GeoDataFrame: {type(gdf)}, rows={len(gdf)}")

        moran_result = spatial_service.compute_moran_i(
            gdf=gdf,
            variable=request.variable,
            weights_type=request.weights_type,
            permutations=request.permutations,
        )

        moran_result["election_name"] = request.election_name
        moran_result["entidad_id"] = request.entidad_id or 0

        # Surface a UI-facing note at national level
        if request.analysis_level == "national":
            n_obs = moran_result.get("n_observations", 0)
            note = (
                f"[Nivel nacional — {n_obs:,} observaciones, "
                f"granularidad: {request.granularity}] "
            )
            moran_result["interpretation"] = note + moran_result.get("interpretation", "")

        return moran_result

    except ValueError as e:
        raise HTTPException(status_code=400, detail=str(e))
    except Exception as e:
        logger.error(f"Error computing Moran's I: {e}")
        import traceback
        traceback.print_exc()
        raise HTTPException(status_code=500, detail=str(e))


@router.post("/lisa", response_model=LISAResult)
async def compute_lisa(request: LISARequest):
    """
    Compute Local Moran's I (LISA) for spatial cluster detection.

    Returns a GeoJSON FeatureCollection where each feature carries:
      - cluster_type: 'HH' | 'LL' | 'HL' | 'LH' | 'NS'
      - local_i: local Moran's I value
      - p_value: permutation-based p-value
      - z_score: standardised local I
      - significant: boolean

    Cluster types:
      HH — Hot spot   (high value, high-value neighbours)
      LL — Cold spot  (low value, low-value neighbours)
      HL — Spatial outlier (high value, low-value neighbours)
      LH — Spatial outlier (low value, high-value neighbours)
      NS — Not statistically significant
    """
    try:
        logger.info(
            f"Computing LISA: {request.election_name}, "
            f"level={request.analysis_level}, entidad={request.entidad_id}, "
            f"var={request.variable}, sig={request.significance}"
        )

        gdf = _load_gdf(
            request.election_name, request.entidad_id,
            request.analysis_level, request.granularity,
            municipio_id=request.municipio_id,
        )

        lisa_result = spatial_service.compute_lisa(
            gdf=gdf,
            variable=request.variable,
            weights_type=request.weights_type,
            permutations=request.permutations,
            significance=request.significance,
        )

        lisa_result["election_name"] = request.election_name
        lisa_result["entidad_id"] = request.entidad_id or 0
        lisa_result["granularity"] = request.granularity

        return lisa_result

    except ValueError as e:
        raise HTTPException(status_code=400, detail=str(e))
    except Exception as e:
        logger.error(f"Error computing LISA: {e}")
        import traceback
        traceback.print_exc()
        raise HTTPException(status_code=500, detail=str(e))


@router.get("/variables/{election_name}/{entidad_id}")
async def get_available_variables(election_name: str, entidad_id: int):
    """
    Get list of variables available for spatial analysis.

    Uses section-level data from the specified state to enumerate
    available numeric/percentage columns.
    """
    try:
        df = data_service.load_election_data(
            election_name=election_name,
            entidad_id=entidad_id,
            as_geodataframe=False,
        )

        numeric_cols = df.select_dtypes(include=["float64", "int64"]).columns.tolist()
        pct_cols = [col for col in numeric_cols if "PCT" in col.upper()]

        excluded_patterns = [
            "DISTRITO_FEDERAL", "EXT_CONTIGUA", "UBICACION_CASILLA",
            "DISTRITO", "SECCION", "CASILLA", "ID_",
        ]

        pct_cols = [
            col for col in pct_cols
            if not any(pat in col.upper() for pat in excluded_patterns)
        ]

        other_numeric = [col for col in numeric_cols if "PCT" not in col.upper()]

        return {
            "percentage_variables": pct_cols,
            "other_numeric_variables": other_numeric[:20],
            "total_numeric_columns": len(numeric_cols),
        }

    except Exception as e:
        logger.error(f"Error getting available variables: {e}")
        raise HTTPException(status_code=500, detail=str(e))


@router.post("/cache/clear")
async def clear_national_cache():
    """
    Clear the server-side cache for national aggregated GeoDataFrames.

    Call this after re-ingesting electoral data to ensure fresh results.
    """
    aggregation_service.clear_cache()
    return {"status": "ok", "message": "National GeoDataFrame cache cleared."}
