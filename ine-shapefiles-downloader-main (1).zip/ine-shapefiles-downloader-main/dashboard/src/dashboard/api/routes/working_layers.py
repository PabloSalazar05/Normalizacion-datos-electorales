"""
Working Layers Router
=====================

API endpoints for user-created working layers.

Working layers are GeoDataFrame snapshots derived from completed analyses
(Moran's I, LISA, Density) that can be:
  - Listed, renamed, and deleted
  - Combined via attribute join to produce multi-analysis overlays
  - Exported to a formatted .xlsx file
  - Fetched as GeoJSON for client-side rendering

All data is in-memory and does not persist across restarts.
"""

import logging
from typing import List, Optional

from fastapi import APIRouter, HTTPException
from fastapi.responses import StreamingResponse
from pydantic import BaseModel, Field

from dashboard.api.services import DataService, AggregationService, SpatialService
from dashboard.api.services.working_layer_service import WorkingLayerService

logger = logging.getLogger(__name__)

router = APIRouter(prefix="/api/working-layers", tags=["working-layers"])

# Shared service instances (same pattern as other routers)
data_service        = DataService()
aggregation_service = AggregationService()
spatial_service     = SpatialService()


# ── Request models ────────────────────────────────────────────────────────────

class MoranLayerParams(BaseModel):
    election_name:  str
    variable:       str
    entidad_id:     Optional[int] = None
    granularity:    str = "section"
    analysis_level: str = "state"
    moran_i:        float
    p_value:        float
    significant:    bool
    z_score:        float
    n_observations: int = 0


class LISALayerParams(BaseModel):
    election_name:    str
    variable:         str
    entidad_id:       int
    granularity:      str = "section"
    analysis_level:   str = "state"
    significance:     float = 0.05
    # Pre-computed fields supplied by the frontend to avoid re-running LISA
    geojson_features: Optional[list] = None
    n_significant:    int = 0
    n_observations:   int = 0
    cluster_counts:   dict = {}


class DensityLayerParams(BaseModel):
    election_name: str
    entidad_id:    int
    granularity:   str = "section"
    threshold_pct: float = Field(default=80.0, ge=1.0, le=100.0)
    municipio_id:  Optional[int] = None


class CreateLayerRequest(BaseModel):
    type:    str            # "moran" | "lisa" | "density"
    name:    Optional[str] = None
    params:  dict


class RenameRequest(BaseModel):
    name: str


class CombineRequest(BaseModel):
    layer_ids: List[str] = Field(..., min_length=2)
    name:      Optional[str] = None


class IntersectionLayerParams(BaseModel):
    layer_ids: List[str] = Field(..., min_length=2)


# ── Endpoints ─────────────────────────────────────────────────────────────────

@router.get("")
async def list_layers():
    """Return metadata for all working layers (no geometry)."""
    return WorkingLayerService.list_layers()


@router.get("/{layer_id}")
async def get_layer(layer_id: str):
    """Return metadata for a single working layer."""
    meta = WorkingLayerService.get_meta(layer_id)
    if not meta:
        raise HTTPException(status_code=404, detail=f"Layer '{layer_id}' not found.")
    return meta


@router.delete("/{layer_id}")
async def delete_layer(layer_id: str):
    """Delete a working layer."""
    if not WorkingLayerService.delete_layer(layer_id):
        raise HTTPException(status_code=404, detail=f"Layer '{layer_id}' not found.")
    return {"ok": True}


@router.patch("/{layer_id}/rename")
async def rename_layer(layer_id: str, body: RenameRequest):
    """Rename a working layer."""
    result = WorkingLayerService.rename_layer(layer_id, body.name)
    if not result:
        raise HTTPException(status_code=404, detail=f"Layer '{layer_id}' not found.")
    return result


@router.get("/{layer_id}/geojson")
async def get_layer_geojson(layer_id: str):
    """Return the full GeoJSON FeatureCollection for a working layer."""
    fc = WorkingLayerService.get_geojson(layer_id)
    if not fc:
        raise HTTPException(status_code=404, detail=f"Layer '{layer_id}' not found.")
    return fc


@router.get("/{layer_id}/export")
async def export_layer(layer_id: str):
    """Download a working layer as a formatted .xlsx file."""
    xlsx_bytes = WorkingLayerService.export_to_excel(layer_id)
    if xlsx_bytes is None:
        raise HTTPException(status_code=404, detail=f"Layer '{layer_id}' not found.")

    meta = WorkingLayerService.get_meta(layer_id)
    safe_name = (meta["name"] if meta else layer_id).replace(" ", "_")

    import io
    return StreamingResponse(
        io.BytesIO(xlsx_bytes),
        media_type="application/vnd.openxmlformats-officedocument.spreadsheetml.sheet",
        headers={"Content-Disposition": f'attachment; filename="{safe_name}.xlsx"'},
    )


@router.post("/combine")
async def combine_layers(body: CombineRequest):
    """Combine two or more working layers into a single Combined layer."""
    try:
        return WorkingLayerService.combine_layers(body.layer_ids, body.name)
    except ValueError as e:
        raise HTTPException(status_code=400, detail=str(e))
    except Exception as e:
        logger.error("Error combining layers: %s", e)
        import traceback; traceback.print_exc()
        raise HTTPException(status_code=500, detail=str(e))


@router.post("")
async def create_layer(body: CreateLayerRequest):
    """
    Create a working layer from a completed analysis.

    type = "moran"   → params must match MoranLayerParams
    type = "lisa"    → params must match LISALayerParams
    type = "density" → params must match DensityLayerParams
    """
    try:
        layer_type = body.type.lower()

        if layer_type == "moran":
            p = MoranLayerParams(**body.params)
            return WorkingLayerService.create_from_moran(
                election_name=p.election_name,
                variable=p.variable,
                entidad_id=p.entidad_id,
                granularity=p.granularity,
                analysis_level=p.analysis_level,
                moran_result={
                    "moran_i":        p.moran_i,
                    "p_value":        p.p_value,
                    "significant":    p.significant,
                    "z_score":        p.z_score,
                    "n_observations": p.n_observations,
                },
                name=body.name,
                data_service=data_service,
                aggregation_service=aggregation_service,
            )

        elif layer_type == "lisa":
            p = LISALayerParams(**body.params)
            return WorkingLayerService.create_from_lisa(
                election_name=p.election_name,
                variable=p.variable,
                entidad_id=p.entidad_id,
                granularity=p.granularity,
                analysis_level=p.analysis_level,
                significance=p.significance,
                name=body.name,
                geojson_features=p.geojson_features,
                n_significant=p.n_significant,
                n_observations=p.n_observations,
                cluster_counts=p.cluster_counts,
                data_service=data_service,
                aggregation_service=aggregation_service,
                spatial_service=spatial_service,
            )

        elif layer_type == "density":
            p = DensityLayerParams(**body.params)
            return WorkingLayerService.create_from_density(
                election_name=p.election_name,
                entidad_id=p.entidad_id,
                granularity=p.granularity,
                threshold_pct=p.threshold_pct,
                name=body.name,
                data_service=data_service,
                aggregation_service=aggregation_service,
                municipio_id=p.municipio_id,
            )

        elif layer_type == "intersection":
            p = IntersectionLayerParams(**body.params)
            return WorkingLayerService.create_from_intersection(
                layer_ids=p.layer_ids,
                name=body.name,
            )

        else:
            raise HTTPException(
                status_code=400,
                detail=f"Unknown layer type '{layer_type}'. Expected: moran, lisa, density, intersection.",
            )

    except HTTPException:
        raise
    except ValueError as e:
        raise HTTPException(status_code=400, detail=str(e))
    except RuntimeError as e:
        raise HTTPException(status_code=503, detail=str(e))
    except Exception as e:
        logger.error("Error creating working layer: %s", e)
        import traceback; traceback.print_exc()
        raise HTTPException(status_code=500, detail=str(e))
