"""
Geometry Audit and Fix Script
==============================

Scans all PEEPJF shapefiles for the valid states, validates geometry using
shapely.make_valid(), reprojects to EPSG:4326, applies layer-specific
simplification, and writes fixed GeoJSONs to data/processed/layers/.

Run once (or after new shapefiles are downloaded):
    uv run python dashboard/src/dashboard/scripts/audit_geometries.py

Outputs:
    data/processed/layers/{layer_name}/{entidad_id:02d}.geojson
    data/processed/layers/audit_report.json
"""

import argparse
import json
import logging
import sys
from pathlib import Path
from typing import Any, Optional

import geopandas as gpd
from shapely.validation import make_valid

logging.basicConfig(
    level=logging.INFO,
    format="%(asctime)s - %(levelname)s - %(message)s",
)
logger = logging.getLogger(__name__)

# Project paths
# __file__ = .../dashboard/src/dashboard/scripts/audit_geometries.py
# parents[4] = project root
PROJECT_ROOT = Path(__file__).parents[4]
PEEPJF_DIR = PROJECT_ROOT / "data" / "geo" / "shapefiles_peepjf"
NACIONAL_DIR = PROJECT_ROOT / "data" / "geo" / "productos_ine_nacional"
OUTPUT_DIR = PROJECT_ROOT / "data" / "processed" / "layers"
CONFIG_PATH = Path(__file__).parents[1] / "api" / "layers.config.json"

# States with confirmed valid PEEPJF shapefiles
VALID_ENTIDAD_IDS: list[int] = [1, 2, 3, 4, 6, 10, 18, 25, 27, 29, 31]

# Centroid longitude threshold for geographic validation
# (Baja California, entidad_id=2, is the only state whose correct shapefile
#  has centroids west of -113°)
_BC_CENTROID_THRESHOLD = -113.0

ENTIDAD_FOLDERS: dict[int, str] = {
    1: "1_Aguascalientes",
    2: "2_Baja_California",
    3: "3_Baja_California_Sur",
    4: "4_Campeche",
    5: "5_Coahuila",
    6: "6_Colima",
    7: "7_Chiapas",
    8: "8_Chihuahua",
    9: "9_CDMX",
    10: "10_Durango",
    11: "11_Guanajuato",
    12: "12_Guerrero",
    13: "13_Hidalgo",
    14: "14_Jalisco",
    15: "15_Mexico",
    16: "16_Michoacan",
    17: "17_Morelos",
    18: "18_Nayarit",
    19: "19_Nuevo_Leon",
    20: "20_Oaxaca",
    21: "21_Puebla",
    22: "22_Queretaro",
    23: "23_Quintana_Roo",
    24: "24_San_Luis_Potosi",
    25: "25_Sinaloa",
    26: "26_Sonora",
    27: "27_Tabasco",
    28: "28_Tamaulipas",
    29: "29_Tlaxcala",
    30: "30_Veracruz",
    31: "31_Yucatan",
    32: "32_Zacatecas",
}


def _find_peepjf_shapefile(entidad_id: int, shapefile_name: str) -> Optional[Path]:
    """
    Find the PEEPJF shapefile path for a given state and layer.

    Structure: shapefiles_peepjf/{N_State}/{NN}/{SHAPEFILE_NAME}
    Returns None if the file does not exist.
    """
    folder = ENTIDAD_FOLDERS.get(entidad_id)
    if folder is None:
        return None
    entidad_str = str(entidad_id).zfill(2)
    candidate = PEEPJF_DIR / folder / entidad_str / shapefile_name
    if candidate.exists():
        return candidate
    # Fallback: search sub-directories
    state_dir = PEEPJF_DIR / folder
    if state_dir.exists():
        for sub in sorted(state_dir.iterdir()):
            if sub.is_dir():
                p = sub / shapefile_name
                if p.exists():
                    return p
    return None


def _find_nacional_shapefile(entidad_id: int, shapefile_name: str) -> Optional[Path]:
    """
    Find the nacional shapefile path for a given state and layer.

    Structure: productos_ine_nacional/{N_State}/Shapefile/{NN STATE}/{SHAPEFILE_NAME}
    Returns None if the file does not exist.
    """
    folder = ENTIDAD_FOLDERS.get(entidad_id)
    if folder is None:
        return None
    state_dir = NACIONAL_DIR / folder / "Shapefile"
    if not state_dir.exists():
        return None
    # The inner subfolder has a variable name like "03 BAJA CALIFORNIA SUR"
    for sub in sorted(state_dir.iterdir()):
        if sub.is_dir():
            p = sub / shapefile_name
            if p.exists():
                return p
    return None


def _find_shapefile(entidad_id: int, shapefile_name: str) -> Optional[Path]:
    """
    Find shapefile for a state, trying PEEPJF first then nacional as fallback.
    Returns (path, source) or (None, None).
    """
    return _find_peepjf_shapefile(entidad_id, shapefile_name) or \
           _find_nacional_shapefile(entidad_id, shapefile_name)


def _geographic_validation(gdf: gpd.GeoDataFrame, entidad_id: int) -> bool:
    """
    Return True if the shapefile centroid longitude is plausible for entidad_id.

    Rejects Baja California's shapefile (lon ≈ -116°) when loaded into any
    other state's folder — the known PEEPJF bug.
    """
    gdf_wgs = gdf.to_crs("EPSG:4326") if gdf.crs and gdf.crs.to_epsg() != 4326 else gdf
    mean_lon = gdf_wgs.geometry.centroid.x.mean()
    if entidad_id != 2 and mean_lon < _BC_CENTROID_THRESHOLD:
        logger.warning(
            "entidad_id=%d: centroid lon=%.2f is too far west (Baja California shapefile?). "
            "Skipping — re-download the correct shapefile.",
            entidad_id, mean_lon,
        )
        return False
    return True


def audit_and_fix_layer(
    entidad_id: int,
    shapefile_name: str,
    layer_name: str,
    simplification_tolerance: float,
) -> dict[str, Any]:
    """
    Load a PEEPJF shapefile, validate and fix geometry, reproject to EPSG:4326,
    simplify, then write the result as GeoJSON.

    Returns an audit record dict:
        entidad_id, layer_name, total_features, invalid_before,
        invalid_after, output_path, error (or None)
    """
    record: dict[str, Any] = {
        "entidad_id": entidad_id,
        "layer_name": layer_name,
        "total_features": 0,
        "invalid_before": 0,
        "invalid_after": 0,
        "output_path": None,
        "error": None,
    }

    # Try PEEPJF first, fall back to nacional if geographic validation fails
    gdf = None
    for find_fn, source_name in [
        (_find_peepjf_shapefile, "peepjf"),
        (_find_nacional_shapefile, "nacional"),
    ]:
        shp_path = find_fn(entidad_id, shapefile_name)
        if shp_path is None:
            continue
        try:
            candidate_gdf = gpd.read_file(shp_path)
        except Exception as exc:
            logger.warning("entidad_id=%d layer=%s source=%s: read error: %s", entidad_id, layer_name, source_name, exc)
            continue
        if candidate_gdf.empty:
            continue
        if not _geographic_validation(candidate_gdf, entidad_id):
            logger.info("entidad_id=%d layer=%s: %s failed geographic validation, trying next source", entidad_id, layer_name, source_name)
            continue
        gdf = candidate_gdf
        logger.info("entidad_id=%d layer=%s: using %s shapefile", entidad_id, layer_name, source_name)
        break

    if gdf is None:
        record["error"] = f"No valid shapefile found ({shapefile_name}) in PEEPJF or nacional"
        logger.warning("entidad_id=%d layer=%s: %s", entidad_id, layer_name, record["error"])
        return record

    # Override ENTIDAD column with folder-derived entidad_id (PEEPJF bug fix)
    if "ENTIDAD" in gdf.columns:
        gdf["ENTIDAD"] = entidad_id

    record["total_features"] = len(gdf)

    # Count invalid geometries before fix
    invalid_mask = ~gdf.geometry.is_valid
    record["invalid_before"] = int(invalid_mask.sum())

    # Fix invalid geometries using make_valid (Shapely >=2.0)
    if record["invalid_before"] > 0:
        logger.info(
            "entidad_id=%d layer=%s: fixing %d invalid geometries",
            entidad_id, layer_name, record["invalid_before"],
        )
        gdf.geometry = gdf.geometry.apply(make_valid)

    # Count invalid geometries after fix
    invalid_after = int((~gdf.geometry.is_valid).sum())
    record["invalid_after"] = invalid_after
    if invalid_after > 0:
        logger.warning(
            "entidad_id=%d layer=%s: %d geometries still invalid after make_valid",
            entidad_id, layer_name, invalid_after,
        )

    # Reproject to WGS84 (EPSG:4326)
    try:
        if gdf.crs is None:
            logger.warning("entidad_id=%d layer=%s: no CRS, assuming EPSG:32613", entidad_id, layer_name)
            gdf = gdf.set_crs("EPSG:32613")
        gdf = gdf.to_crs("EPSG:4326")
    except Exception as exc:
        record["error"] = f"CRS reprojection failed: {exc}"
        logger.error("entidad_id=%d layer=%s: %s", entidad_id, layer_name, record["error"])
        return record

    # Simplify geometry
    if simplification_tolerance > 0:
        gdf.geometry = gdf.geometry.simplify(
            simplification_tolerance, preserve_topology=True
        )

    # Write GeoJSON
    out_dir = OUTPUT_DIR / layer_name
    out_dir.mkdir(parents=True, exist_ok=True)
    out_path = out_dir / f"{entidad_id:02d}.geojson"
    try:
        gdf.to_file(str(out_path), driver="GeoJSON")
        record["output_path"] = str(out_path)
        logger.info(
            "entidad_id=%d layer=%s: wrote %d features → %s",
            entidad_id, layer_name, len(gdf), out_path,
        )
    except Exception as exc:
        record["error"] = f"Failed to write GeoJSON: {exc}"
        logger.error("entidad_id=%d layer=%s: %s", entidad_id, layer_name, record["error"])

    return record


def run_audit(entidad_ids: list[int] = VALID_ENTIDAD_IDS) -> list[dict[str, Any]]:
    """
    Run the geometry audit for all (state, layer) combinations.

    Writes each fixed GeoJSON to data/processed/layers/{layer}/{entidad_id:02d}.geojson
    and saves a summary to data/processed/layers/audit_report.json.

    Returns the list of audit records.
    """
    config = json.loads(CONFIG_PATH.read_text())
    OUTPUT_DIR.mkdir(parents=True, exist_ok=True)

    report: list[dict[str, Any]] = []
    total = len(entidad_ids) * sum(
        1 for v in config["layers"].values() if v["enabled"]
    )
    done = 0

    for layer_name, layer_cfg in config["layers"].items():
        if not layer_cfg["enabled"]:
            continue
        for entidad_id in entidad_ids:
            record = audit_and_fix_layer(
                entidad_id=entidad_id,
                shapefile_name=layer_cfg["shapefile_name"],
                layer_name=layer_name,
                simplification_tolerance=layer_cfg["simplification_tolerance"],
            )
            report.append(record)
            done += 1
            logger.info("Progress: %d/%d", done, total)

    report_path = OUTPUT_DIR / "audit_report.json"
    report_path.write_text(json.dumps(report, indent=2))
    logger.info("Audit complete. Report saved to %s", report_path)

    # Summary
    errors = [r for r in report if r["error"]]
    invalid_remaining = [r for r in report if r["invalid_after"] > 0]
    logger.info(
        "Summary: %d records | %d errors | %d with remaining invalid geometries",
        len(report), len(errors), len(invalid_remaining),
    )
    return report


def _parse_args() -> argparse.Namespace:
    parser = argparse.ArgumentParser(
        description="Audit and fix PEEPJF shapefile geometries, output GeoJSON layers."
    )
    parser.add_argument(
        "--states",
        nargs="+",
        type=int,
        metavar="N",
        help="State entidad_ids to audit (default: all valid states)",
        default=VALID_ENTIDAD_IDS,
    )
    parser.add_argument(
        "--layer",
        choices=["seccion", "municipio", "distrito_federal", "distrito_local", "entidad", "all"],
        default="all",
        help="Which layer to audit (default: all)",
    )
    return parser.parse_args()


if __name__ == "__main__":
    args = _parse_args()

    if args.layer != "all":
        # Temporarily disable other layers in config for targeted run
        config = json.loads(CONFIG_PATH.read_text())
        for lname in list(config["layers"].keys()):
            if lname != args.layer:
                config["layers"][lname]["enabled"] = False
        # Write temp config — we just need to pass it to run_audit differently
        # Instead, filter within run_audit by monkey-patching CONFIG_PATH reading:
        import tempfile, os
        with tempfile.NamedTemporaryFile(
            mode="w", suffix=".json", delete=False
        ) as tf:
            json.dump(config, tf)
            tmp_path = tf.name
        original_config = CONFIG_PATH
        # Use importlib trick is complex; just run audit_and_fix_layer directly
        layer_cfg = json.loads(original_config.read_text())["layers"][args.layer]
        report = []
        for eid in args.states:
            r = audit_and_fix_layer(
                entidad_id=eid,
                shapefile_name=layer_cfg["shapefile_name"],
                layer_name=args.layer,
                simplification_tolerance=layer_cfg["simplification_tolerance"],
            )
            report.append(r)
        report_path = OUTPUT_DIR / "audit_report.json"
        OUTPUT_DIR.mkdir(parents=True, exist_ok=True)
        report_path.write_text(json.dumps(report, indent=2))
        os.unlink(tmp_path)
    else:
        report = run_audit(args.states)

    errors = [r for r in report if r["error"]]
    sys.exit(1 if errors else 0)
