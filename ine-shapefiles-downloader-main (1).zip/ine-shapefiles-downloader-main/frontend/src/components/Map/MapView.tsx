import { useEffect, useRef, useState } from 'react'
import maplibregl from 'maplibre-gl'
import 'maplibre-gl/dist/maplibre-gl.css'
import { useMapStore } from '../../store/mapStore'
import { useElectoralLayer } from '../../hooks/useElectoralLayer'
import { fetchLayer, fetchLayerLabels, fetchPrecomputedElectoral } from '../../api/layersApi'
import { buildSinglePartyExpression, buildWinnerExpression, getPctColumns } from '../../utils/choropleth'
import { PARTY_COLORS } from '../../utils/partyColors'
import { computeBBox } from '../../utils/geo'
import { buildChartHTML } from '../../utils/chartPopup'
import { PartyLegend } from './PartyLegend'
import type { LayerName } from '../../types/layers'
import './MapView.css'

const BASEMAP_STYLE = 'https://tiles.openfreemap.org/styles/liberty'

const EMPTY_FC: GeoJSON.FeatureCollection = { type: 'FeatureCollection', features: [] }

// Layers that get their own map source/layers (entidad is only the highlight border)
const DATA_LAYERS: LayerName[] = ['seccion', 'municipio', 'distrito_federal', 'distrito_local']

// Line colors for each overlay layer
// Note: distrito_local was previously #9B1C1C (same dark red as MORENA fill — invisible).
// Colors chosen to be distinguishable from party fill colors AND from each other.
const LAYER_LINE_COLORS: Record<LayerName, string> = {
  seccion:           '#1B9A8E',  // teal
  municipio:         '#FF8C00',  // vivid orange
  distrito_federal:  '#0EA5E9',  // sky blue
  distrito_local:    '#A855F7',  // purple
  entidad:           '#1A3A52',  // navy
}

// Widths when the layer is the primary choropleth layer
const LAYER_LINE_WIDTHS: Record<LayerName, number> = {
  seccion:           0.6,
  municipio:         1.6,
  distrito_federal:  2.0,
  distrito_local:    1.6,
  entidad:           2.5,
}

// Thicker widths for secondary overlay lines (drawn over a choropleth primary layer)
const LAYER_LINE_WIDTHS_OVERLAY: Record<LayerName, number> = {
  seccion:           0.6,
  municipio:         4.5,
  distrito_federal:  5.0,
  distrito_local:    4.5,
  entidad:           3.5,
}

// Layer join-key columns used to build the composite feature key for precomputed lookup
const LAYER_JOIN_KEYS: Record<LayerName, string[]> = {
  seccion:          ['ENTIDAD', 'SECCION'],
  municipio:        ['ENTIDAD', 'MUNICIPIO'],
  distrito_federal: ['ENTIDAD', 'DISTRITO_F'],
  distrito_local:   ['ENTIDAD', 'DISTRITO_L'],
  entidad:          ['ENTIDAD'],
}

export function MapView() {
  const mapContainer = useRef<HTMLDivElement>(null)
  const mapRef = useRef<maplibregl.Map | null>(null)
  const popupRef = useRef<maplibregl.Popup | null>(null)
  const hoverPopupRef = useRef<maplibregl.Popup | null>(null)
  const [mapReady, setMapReady] = useState(false)

  // Precomputed PCT lookup for secondary (overlay) layers.
  // Shape: { layerName → { featureKey → { PARTY_PCT: number } } }
  // Mutable ref — no re-render needed when updated.
  const precomputedRef = useRef<Record<string, Record<string, Record<string, number | null>>>>({})
  // Track active aborts for precomputed fetches
  const precomputedAbortRef = useRef<AbortController[]>([])

  const activeLayers              = useMapStore((s) => s.activeLayers)
  const layerOpacity              = useMapStore((s) => s.layerOpacity)
  const electionName              = useMapStore((s) => s.electionName)
  const partyFilter               = useMapStore((s) => s.partyFilter)
  const showLabels                = useMapStore((s) => s.showLabels)
  const selectedEntidad           = useMapStore((s) => s.selectedEntidad)
  const selectedMunicipio         = useMapStore((s) => s.selectedMunicipio)
  const selectedDistritoFederal   = useMapStore((s) => s.selectedDistritoFederal)
  const selectedDistritoLocal     = useMapStore((s) => s.selectedDistritoLocal)
  const showNationalSections      = useMapStore((s) => s.showNationalSections)
  const flyToBbox                 = useMapStore((s) => s.flyToBbox)
  const setSelectedEntidad        = useMapStore((s) => s.setSelectedEntidad)
  const setActiveView             = useMapStore((s) => s.setActiveView)
  const setFlyToBbox              = useMapStore((s) => s.setFlyToBbox)

  // Primary layer is always the first in activeLayers
  const primaryLayer = activeLayers[0] ?? 'seccion'
  // In national sections mode, always use seccion without an entidad filter
  const entidadIds = selectedEntidad != null ? [selectedEntidad] : undefined

  // Fetch electoral data when:
  //   • a state is selected (state mode), OR
  //   • national sections mode is active (uses seccion layer, no entidad filter)
  const { data: electoralData } = useElectoralLayer(
    primaryLayer,
    electionName,
    entidadIds,
    selectedEntidad != null || showNationalSections,
  )

  // ── Map initialisation ─────────────────────────────────────────
  useEffect(() => {
    if (!mapContainer.current) return

    const map = new maplibregl.Map({
      container: mapContainer.current,
      style: BASEMAP_STYLE,
      center: [-102, 23.5],
      zoom: 5,
    })

    map.addControl(new maplibregl.NavigationControl(), 'top-right')
    map.addControl(new maplibregl.ScaleControl(), 'bottom-right')

    popupRef.current = new maplibregl.Popup({
      closeButton: true,
      maxWidth: '300px',
    })

    hoverPopupRef.current = new maplibregl.Popup({
      closeButton: false,
      closeOnClick: false,
      maxWidth: '200px',
      offset: 6,
    })

    map.on('load', () => {
      // ── National entidad outline layers (shown in national mode) ──
      map.addSource('entidad-national-src', { type: 'geojson', data: EMPTY_FC })

      // Transparent fill layer — captures click events in national mode
      map.addLayer({
        id: 'entidad-national-fill',
        type: 'fill',
        source: 'entidad-national-src',
        layout: { visibility: 'visible' },
        paint: {
          'fill-color': '#f0f4f8',
          'fill-opacity': 0.5,
        },
      })

      // State border lines
      map.addLayer({
        id: 'entidad-national-line',
        type: 'line',
        source: 'entidad-national-src',
        layout: { visibility: 'visible' },
        paint: {
          'line-color': '#1A3A52',
          'line-width': 1.8,
          'line-opacity': 0.85,
        },
      })

      // State name labels (centroid points)
      map.addSource('entidad-national-labels-src', { type: 'geojson', data: EMPTY_FC })
      map.addLayer({
        id: 'entidad-national-labels',
        type: 'symbol',
        source: 'entidad-national-labels-src',
        layout: {
          'text-field': ['get', 'label'],
          'text-size': ['interpolate', ['linear'], ['zoom'], 4, 10, 7, 13],
          'text-font': ['Open Sans Regular'],
          'text-padding': 4,
          'text-allow-overlap': false,
          visibility: 'visible',
        },
        paint: {
          'text-color': '#1A3A52',
          'text-halo-color': '#ffffff',
          'text-halo-width': 2,
        },
      })

      // ── Data layer sources + fill/line pairs ─────────────────
      for (const name of DATA_LAYERS) {
        map.addSource(`${name}-src`, { type: 'geojson', data: EMPTY_FC })

        // Fill (for primary choropleth)
        map.addLayer({
          id: `${name}-fill`,
          type: 'fill',
          source: `${name}-src`,
          layout: { visibility: 'none' },
          paint: {
            'fill-color': '#cccccc',
            'fill-opacity': 0.75,
          },
        })

        // Line (border for all active layers)
        map.addLayer({
          id: `${name}-line`,
          type: 'line',
          source: `${name}-src`,
          layout: { visibility: 'none' },
          paint: {
            'line-color': LAYER_LINE_COLORS[name],
            'line-width': LAYER_LINE_WIDTHS[name],
            'line-opacity': 0.85,
          },
        })
      }

      // ── State highlight (entidad border in state mode) ────────
      map.addSource('entidad-highlight-src', { type: 'geojson', data: EMPTY_FC })
      map.addLayer({
        id: 'entidad-highlight-fill',
        type: 'fill',
        source: 'entidad-highlight-src',
        layout: { visibility: 'none' },
        paint: {
          'fill-color': '#1A3A52',
          'fill-opacity': 0.12,
        },
      })
      map.addLayer({
        id: 'entidad-highlight-line',
        type: 'line',
        source: 'entidad-highlight-src',
        layout: { visibility: 'none' },
        paint: {
          'line-color': LAYER_LINE_COLORS.entidad,
          'line-width': LAYER_LINE_WIDTHS.entidad,
          'line-opacity': 1,
        },
      })

      // ── Labels (state-mode layer labels) ────────────────────
      map.addSource('labels-src', { type: 'geojson', data: EMPTY_FC })
      map.addLayer({
        id: 'labels-symbols',
        type: 'symbol',
        source: 'labels-src',
        layout: {
          'text-field': ['get', 'label'],
          'text-size': ['interpolate', ['linear'], ['zoom'], 6, 9, 12, 14],
          'text-font': ['Open Sans Regular'],
          'text-padding': 2,
          'text-allow-overlap': false,
          visibility: 'none',
        },
        paint: {
          'text-color': '#222',
          'text-halo-color': '#fff',
          'text-halo-width': 1.5,
        },
      })

      // ── Click: national entidad fill → select state ───────────
      map.on('click', 'entidad-national-fill', (e) => {
        if (!e.features?.length) return
        const props = e.features[0].properties as Record<string, unknown>
        const entidad = props['ENTIDAD'] as number | undefined
        if (entidad != null) {
          setSelectedEntidad(Number(entidad))
          setActiveView('map')
        }
      })

      // ── Hover: national entidad fill → show state name ────────
      map.on('mousemove', 'entidad-national-fill', (e) => {
        if (!e.features?.length) return
        map.getCanvas().style.cursor = 'pointer'
        const props = e.features[0].properties as Record<string, unknown>
        const nombre = props['NOMBRE'] as string | undefined
        if (nombre) {
          hoverPopupRef.current
            ?.setLngLat(e.lngLat)
            .setHTML(`<span style="font-size:13px;font-weight:600;color:#1A3A52">${nombre}</span>`)
            .addTo(map)
        }
      })
      map.on('mouseleave', 'entidad-national-fill', () => {
        map.getCanvas().style.cursor = ''
        hoverPopupRef.current?.remove()
      })

      // ── Unified click: finds finest-grain layer at click point ──
      // queryRenderedFeatures detects hits across all data layer fills,
      // including secondary fills kept at near-zero opacity for detection.
      const CLICK_PRIORITY: LayerName[] = [
        'seccion', 'municipio', 'distrito_local', 'distrito_federal',
      ]

      map.on('click', (e) => {
        const allFillIds = DATA_LAYERS.map((l) => `${l}-fill`)
        const features = map.queryRenderedFeatures(e.point, { layers: allFillIds })
        if (!features.length) return

        // Pick finest-grain layer that has a hit
        let clickedFeat: maplibregl.MapGeoJSONFeature | null = null
        let clickedLayer: LayerName | null = null
        for (const priority of CLICK_PRIORITY) {
          const f = features.find((f) => f.layer.id === `${priority}-fill`)
          if (f) { clickedFeat = f; clickedLayer = priority; break }
        }
        if (!clickedFeat || !clickedLayer) return

        const props = clickedFeat.properties as Record<string, unknown>

        // Select state
        const entidad = props['ENTIDAD'] as number | undefined
        if (entidad != null) setSelectedEntidad(Number(entidad))

        // Build popup title
        let title: string
        if (clickedLayer === 'seccion') {
          title = `Sección ${props['SECCION'] ?? ''}`
        } else if (clickedLayer === 'municipio') {
          const nombre = props['NOMBRE'] as string | undefined
          title = nombre
            ? `Municipio ${props['MUNICIPIO']} — ${nombre}`
            : `Municipio ${props['MUNICIPIO'] ?? ''}`
        } else if (clickedLayer === 'distrito_federal') {
          title = `Dto. Federal ${props['DISTRITO_F'] ?? ''}`
        } else if (clickedLayer === 'distrito_local') {
          title = `Dto. Local ${props['DISTRITO_L'] ?? ''}`
        } else {
          title = String(clickedLayer)
        }

        // Build the composite feature key for the precomputed lookup
        const joinKeys = LAYER_JOIN_KEYS[clickedLayer]
        const featureKey = joinKeys.map((k) => String(props[k] ?? '')).join('_')

        // Get PCT data: prefer precomputed cache (populated for all active layers),
        // fall back to properties embedded in the feature by the electoral-join response.
        const precomputedPct = precomputedRef.current[clickedLayer]?.[featureKey]
        let pctData: Record<string, number | null | undefined>

        if (precomputedPct && Object.keys(precomputedPct).length > 0) {
          pctData = precomputedPct
        } else {
          // Fallback: read _PCT directly from feature properties
          pctData = Object.fromEntries(
            Object.entries(props).filter(([k]) => k.endsWith('_PCT')),
          ) as Record<string, number>
        }

        const html = buildChartHTML(title, pctData)
        if (html) {
          popupRef.current?.setLngLat(e.lngLat).setHTML(html).addTo(map)
        }
      })

      // Cursor: pointer when over any active data fill
      map.on('mousemove', (e) => {
        const allFillIds = DATA_LAYERS.map((l) => `${l}-fill`)
        const hits = map.queryRenderedFeatures(e.point, { layers: allFillIds })
        map.getCanvas().style.cursor = hits.length ? 'pointer' : ''
      })

      setMapReady(true)
    })

    mapRef.current = map
    return () => {
      map.remove()
      mapRef.current = null
      setMapReady(false)
    }
  }, [])

  // ── Load national entidad outlines + labels (once on map ready) ──
  useEffect(() => {
    const map = mapRef.current
    if (!map || !mapReady) return

    Promise.all([
      fetchLayer('entidad'),
      fetchLayerLabels('entidad'),
    ]).then(([geojson, labels]) => {
      if (!mapRef.current) return
      ;(map.getSource('entidad-national-src') as maplibregl.GeoJSONSource | undefined)?.setData(geojson)
      ;(map.getSource('entidad-national-labels-src') as maplibregl.GeoJSONSource | undefined)?.setData(labels)
    }).catch(console.error)
  }, [mapReady])

  // ── Update primary electoral data source ───────────────────────
  useEffect(() => {
    const map = mapRef.current
    if (!map || !mapReady || !electoralData) return
    const src = map.getSource(`${primaryLayer}-src`) as maplibregl.GeoJSONSource | undefined
    src?.setData(electoralData as GeoJSON.FeatureCollection)
  }, [mapReady, electoralData, primaryLayer])

  // ── Update choropleth fill expression ──────────────────────────
  useEffect(() => {
    const map = mapRef.current
    if (!map || !mapReady) return
    const features = electoralData?.features ?? []
    const pctCols = getPctColumns(features)
    const colorExpr = partyFilter
      ? buildSinglePartyExpression(`${partyFilter}_PCT`, PARTY_COLORS[partyFilter] ?? '#1B9A8E')
      : buildWinnerExpression(pctCols)
    if (map.getLayer(`${primaryLayer}-fill`)) {
      map.setPaintProperty(`${primaryLayer}-fill`, 'fill-color', colorExpr as maplibregl.ExpressionSpecification)
    }
  }, [mapReady, electoralData, partyFilter, primaryLayer])

  // ── Update opacity ─────────────────────────────────────────────
  useEffect(() => {
    const map = mapRef.current
    if (!map || !mapReady) return
    if (map.getLayer(`${primaryLayer}-fill`)) {
      map.setPaintProperty(`${primaryLayer}-fill`, 'fill-opacity', layerOpacity)
    }
  }, [mapReady, layerOpacity, primaryLayer])

  // ── State selection: fly to bounds + highlight + secondary layers
  useEffect(() => {
    const map = mapRef.current
    if (!map || !mapReady) return

    const highlightFillSrc = map.getSource('entidad-highlight-src') as maplibregl.GeoJSONSource | undefined

    if (selectedEntidad == null) {
      // ── National mode ──────────────────────────────────────
      highlightFillSrc?.setData(EMPTY_FC)
      map.setLayoutProperty('entidad-highlight-fill', 'visibility', 'none')
      map.setLayoutProperty('entidad-highlight-line', 'visibility', 'none')

      // Clear all secondary layer sources
      for (const name of DATA_LAYERS) {
        if (name !== primaryLayer) {
          const src = map.getSource(`${name}-src`) as maplibregl.GeoJSONSource | undefined
          src?.setData(EMPTY_FC)
        }
      }

      map.flyTo({ center: [-102, 23.5], zoom: 5, duration: 1200 })
    } else {
      // ── State mode ─────────────────────────────────────────
      fetchLayer('entidad', selectedEntidad).then((geojson) => {
        if (!mapRef.current) return
        highlightFillSrc?.setData(geojson)
        map.setLayoutProperty('entidad-highlight-fill', 'visibility', 'visible')
        map.setLayoutProperty('entidad-highlight-line', 'visibility', 'visible')

        const bbox = computeBBox(geojson)
        if (bbox[0] !== Infinity) {
          map.fitBounds(bbox as maplibregl.LngLatBoundsLike, {
            padding: { top: 60, bottom: 60, left: 60, right: 60 },
            maxZoom: 11,
            duration: 1000,
          })
        }
      }).catch(console.error)

      // Fetch secondary layers (line overlays)
      const secondary = activeLayers.filter((l) => l !== primaryLayer)
      for (const name of secondary) {
        fetchLayer(name, selectedEntidad)
          .then((geojson) => {
            if (!mapRef.current) return
            const src = map.getSource(`${name}-src`) as maplibregl.GeoJSONSource | undefined
            src?.setData(geojson)
          })
          .catch(console.error)
      }
    }
  // eslint-disable-next-line react-hooks/exhaustive-deps
  }, [mapReady, selectedEntidad])

  // ── When activeLayers changes in state mode, fetch new secondaries
  useEffect(() => {
    const map = mapRef.current
    if (!map || !mapReady || selectedEntidad == null) return

    const secondary = activeLayers.filter((l) => l !== primaryLayer)
    for (const name of secondary) {
      fetchLayer(name, selectedEntidad)
        .then((geojson) => {
          if (!mapRef.current) return
          const src = map.getSource(`${name}-src`) as maplibregl.GeoJSONSource | undefined
          src?.setData(geojson)
        })
        .catch(console.error)
    }
  // eslint-disable-next-line react-hooks/exhaustive-deps
  }, [mapReady, activeLayers.join(','), primaryLayer])

  // ── Layer visibility based on activeLayers + state mode ────────
  useEffect(() => {
    const map = mapRef.current
    if (!map || !mapReady) return

    const inNationalMode     = selectedEntidad == null
    const inNationalSections = inNationalMode && showNationalSections

    // National entidad outline layers
    // In national-sections mode: keep state border lines for reference,
    // but hide the transparent fill (so seccion clicks work) and labels.
    map.setLayoutProperty(
      'entidad-national-fill',
      'visibility',
      inNationalMode && !inNationalSections ? 'visible' : 'none',
    )
    map.setLayoutProperty(
      'entidad-national-line',
      'visibility',
      inNationalMode ? 'visible' : 'none',
    )
    map.setLayoutProperty(
      'entidad-national-labels',
      'visibility',
      inNationalMode && !inNationalSections ? 'visible' : 'none',
    )

    // Data layers
    for (const name of DATA_LAYERS) {
      const isActive = activeLayers.includes(name)
      const isPrimary = name === primaryLayer

      if (inNationalSections) {
        // National sections mode: only seccion fill + line visible
        if (name === 'seccion') {
          map.setLayoutProperty('seccion-fill', 'visibility', 'visible')
          map.setPaintProperty('seccion-fill', 'fill-opacity', layerOpacity)
          map.setLayoutProperty('seccion-line', 'visibility', 'visible')
          map.setPaintProperty('seccion-line', 'line-width', LAYER_LINE_WIDTHS['seccion'])
        } else {
          map.setLayoutProperty(`${name}-fill`, 'visibility', 'none')
          map.setLayoutProperty(`${name}-line`, 'visibility', 'none')
        }
      } else if (!isActive || inNationalMode) {
        map.setLayoutProperty(`${name}-fill`, 'visibility', 'none')
        map.setLayoutProperty(`${name}-line`, 'visibility', 'none')
      } else {
        // State mode: primary = choropleth; secondary = near-zero fill (queryable) + thick line
        map.setLayoutProperty(`${name}-fill`, 'visibility', 'visible')
        map.setPaintProperty(
          `${name}-fill`,
          'fill-opacity',
          isPrimary ? layerOpacity : 0.001,
        )
        map.setLayoutProperty(`${name}-line`, 'visibility', 'visible')

        // When an area (municipio / distrito) is selected, use zoom-interpolated
        // seccion line width so boundaries are clearly visible when zoomed in.
        const areaSelected = selectedMunicipio != null || selectedDistritoFederal != null || selectedDistritoLocal != null
        let lineWidth: number | maplibregl.ExpressionSpecification
        if (isPrimary) {
          lineWidth = (name === 'seccion' && areaSelected)
            ? ['interpolate', ['linear'], ['zoom'], 10, 1.0, 13, 1.8, 16, 2.5] as maplibregl.ExpressionSpecification
            : LAYER_LINE_WIDTHS[name]
        } else {
          lineWidth = LAYER_LINE_WIDTHS_OVERLAY[name]
        }
        map.setPaintProperty(`${name}-line`, 'line-width', lineWidth)
      }
    }
  }, [mapReady, activeLayers.join(','), primaryLayer, selectedEntidad, selectedMunicipio, selectedDistritoFederal, selectedDistritoLocal, showNationalSections, layerOpacity])

  // ── Labels toggle (state-mode layer labels) ────────────────────
  useEffect(() => {
    const map = mapRef.current
    if (!map || !mapReady) return
    map.setLayoutProperty('labels-symbols', 'visibility', showLabels ? 'visible' : 'none')
  }, [mapReady, showLabels])

  // ── When any area selection is cleared, zoom back to state bounds ──
  const prevMunicipioRef       = useRef<number | null>(null)
  const prevDistritoFedRef     = useRef<number | null>(null)
  const prevDistritoLocalRef   = useRef<number | null>(null)
  useEffect(() => {
    const prevMuni  = prevMunicipioRef.current
    const prevFed   = prevDistritoFedRef.current
    const prevLocal = prevDistritoLocalRef.current
    prevMunicipioRef.current     = selectedMunicipio
    prevDistritoFedRef.current   = selectedDistritoFederal
    prevDistritoLocalRef.current = selectedDistritoLocal

    const wasAreaSelected = prevMuni != null || prevFed != null || prevLocal != null
    const isAreaSelected  = selectedMunicipio != null || selectedDistritoFederal != null || selectedDistritoLocal != null

    if (wasAreaSelected && !isAreaSelected && selectedEntidad != null) {
      const map = mapRef.current
      if (!map || !mapReady) return
      fetchLayer('entidad', selectedEntidad).then((geojson) => {
        if (!mapRef.current) return
        const bbox = computeBBox(geojson as GeoJSON.FeatureCollection)
        if (bbox[0] !== Infinity) {
          mapRef.current.fitBounds(bbox as maplibregl.LngLatBoundsLike, {
            padding: { top: 60, bottom: 60, left: 60, right: 60 },
            maxZoom: 11,
            duration: 900,
          })
        }
      }).catch(console.error)
    }
  }, [mapReady, selectedMunicipio, selectedDistritoFederal, selectedDistritoLocal, selectedEntidad])

  // ── Area filter: isolate secciones + boundary of the selected area ──
  // Applies when municipio, distrito_federal, or distrito_local is selected.
  // Filters both the seccion fill/line and the relevant boundary layer.
  useEffect(() => {
    const map = mapRef.current
    if (!map || !mapReady) return

    // Seccion filter — based on whichever area type is selected
    let seccionFilter: maplibregl.FilterSpecification | null = null
    if (selectedMunicipio != null) {
      seccionFilter = ['==', ['get', 'MUNICIPIO'], selectedMunicipio]
    } else if (selectedDistritoFederal != null) {
      seccionFilter = ['==', ['get', 'DISTRITO_F'], selectedDistritoFederal]
    } else if (selectedDistritoLocal != null) {
      seccionFilter = ['==', ['get', 'DISTRITO_L'], selectedDistritoLocal]
    }

    for (const id of ['seccion-fill', 'seccion-line']) {
      if (map.getLayer(id)) map.setFilter(id, seccionFilter)
    }

    // Municipio boundary filter
    const muniFilter: maplibregl.FilterSpecification | null =
      selectedMunicipio != null ? ['==', ['get', 'MUNICIPIO'], selectedMunicipio] : null
    for (const id of ['municipio-fill', 'municipio-line']) {
      if (map.getLayer(id)) map.setFilter(id, muniFilter)
    }

    // Distrito Federal boundary filter
    const fedFilter: maplibregl.FilterSpecification | null =
      selectedDistritoFederal != null ? ['==', ['get', 'DISTRITO_F'], selectedDistritoFederal] : null
    for (const id of ['distrito_federal-fill', 'distrito_federal-line']) {
      if (map.getLayer(id)) map.setFilter(id, fedFilter)
    }

    // Distrito Local boundary filter
    const localFilter: maplibregl.FilterSpecification | null =
      selectedDistritoLocal != null ? ['==', ['get', 'DISTRITO_L'], selectedDistritoLocal] : null
    for (const id of ['distrito_local-fill', 'distrito_local-line']) {
      if (map.getLayer(id)) map.setFilter(id, localFilter)
    }
  }, [mapReady, selectedMunicipio, selectedDistritoFederal, selectedDistritoLocal])

  // ── Fly to municipality bbox ───────────────────────────────────
  useEffect(() => {
    const map = mapRef.current
    if (!map || !mapReady || !flyToBbox) return
    map.fitBounds(flyToBbox as maplibregl.LngLatBoundsLike, {
      padding: { top: 16, bottom: 16, left: 16, right: 16 },
      maxZoom: 15,
      duration: 800,
    })
    setFlyToBbox(null)
  }, [mapReady, flyToBbox])

  // ── Fetch precomputed PCT data for ALL active layers ──────────
  // Stored in a mutable ref (no re-render) and used by the click handler
  // to show charts for any clicked layer (primary or secondary overlay).
  // Fetching for all layers (not just secondary) ensures the chart works
  // even when the primary layer source was previously set with geometry-only
  // data (i.e. before the electoral-join response arrives).
  useEffect(() => {
    if (selectedEntidad == null || !electionName) {
      precomputedRef.current = {}
      return
    }
    ;(activeLayers as LayerName[]).forEach((layerName) => {
      fetchPrecomputedElectoral(layerName, electionName, selectedEntidad)
        .then((data) => {
          precomputedRef.current = { ...precomputedRef.current, [layerName]: data }
        })
        .catch(() => { /* silently ignore — chart shows empty for this layer */ })
    })
  // eslint-disable-next-line react-hooks/exhaustive-deps
  }, [selectedEntidad, electionName, activeLayers.join(','), primaryLayer])

  return (
    <div className="map-wrapper">
      <div ref={mapContainer} className="map-container" />
      <PartyLegend />
    </div>
  )
}
