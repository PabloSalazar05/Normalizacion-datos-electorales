import { PARTY_COLORS, MAJOR_PARTIES } from '../../utils/partyColors'
import { useMapStore } from '../../store/mapStore'
import './PartyLegend.css'

export function PartyLegend() {
  const partyFilter = useMapStore((s) => s.partyFilter)
  const setPartyFilter = useMapStore((s) => s.setPartyFilter)

  return (
    <div className="party-legend">
      <div className="legend-title">
        {partyFilter ? `Votos ${partyFilter}` : 'Ganador por partido'}
      </div>
      <div className="legend-items">
        {MAJOR_PARTIES.map((party) => (
          <button
            key={party}
            className={`legend-item ${partyFilter === party ? 'active' : ''}`}
            onClick={() => setPartyFilter(partyFilter === party ? null : party)}
            title={`Mostrar coropleta de ${party}`}
          >
            <span
              className="legend-swatch"
              style={{ background: PARTY_COLORS[party] }}
            />
            <span className="legend-label">{party}</span>
          </button>
        ))}
      </div>
      {partyFilter && (
        <div className="legend-gradient">
          <span>0%</span>
          <div
            className="legend-gradient-bar"
            style={{
              background: `linear-gradient(to right, #fff, ${PARTY_COLORS[partyFilter]})`,
            }}
          />
          <span>100%</span>
        </div>
      )}
    </div>
  )
}
