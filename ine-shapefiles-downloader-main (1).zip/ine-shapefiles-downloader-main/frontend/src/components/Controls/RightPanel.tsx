import { useEffect, useState } from 'react'
import { useMapStore } from '../../store/mapStore'
import { fetchLayerConfig } from '../../api/layersApi'
import { fetchElections } from '../../api/electionsApi'
import type { LayerName, LayersConfigResponse } from '../../types/layers'
import { MAJOR_PARTIES } from '../../utils/partyColors'
import './RightPanel.css'

// Layers available as overlays (exclude entidad — shown automatically as highlight)
const OVERLAY_LAYERS: LayerName[] = ['seccion', 'municipio', 'distrito_federal', 'distrito_local']

export function RightPanel() {
  const activeLayers            = useMapStore((s) => s.activeLayers)
  const layerOpacity            = useMapStore((s) => s.layerOpacity)
  const showLabels              = useMapStore((s) => s.showLabels)
  const electionName            = useMapStore((s) => s.electionName)
  const partyFilter             = useMapStore((s) => s.partyFilter)
  const selectedEntidad         = useMapStore((s) => s.selectedEntidad)
  const selectedMunicipio       = useMapStore((s) => s.selectedMunicipio)
  const selectedDistritoFederal = useMapStore((s) => s.selectedDistritoFederal)
  const selectedDistritoLocal   = useMapStore((s) => s.selectedDistritoLocal)

  const showNationalSections    = useMapStore((s) => s.showNationalSections)
  const setShowNationalSections = useMapStore((s) => s.setShowNationalSections)

  const toggleLayer    = useMapStore((s) => s.toggleLayer)
  const setLayerOpacity = useMapStore((s) => s.setLayerOpacity)
  const setShowLabels  = useMapStore((s) => s.setShowLabels)
  const setElectionName = useMapStore((s) => s.setElectionName)
  const setPartyFilter = useMapStore((s) => s.setPartyFilter)

  const [layerConfig, setLayerConfig] = useState<LayersConfigResponse | null>(null)
  const [elections, setElections] = useState<string[]>([])

  useEffect(() => {
    fetchLayerConfig().then(setLayerConfig).catch(console.error)
    fetchElections()
      .then((data) => setElections([...new Set(data.map((e) => e.election_name))]))
      .catch(console.error)
  }, [])

  const layerDisplayNames = layerConfig?.layers ?? ({} as Partial<Record<LayerName, { display_name: string }>>)

  // When an area is selected from the sidebar, restrict visible layer choices
  // to only the relevant pair: sección + the selected area type.
  const visibleOverlayLayers: LayerName[] =
    selectedMunicipio != null       ? ['seccion', 'municipio'] :
    selectedDistritoFederal != null ? ['seccion', 'distrito_federal'] :
    selectedDistritoLocal != null   ? ['seccion', 'distrito_local'] :
    OVERLAY_LAYERS

  return (
    <div className="right-panel">

      {/* ── Vista nacional: secciones electorales ────────────────── */}
      {!selectedEntidad && (
        <section className="panel-section">
          <h4 className="section-title">Vista nacional</h4>
          <button
            className={`national-sections-btn ${showNationalSections ? 'active' : ''}`}
            onClick={() => setShowNationalSections(!showNationalSections)}
          >
            {showNationalSections ? 'Ocultar secciones' : 'Ver secciones electorales'}
          </button>
          {showNationalSections && (
            <p className="layer-note" style={{ marginTop: 8, marginBottom: 0 }}>
              Secciones coloreadas por partido ganador a nivel nacional.
            </p>
          )}
        </section>
      )}

      {/* ── Elección ─────────────────────────────────────────────── */}
      <section className="panel-section">
        <h4 className="section-title">Elección</h4>
        <select
          className="panel-select"
          value={electionName}
          onChange={(e) => setElectionName(e.target.value)}
        >
          {elections.length === 0 && (
            <option value={electionName}>{electionName}</option>
          )}
          {elections.map((name) => (
            <option key={name} value={name}>{name}</option>
          ))}
        </select>
      </section>

      {/* ── Partido ──────────────────────────────────────────────── */}
      <section className="panel-section">
        <h4 className="section-title">Partido</h4>
        <div className="party-buttons">
          <button
            className={`party-btn ${partyFilter === null ? 'active' : ''}`}
            onClick={() => setPartyFilter(null)}
          >
            Ganador
          </button>
          {MAJOR_PARTIES.map((p) => (
            <button
              key={p}
              className={`party-btn ${partyFilter === p ? 'active' : ''}`}
              onClick={() => setPartyFilter(partyFilter === p ? null : p)}
            >
              {p}
            </button>
          ))}
        </div>
      </section>

      {/* ── Capas geográficas ────────────────────────────────────── */}
      <section className="panel-section">
        <h4 className="section-title">
          Capas geográficas
          {selectedEntidad && (
            <span className="section-hint"> — estado seleccionado</span>
          )}
        </h4>

        {!selectedEntidad && (
          <p className="layer-note">
            Selecciona un estado para activar varias capas simultáneamente.
          </p>
        )}

        <div className="layer-checklist">
          {visibleOverlayLayers.map((name) => {
            const cfg = layerDisplayNames[name]
            const isChecked = activeLayers.includes(name)
            const isPrimary = activeLayers[0] === name
            const disabled = !selectedEntidad && name !== 'seccion'

            return (
              <label
                key={name}
                className={`layer-check-row ${disabled ? 'disabled' : ''} ${isChecked ? 'checked' : ''}`}
              >
                <span className={`layer-dot layer-dot-${name}`} />
                <input
                  type="checkbox"
                  checked={isChecked}
                  disabled={disabled}
                  onChange={() => toggleLayer(name)}
                  className="layer-checkbox"
                />
                <span className="layer-check-label">
                  {cfg?.display_name ?? name}
                </span>
                {isPrimary && isChecked && (
                  <span className="primary-badge">principal</span>
                )}
              </label>
            )
          })}
        </div>

        <div className="opacity-row">
          <span className="opacity-label">Opacidad</span>
          <input
            type="range"
            min={0.1}
            max={1}
            step={0.05}
            value={layerOpacity}
            onChange={(e) => setLayerOpacity(Number(e.target.value))}
            className="opacity-slider"
          />
          <span className="opacity-value">{Math.round(layerOpacity * 100)}%</span>
        </div>
      </section>

      {/* ── Etiquetas ────────────────────────────────────────────── */}
      <section className="panel-section">
        <label className="toggle-row">
          <input
            type="checkbox"
            checked={showLabels}
            onChange={(e) => setShowLabels(e.target.checked)}
          />
          Mostrar etiquetas
        </label>
      </section>

    </div>
  )
}
