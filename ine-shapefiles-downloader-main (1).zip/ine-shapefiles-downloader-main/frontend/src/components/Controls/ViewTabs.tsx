import { useMapStore } from '../../store/mapStore'
import type { ActiveView } from '../../store/mapStore'
import './ViewTabs.css'

const TABS: { id: ActiveView; label: string; requiresState: boolean }[] = [
  { id: 'map',     label: 'Mapa Electoral',  requiresState: false },
  { id: 'morans',  label: "Moran's I",       requiresState: true  },
  { id: 'lisa',    label: 'LISA Clusters',   requiresState: true  },
  { id: 'density', label: 'Densidad',        requiresState: false },
  { id: 'layers',  label: 'Capas de Trabajo', requiresState: false },
]

export function ViewTabs() {
  const activeView      = useMapStore((s) => s.activeView)
  const setActiveView   = useMapStore((s) => s.setActiveView)
  const selectedEntidad = useMapStore((s) => s.selectedEntidad)

  return (
    <div className="view-tabs-bar">
      {TABS.map((tab) => {
        const disabled = tab.requiresState && selectedEntidad == null
        return (
          <button
            key={tab.id}
            className={`view-tab-btn ${activeView === tab.id ? 'active' : ''} ${disabled ? 'disabled' : ''}`}
            onClick={() => { if (!disabled) setActiveView(tab.id) }}
            disabled={disabled}
            title={disabled ? 'Selecciona un estado para activar este análisis' : undefined}
          >
            {tab.label}
          </button>
        )
      })}
    </div>
  )
}
