import type { LayerStatus } from '../../types/layers'
import './LayerLoadingScreen.css'

interface Props {
  progress: LayerStatus['progress']
}

export function LayerLoadingScreen({ progress }: Props) {
  const pct = progress.total > 0
    ? Math.round((progress.processed / progress.total) * 100)
    : 0

  return (
    <div className="loading-screen">
      <div className="loading-card">
        <img src="/labexandria-logo.png" alt="Labexandria" className="loading-logo-img" />
        <p className="loading-subtitle">Cargando capas geográficas…</p>

        <div className="progress-bar-track">
          <div
            className="progress-bar-fill"
            style={{ width: `${pct}%` }}
          />
        </div>

        <p className="loading-pct">{pct}%</p>
        <p className="loading-detail">
          {progress.processed} / {progress.total} layers processed
        </p>
      </div>
    </div>
  )
}
