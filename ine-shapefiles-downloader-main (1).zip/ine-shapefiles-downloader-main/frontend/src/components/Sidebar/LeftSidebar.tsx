import { useEffect, useRef, useState } from 'react'
import { useMapStore } from '../../store/mapStore'
import { fetchLayer } from '../../api/layersApi'
import { computeBBox } from '../../utils/geo'
import './LeftSidebar.css'

const STATES: [number, string][] = [
  [1,  'Aguascalientes'],
  [2,  'Baja California'],
  [3,  'Baja California Sur'],
  [4,  'Campeche'],
  [5,  'Coahuila'],
  [6,  'Colima'],
  [7,  'Chiapas'],
  [8,  'Chihuahua'],
  [9,  'Ciudad de México'],
  [10, 'Durango'],
  [11, 'Guanajuato'],
  [12, 'Guerrero'],
  [13, 'Hidalgo'],
  [14, 'Jalisco'],
  [15, 'Estado de México'],
  [16, 'Michoacán'],
  [17, 'Morelos'],
  [18, 'Nayarit'],
  [19, 'Nuevo León'],
  [20, 'Oaxaca'],
  [21, 'Puebla'],
  [22, 'Querétaro'],
  [23, 'Quintana Roo'],
  [24, 'San Luis Potosí'],
  [25, 'Sinaloa'],
  [26, 'Sonora'],
  [27, 'Tabasco'],
  [28, 'Tamaulipas'],
  [29, 'Tlaxcala'],
  [30, 'Veracruz'],
  [31, 'Yucatán'],
  [32, 'Zacatecas'],
]

interface MunicipioOption {
  id: number
  name: string
  feature: GeoJSON.Feature
}

interface DistritoOption {
  id: number
  feature: GeoJSON.Feature
}

type ExpandedSection = 'municipio' | 'distrito_federal' | 'distrito_local' | null

export function LeftSidebar() {
  const selectedEntidad              = useMapStore((s) => s.selectedEntidad)
  const setSelectedEntidad           = useMapStore((s) => s.setSelectedEntidad)
  const selectedMunicipio            = useMapStore((s) => s.selectedMunicipio)
  const selectedDistritoFederalStore = useMapStore((s) => s.selectedDistritoFederal)
  const selectedDistritoLocalStore   = useMapStore((s) => s.selectedDistritoLocal)
  const setFlyToBbox                 = useMapStore((s) => s.setFlyToBbox)
  const setSelectedMunicipio         = useMapStore((s) => s.setSelectedMunicipio)
  const setSelectedMunicipioBbox     = useMapStore((s) => s.setSelectedMunicipioBbox)
  const setSelectedDistritoFederal   = useMapStore((s) => s.setSelectedDistritoFederal)
  const setSelectedDistritoLocal     = useMapStore((s) => s.setSelectedDistritoLocal)
  const setActiveLayers              = useMapStore((s) => s.setActiveLayers)

  const [municipalities, setMunicipalities]           = useState<MunicipioOption[]>([])
  const [distritosFederales, setDistritosFederales]   = useState<DistritoOption[]>([])
  const [distritosLocales, setDistritosLocales]       = useState<DistritoOption[]>([])

  const [selectedMunicipioId, setSelectedMunicipioId]         = useState<number | null>(null)
  const [selectedDistritoFedId, setSelectedDistritoFedId]     = useState<number | null>(null)
  const [selectedDistritoLocalId, setSelectedDistritoLocalId] = useState<number | null>(null)

  const [searchText, setSearchText]       = useState('')
  const [showSuggestions, setShowSuggestions] = useState(false)
  const [expandedSection, setExpandedSection] = useState<ExpandedSection>(null)

  const searchRef = useRef<HTMLInputElement>(null)

  const selectedStateName = STATES.find(([id]) => id === selectedEntidad)?.[1] ?? ''

  // Fetch all area layers whenever state changes
  useEffect(() => {
    if (selectedEntidad == null) {
      setMunicipalities([])
      setDistritosFederales([])
      setDistritosLocales([])
      setSelectedMunicipioId(null)
      setSelectedDistritoFedId(null)
      setSelectedDistritoLocalId(null)
      setSearchText('')
      setExpandedSection(null)
      return
    }
    setSelectedMunicipioId(null)
    setSelectedDistritoFedId(null)
    setSelectedDistritoLocalId(null)
    setSearchText('')
    setExpandedSection(null)

    fetchLayer('municipio', selectedEntidad)
      .then((geojson) => {
        const list = geojson.features
          .map((f) => {
            const props = f.properties as Record<string, unknown>
            return {
              id: Number(props['MUNICIPIO']),
              name: String(props['NOMBRE'] ?? props['MUNICIPIO'] ?? ''),
              feature: f,
            }
          })
          .filter((m) => !isNaN(m.id))
          .sort((a, b) => a.name.localeCompare(b.name, 'es'))
        setMunicipalities(list)
      })
      .catch(console.error)

    fetchLayer('distrito_federal', selectedEntidad)
      .then((geojson) => {
        const list = geojson.features
          .map((f) => {
            const props = f.properties as Record<string, unknown>
            const num = Number(props['DISTRITO_F'] ?? props['distrito_f'] ?? 0)
            return { id: num, feature: f }
          })
          .filter((d) => !isNaN(d.id) && d.id > 0)
          .sort((a, b) => a.id - b.id)
        setDistritosFederales(list)
      })
      .catch(console.error)

    fetchLayer('distrito_local', selectedEntidad)
      .then((geojson) => {
        const list = geojson.features
          .map((f) => {
            const props = f.properties as Record<string, unknown>
            const num = Number(props['DISTRITO_L'] ?? props['distrito_l'] ?? 0)
            return { id: num, feature: f }
          })
          .filter((d) => !isNaN(d.id) && d.id > 0)
          .sort((a, b) => a.id - b.id)
        setDistritosLocales(list)
      })
      .catch(console.error)
  }, [selectedEntidad])

  // Focus search input when municipio section expands
  useEffect(() => {
    if (expandedSection === 'municipio') {
      setTimeout(() => searchRef.current?.focus(), 50)
    }
  }, [expandedSection])

  const selectMunicipio = (muni: MunicipioOption) => {
    setSelectedMunicipioId(muni.id)
    setSelectedDistritoFedId(null)
    setSelectedDistritoLocalId(null)
    setSearchText(muni.name)
    setShowSuggestions(false)
    const bbox = computeBBox(muni.feature)
    if (bbox[0] !== Infinity) {
      setFlyToBbox(bbox)
      setSelectedMunicipioBbox(bbox)
    }
    setSelectedMunicipio(muni.id)
    setActiveLayers(['seccion', 'municipio'])
  }

  const selectDistritoFederal = (d: DistritoOption) => {
    setSelectedDistritoFedId(d.id)
    setSelectedDistritoLocalId(null)
    setSelectedMunicipioId(null)
    setSearchText('')
    setSelectedDistritoFederal(d.id)
    setActiveLayers(['seccion', 'distrito_federal'])
    const bbox = computeBBox(d.feature)
    if (bbox[0] !== Infinity) setFlyToBbox(bbox)
  }

  const selectDistritoLocal = (d: DistritoOption) => {
    setSelectedDistritoLocalId(d.id)
    setSelectedDistritoFedId(null)
    setSelectedMunicipioId(null)
    setSearchText('')
    setSelectedDistritoLocal(d.id)
    setActiveLayers(['seccion', 'distrito_local'])
    const bbox = computeBBox(d.feature)
    if (bbox[0] !== Infinity) setFlyToBbox(bbox)
  }

  const clearMunicipio = () => {
    setSelectedMunicipioId(null)
    setSearchText('')
    setShowSuggestions(false)
    searchRef.current?.focus()
    setSelectedMunicipio(null)
  }

  const toggleSection = (section: ExpandedSection) => {
    setExpandedSection((prev) => (prev === section ? null : section))
  }

  const filtered = municipalities.filter((m) =>
    m.name.toLowerCase().includes(searchText.toLowerCase()),
  )

  const suggestionsVisible =
    showSuggestions && searchText.length > 0 && filtered.length > 0 &&
    !(selectedMunicipioId != null && municipalities.find((m) => m.id === selectedMunicipioId)?.name === searchText)

  return (
    <div className="left-sidebar">
      {/* Logo */}
      <div className="sidebar-header">
        <img src="/labexlogo.png" alt="Labexandria" className="sidebar-logo-img" />
      </div>

      {/* ── National mode: state list ── */}
      {selectedEntidad == null && (
        <div className="sidebar-section">
          <div className="sidebar-section-label">Entidad</div>
          <div className="state-list">
            <button
              className="state-item active-national"
              onClick={() => setSelectedEntidad(null)}
            >
              Nacional
            </button>
            {STATES.map(([id, name]) => (
              <button
                key={id}
                className="state-item"
                onClick={() => setSelectedEntidad(id)}
              >
                {name}
              </button>
            ))}
          </div>
        </div>
      )}

      {/* ── State selected mode ── */}
      {selectedEntidad != null && (
        <div className="sidebar-section state-detail-section">

          {/* Back button */}
          <button
            className="back-btn"
            onClick={() => {
              const hasAreaSelected =
                selectedMunicipio != null ||
                selectedDistritoFederalStore != null ||
                selectedDistritoLocalStore != null
              if (hasAreaSelected) {
                // Area → State: clear area selection and reset layers to seccion only
                setSelectedMunicipioId(null)
                setSelectedDistritoFedId(null)
                setSelectedDistritoLocalId(null)
                setSearchText('')
                setShowSuggestions(false)
                setSelectedMunicipio(null)
                setSelectedDistritoFederal(null)
                setSelectedDistritoLocal(null)
                setActiveLayers(['seccion'])
              } else {
                setSelectedEntidad(null)
              }
            }}
          >
            &#8592; Atrás
          </button>
          <div className="selected-state-name">{selectedStateName}</div>

          {/* Work area header */}
          <div className="work-area-header">Selecciona tu área de trabajo</div>

          {/* ── Municipio accordion ── */}
          <div className="area-section">
            <button
              className={`area-section-toggle ${expandedSection === 'municipio' ? 'open' : ''}`}
              onClick={() => toggleSection('municipio')}
            >
              <span className="area-section-label">Municipio</span>
              <span className="area-section-arrow">{expandedSection === 'municipio' ? '▲' : '▼'}</span>
            </button>

            {expandedSection === 'municipio' && (
              <div className="area-section-body">
                <div className="muni-search-wrapper">
                  <input
                    ref={searchRef}
                    type="text"
                    className="muni-search-input"
                    placeholder="Buscar municipio..."
                    value={searchText}
                    onChange={(e) => {
                      setSearchText(e.target.value)
                      setShowSuggestions(true)
                      if (e.target.value === '') setSelectedMunicipioId(null)
                    }}
                    onFocus={() => setShowSuggestions(true)}
                    onBlur={() => {
                      setTimeout(() => setShowSuggestions(false), 150)
                    }}
                  />
                  {searchText && (
                    <button className="muni-clear-btn" onMouseDown={clearMunicipio} title="Limpiar">
                      ×
                    </button>
                  )}

                  {suggestionsVisible && (
                    <ul className="muni-suggestions">
                      {filtered.slice(0, 12).map((m) => (
                        <li
                          key={m.id}
                          className={`muni-suggestion-item ${selectedMunicipioId === m.id ? 'selected' : ''}`}
                          onMouseDown={() => selectMunicipio(m)}
                        >
                          {m.name}
                        </li>
                      ))}
                      {filtered.length > 12 && (
                        <li className="muni-suggestion-more">
                          +{filtered.length - 12} más…
                        </li>
                      )}
                    </ul>
                  )}
                </div>

                <div className="area-list">
                  {(searchText ? filtered : municipalities).map((m) => (
                    <button
                      key={m.id}
                      className={`area-list-item ${selectedMunicipioId === m.id ? 'active' : ''}`}
                      onClick={() => selectMunicipio(m)}
                    >
                      {m.name}
                    </button>
                  ))}
                  {searchText && filtered.length === 0 && (
                    <p className="muni-no-results">Sin resultados</p>
                  )}
                </div>
              </div>
            )}
          </div>

          {/* ── Distrito Federal accordion ── */}
          <div className="area-section">
            <button
              className={`area-section-toggle ${expandedSection === 'distrito_federal' ? 'open' : ''}`}
              onClick={() => toggleSection('distrito_federal')}
            >
              <span className="area-section-label">Distrito Federal</span>
              <span className="area-section-arrow">{expandedSection === 'distrito_federal' ? '▲' : '▼'}</span>
            </button>

            {expandedSection === 'distrito_federal' && (
              <div className="area-section-body">
                <div className="area-list">
                  {distritosFederales.map((d) => (
                    <button
                      key={d.id}
                      className={`area-list-item ${selectedDistritoFedId === d.id ? 'active' : ''}`}
                      onClick={() => selectDistritoFederal(d)}
                    >
                      Distrito Federal {d.id}
                    </button>
                  ))}
                  {distritosFederales.length === 0 && (
                    <p className="muni-no-results">Cargando…</p>
                  )}
                </div>
              </div>
            )}
          </div>

          {/* ── Distrito Local accordion ── */}
          <div className="area-section">
            <button
              className={`area-section-toggle ${expandedSection === 'distrito_local' ? 'open' : ''}`}
              onClick={() => toggleSection('distrito_local')}
            >
              <span className="area-section-label">Distrito Local</span>
              <span className="area-section-arrow">{expandedSection === 'distrito_local' ? '▲' : '▼'}</span>
            </button>

            {expandedSection === 'distrito_local' && (
              <div className="area-section-body">
                <div className="area-list">
                  {distritosLocales.map((d) => (
                    <button
                      key={d.id}
                      className={`area-list-item ${selectedDistritoLocalId === d.id ? 'active' : ''}`}
                      onClick={() => selectDistritoLocal(d)}
                    >
                      Distrito Local {d.id}
                    </button>
                  ))}
                  {distritosLocales.length === 0 && (
                    <p className="muni-no-results">Cargando…</p>
                  )}
                </div>
              </div>
            )}
          </div>

        </div>
      )}

      <div className="sidebar-footer">
        <a href="/api/docs" target="_blank" rel="noreferrer" className="api-link">
          API Docs ↗
        </a>
      </div>
    </div>
  )
}
