import { useEffect, useRef, useState } from 'react'
import { useMapStore } from '../../store/mapStore'
import { fetchElections } from '../../api/electionsApi'
import {
  downloadDensityExport,
  fetchCumulativeDensityMap,
  fetchCumulativeStats,
  type CumulativeLevelType,
  type CumulativeStatsResponse,
} from '../../api/analysisApi'
import { createDensityLayer } from '../../api/workingLayersApi'
import { useWorkingLayersStore } from '../../store/workingLayersStore'
import { DensityMapEmbed } from './DensityMapEmbed'
import './DensityPanel.css'

type DensityMode = 'individual' | 'cumulative'

const CUMULATIVE_LEVEL_OPTIONS: { value: CumulativeLevelType; label: string }[] = [
  { value: 'national', label: 'Nacional' },
  { value: 'state',    label: 'Estatal' },
  { value: 'municipal', label: 'Municipal' },
]

const STATES_BY_ID: Record<number, string> = {
  1:'Aguascalientes', 2:'Baja California', 3:'Baja California Sur',
  4:'Campeche', 5:'Coahuila', 6:'Colima', 7:'Chiapas', 8:'Chihuahua',
  9:'Ciudad de México', 10:'Durango', 11:'Guanajuato', 12:'Guerrero',
  13:'Hidalgo', 14:'Jalisco', 15:'Estado de México', 16:'Michoacán',
  17:'Morelos', 18:'Nayarit', 19:'Nuevo León', 20:'Oaxaca', 21:'Puebla',
  22:'Querétaro', 23:'Quintana Roo', 24:'San Luis Potosí', 25:'Sinaloa',
  26:'Sonora', 27:'Tabasco', 28:'Tamaulipas', 29:'Tlaxcala', 30:'Veracruz',
  31:'Yucatán', 32:'Zacatecas',
}

export function DensityPanel() {
  const selectedEntidad = useMapStore((s) => s.selectedEntidad)
  const selectedMunicipio = useMapStore((s) => s.selectedMunicipio)
  const selectedMunicipioBbox = useMapStore((s) => s.selectedMunicipioBbox)
  const electionName = useMapStore((s) => s.electionName)
  const setElectionName = useMapStore((s) => s.setElectionName)

  const [elections, setElections] = useState<string[]>([])
  const [mode, setMode] = useState<DensityMode>('individual')

  // Individual density state
  const [densityMin, setDensityMin] = useState(0)

  // Export controls
  const [exportGranularity, setExportGranularity] = useState<'section' | 'municipio'>('municipio')
  const [exportThreshold, setExportThreshold] = useState(80)
  const upsertLayer   = useWorkingLayersStore((s) => s.upsertLayer)
  const setActiveView = useMapStore((s) => s.setActiveView)

  const [exporting, setExporting]     = useState(false)
  const [exportError, setExportError] = useState<string | null>(null)
  const [saving, setSaving]           = useState(false)
  const [saveError, setSaveError]     = useState<string | null>(null)

  // Cumulative density state
  const [cumulativeLevel, setCumulativeLevel] = useState<CumulativeLevelType>('national')
  const [cumulativeThreshold, setCumulativeThreshold] = useState(50)
  const [cumulativeLoading, setCumulativeLoading] = useState(false)
  const [cumulativeError, setCumulativeError] = useState<string | null>(null)
  const [cumulativeHtml, setCumulativeHtml] = useState<string | null>(null)
  const [cumulativeStats, setCumulativeStats] = useState<CumulativeStatsResponse | null>(null)

  const cumulativeIframeRef = useRef<HTMLIFrameElement>(null)

  useEffect(() => {
    fetchElections()
      .then((data) => setElections([...new Set(data.map((e) => e.election_name))]))
      .catch(console.error)
  }, [])

  // Auto-generate cumulative map when mode/params change (debounced)
  useEffect(() => {
    if (mode !== 'cumulative') return
    let cancelled = false

    const timer = setTimeout(async () => {
      if (cancelled) return
      setCumulativeLoading(true)
      setCumulativeError(null)
      try {
        const req = {
          election_name: electionName,
          analysis_level: cumulativeLevel,
          entidad_id: selectedEntidad ?? undefined,
          municipio_id: selectedMunicipio ?? undefined,
          threshold: cumulativeThreshold,
          focus_bbox: selectedMunicipioBbox ?? undefined,
        }
        const [mapRes, statsRes] = await Promise.all([
          fetchCumulativeDensityMap(req),
          fetchCumulativeStats(req),
        ])
        if (!cancelled) {
          setCumulativeHtml(mapRes.content)
          setCumulativeStats(statsRes)
        }
      } catch (e: unknown) {
        if (!cancelled) {
          setCumulativeError(e instanceof Error ? e.message : 'Error desconocido')
        }
      } finally {
        if (!cancelled) setCumulativeLoading(false)
      }
    }, 600)

    return () => { cancelled = true; clearTimeout(timer) }
  }, [mode, cumulativeThreshold, cumulativeLevel, electionName, selectedEntidad, selectedMunicipio, selectedMunicipioBbox])

  async function handleExport() {
    if (!selectedEntidad) return
    setExporting(true)
    setExportError(null)
    try {
      await downloadDensityExport({
        election_name: electionName,
        entidad_id: selectedEntidad,
        granularity: exportGranularity,
        threshold_pct: exportThreshold,
      })
    } catch (e: unknown) {
      setExportError(e instanceof Error ? e.message : 'Error al exportar')
    } finally {
      setExporting(false)
    }
  }

  async function handleSaveLayer() {
    if (!selectedEntidad) return
    setSaving(true)
    setSaveError(null)
    try {
      const meta = await createDensityLayer({
        election_name: electionName,
        entidad_id:    selectedEntidad,
        granularity:   'section',
        threshold_pct: mode === 'cumulative' ? cumulativeThreshold : exportThreshold,
        municipio_id:  selectedMunicipio ?? undefined,
      })
      upsertLayer(meta)
      setActiveView('layers')
    } catch (e: unknown) {
      setSaveError(e instanceof Error ? e.message : 'Error al guardar')
    } finally {
      setSaving(false)
    }
  }

  const stateLabel = selectedEntidad
    ? STATES_BY_ID[selectedEntidad] ?? `Estado ${selectedEntidad}`
    : 'Nacional'
  const scopeLabel = selectedMunicipio
    ? `Municipio ${selectedMunicipio} — ${stateLabel}`
    : stateLabel

  return (
    <div className="analysis-layout">
      {/* ── Controls ───────────────────────────────────────────── */}
      <aside className="analysis-controls">
        <div className="controls-header">
          <div className="controls-title">Densidad Electoral</div>
          <div className="controls-subtitle">Votos por km²</div>
        </div>

        {/* Mode toggle */}
        <div className="density-mode-toggle">
          <button
            className={`density-mode-btn${mode === 'individual' ? ' active' : ''}`}
            onClick={() => setMode('individual')}
          >
            Densidad individual
          </button>
          <button
            className={`density-mode-btn${mode === 'cumulative' ? ' active' : ''}`}
            onClick={() => setMode('cumulative')}
          >
            Concentración acumulada
          </button>
        </div>

        {/* ── Election selector (shared) ── */}
        <div className="control-group">
          <label className="control-label">Elección</label>
          <select
            className="control-select"
            value={electionName}
            onChange={(e) => setElectionName(e.target.value)}
          >
            {elections.map((n) => <option key={n} value={n}>{n}</option>)}
          </select>
        </div>

        {/* ── Individual density controls ── */}
        {mode === 'individual' && (
          <>
            <div className="control-group">
              <label className="control-label">
                Densidad mínima — {densityMin}%
              </label>
              <input
                type="range"
                min={0}
                max={90}
                step={5}
                value={densityMin}
                onChange={(e) => setDensityMin(Number(e.target.value))}
                className="density-slider"
              />
              <div className="slider-hint">Filtra zonas con densidad &lt; {densityMin}% del máximo</div>
            </div>

            <div className="scope-badge">
              <span className="scope-icon">📍</span>
              <span>{scopeLabel}</span>
            </div>

            {/* Export section */}
            <div className="export-section">
              <div className="export-title">Exportar datos</div>

              {!selectedEntidad && (
                <div className="export-notice">
                  Selecciona un estado en la barra lateral para habilitar la exportación.
                </div>
              )}

              {selectedEntidad && (
                <>
                  <div className="control-group" style={{ padding: '10px 0 0' }}>
                    <label className="control-label">Granularidad de exportación</label>
                    <div className="radio-group">
                      <label className="radio-label">
                        <input type="radio" name="export-gran" value="municipio"
                          checked={exportGranularity === 'municipio'}
                          onChange={() => setExportGranularity('municipio')}
                        /> Municipio
                      </label>
                      <label className="radio-label">
                        <input type="radio" name="export-gran" value="section"
                          checked={exportGranularity === 'section'}
                          onChange={() => setExportGranularity('section')}
                        /> Sección
                      </label>
                    </div>
                  </div>

                  <div className="control-group" style={{ padding: '10px 0 0' }}>
                    <label className="control-label">Cobertura — {exportThreshold}%</label>
                    <input
                      type="number"
                      min={1} max={100}
                      value={exportThreshold}
                      onChange={(e) => setExportThreshold(Number(e.target.value))}
                      className="control-select"
                      style={{ width: '80px' }}
                    />
                    <div className="slider-hint">Zonas que representan el {exportThreshold}% del total de votos</div>
                  </div>

                  {exportError && <div className="export-error">{exportError}</div>}

                  <button
                    className="export-btn"
                    onClick={handleExport}
                    disabled={exporting}
                  >
                    {exporting ? '⏳ Exportando…' : '⬇ Exportar .xlsx'}
                  </button>

                  {saveError && (
                    <div className="export-error" style={{ marginTop: 6 }}>{saveError}</div>
                  )}
                  <button
                    className="export-btn"
                    onClick={handleSaveLayer}
                    disabled={saving}
                    style={{ marginTop: 6, background: 'var(--navy)' }}
                  >
                    {saving ? '⏳ Guardando…' : '🗂 Generar capa de trabajo'}
                  </button>
                </>
              )}
            </div>
          </>
        )}

        {/* ── Cumulative density controls ── */}
        {mode === 'cumulative' && (
          <>
            <div className="control-group">
              <label className="control-label">Nivel de análisis</label>
              <div className="radio-group">
                {CUMULATIVE_LEVEL_OPTIONS.map((opt) => (
                  <label key={opt.value} className="radio-label">
                    <input
                      type="radio"
                      name="cumulative-level"
                      value={opt.value}
                      checked={cumulativeLevel === opt.value}
                      onChange={() => setCumulativeLevel(opt.value)}
                    />
                    {opt.label}
                  </label>
                ))}
              </div>
              {cumulativeLevel !== 'national' && (
                <div className="slider-hint">
                  {cumulativeLevel === 'state'
                    ? 'El umbral se aplica independientemente por estado.'
                    : 'El umbral se aplica independientemente por municipio.'}
                  {selectedMunicipio
                    ? ` Filtrado a municipio ${selectedMunicipio} en ${stateLabel}.`
                    : selectedEntidad
                      ? ` Filtrado a ${stateLabel}.`
                      : ' Selecciona un estado para filtrar.'}
                </div>
              )}
            </div>

            <div className="control-group">
              <label className="control-label">
                Umbral acumulado — {cumulativeThreshold}%
              </label>
              <input
                type="range"
                min={10}
                max={90}
                step={5}
                value={cumulativeThreshold}
                onChange={(e) => setCumulativeThreshold(Number(e.target.value))}
                className="density-slider"
              />
              <div className="slider-hint">
                Resalta las secciones que juntas suman el {cumulativeThreshold}% de los votos
              </div>
            </div>

            <div className="scope-badge">
              <span className="scope-icon">📍</span>
              <span>{scopeLabel}</span>
            </div>

            {/* Generate layer button for cumulative mode */}
            {cumulativeStats && selectedEntidad && (
              <div style={{ padding: '6px 0 0' }}>
                {saveError && (
                  <div className="export-error" style={{ marginBottom: 4 }}>{saveError}</div>
                )}
                <button
                  className="export-btn"
                  onClick={handleSaveLayer}
                  disabled={saving}
                  style={{ width: '100%', background: 'var(--navy)' }}
                >
                  {saving ? '⏳ Guardando…' : '🗂 Generar capa de trabajo'}
                </button>
              </div>
            )}

            {/* Stats panel */}
            {cumulativeStats && (
              <div className="cumulative-stats">
                <div className="cumulative-stats-title">Resultados</div>
                <div className="cumulative-stats-row">
                  <span className="cumulative-stats-label">Secciones en umbral</span>
                  <span className="cumulative-stats-value">
                    {cumulativeStats.secciones_in_threshold.toLocaleString('es-MX')}
                    <span className="cumulative-stats-pct">
                      {' '}({cumulativeStats.pct_secciones.toFixed(1)}%)
                    </span>
                  </span>
                </div>
                <div className="cumulative-stats-row">
                  <span className="cumulative-stats-label">Total secciones</span>
                  <span className="cumulative-stats-value">
                    {cumulativeStats.total_secciones.toLocaleString('es-MX')}
                  </span>
                </div>
                {cumulativeStats.top_estados.length > 0 && (
                  <div className="cumulative-stats-list">
                    <div className="cumulative-stats-list-title">Top estados (por secciones)</div>
                    {cumulativeStats.top_estados.slice(0, 5).map((e) => (
                      <div key={e.entidad_id} className="cumulative-stats-list-row">
                        <span>{STATES_BY_ID[e.entidad_id] ?? `Estado ${e.entidad_id}`}</span>
                        <span className="cumulative-stats-count">{e.secciones}</span>
                      </div>
                    ))}
                  </div>
                )}
              </div>
            )}
          </>
        )}
      </aside>

      {/* ── Map area ───────────────────────────────────────────── */}
      <section className="density-map-area">
        {mode === 'individual' && (
          selectedEntidad ? (
            <DensityMapEmbed
              entidadId={selectedEntidad}
              electionName={electionName}
              densityMin={densityMin}
              municipioId={selectedMunicipio}
              municipioBbox={selectedMunicipioBbox}
            />
          ) : (
            <div className="results-empty">
              <div className="empty-icon">🗺️</div>
              <div className="empty-title">Selecciona un estado</div>
              <div className="empty-text">
                Haz clic en un estado en la barra lateral para visualizar la densidad electoral por sección.
              </div>
            </div>
          )
        )}

        {mode === 'cumulative' && (
          <>
            {!cumulativeHtml && !cumulativeLoading && !cumulativeError && (
              <div className="results-empty">
                <div className="empty-icon">📊</div>
                <div className="empty-title">Concentración acumulada</div>
                <div className="empty-text">
                  Selecciona un umbral para ver qué secciones concentran ese porcentaje de votos.
                </div>
              </div>
            )}
            {cumulativeLoading && (
              <div className="results-empty">
                <div className="loading-ring" />
                <div className="empty-title">Calculando concentración electoral…</div>
                <div className="empty-text">Esto puede tardar unos segundos.</div>
              </div>
            )}
            {cumulativeError && (
              <div className="results-error" style={{ margin: '40px auto', maxWidth: '480px' }}>
                <div className="error-icon">⚠️</div>
                <div className="error-text">{cumulativeError}</div>
              </div>
            )}
            {cumulativeHtml && !cumulativeLoading && (
              <iframe
                ref={cumulativeIframeRef}
                className="density-iframe"
                srcDoc={cumulativeHtml}
                title="Mapa de concentración acumulada"
                sandbox="allow-scripts allow-same-origin"
              />
            )}
          </>
        )}
      </section>
    </div>
  )
}
