import { useEffect, useRef } from 'react'
import maplibregl from 'maplibre-gl'
import 'maplibre-gl/dist/maplibre-gl.css'
import { fetchLayer } from '../../api/layersApi'
import { fetchDensityPrecomputed } from '../../api/analysisApi'

const BASEMAP_STYLE = 'https://tiles.openfreemap.org/styles/liberty'
const EMPTY_FC: GeoJSON.FeatureCollection = { type: 'FeatureCollection', features: [] }

// YlOrRd color ramp for density_normalized 0→1
const DENSITY_COLOR_EXPR: maplibregl.ExpressionSpecification = [
  'interpolate', ['linear'], ['get', 'density_normalized'],
  0,    '#ffffb2',
  0.2,  '#fed976',
  0.4,  '#feb24c',
  0.6,  '#fd8d3c',
  0.8,  '#f03b20',
  1,    '#bd0026',
]

function computeBBox(fc: GeoJSON.FeatureCollection): [number, number, number, number] {
  let minLng = Infinity, minLat = Infinity, maxLng = -Infinity, maxLat = -Infinity
  function walk(val: unknown) {
    if (Array.isArray(val)) {
      if (typeof val[0] === 'number') {
        minLng = Math.min(minLng, val[0] as number)
        minLat = Math.min(minLat, val[1] as number)
        maxLng = Math.max(maxLng, val[0] as number)
        maxLat = Math.max(maxLat, val[1] as number)
      } else { val.forEach(walk) }
    }
  }
  for (const f of fc.features) {
    if (f.geometry) walk((f.geometry as GeoJSON.Polygon).coordinates)
  }
  return [minLng, minLat, maxLng, maxLat]
}

interface Props {
  entidadId: number
  electionName: string
  densityMin: number  // 0–100: hide sections whose density_normalized < densityMin/100
  municipioId?: number | null
  municipioBbox?: [number, number, number, number] | null
}

export function DensityMapEmbed({ entidadId, electionName, densityMin, municipioId, municipioBbox }: Props) {
  const containerRef = useRef<HTMLDivElement>(null)
  const mapRef = useRef<maplibregl.Map | null>(null)
  const municipioBboxRef = useRef(municipioBbox)
  const entidadIdRef = useRef(entidadId)
  useEffect(() => { municipioBboxRef.current = municipioBbox }, [municipioBbox])
  useEffect(() => { entidadIdRef.current = entidadId }, [entidadId])

  // Initialise map once
  useEffect(() => {
    if (!containerRef.current) return

    const map = new maplibregl.Map({
      container: containerRef.current,
      style: BASEMAP_STYLE,
      center: [-102, 23.5],
      zoom: 5,
      attributionControl: false,
    })
    map.addControl(new maplibregl.NavigationControl({ showCompass: false }), 'top-right')

    map.on('load', () => {
      // Pre-position before data loads
      const muniBbox = municipioBboxRef.current
      if (muniBbox) {
        map.fitBounds(muniBbox as maplibregl.LngLatBoundsLike, {
          padding: { top: 24, bottom: 24, left: 24, right: 24 },
          maxZoom: 15,
          duration: 0,
        })
      } else {
        const id = entidadIdRef.current
        if (id) {
          fetchLayer('entidad', id).then((fc) => {
            if (!mapRef.current) return
            const bbox = computeBBox(fc as GeoJSON.FeatureCollection)
            if (bbox[0] !== Infinity) {
              mapRef.current.fitBounds(bbox as maplibregl.LngLatBoundsLike, {
                padding: { top: 40, bottom: 40, left: 40, right: 40 },
                maxZoom: 11,
                duration: 0,
              })
            }
          }).catch(console.error)
        }
      }

      map.addSource('density-src', { type: 'geojson', data: EMPTY_FC })

      map.addLayer({
        id: 'density-fill',
        type: 'fill',
        source: 'density-src',
        paint: {
          'fill-color': DENSITY_COLOR_EXPR,
          'fill-opacity': 0.85,
        },
      })

      map.addLayer({
        id: 'density-line',
        type: 'line',
        source: 'density-src',
        paint: { 'line-color': '#555555', 'line-width': 0.3, 'line-opacity': 0.5 },
      })

      // Context boundary outline
      map.addSource('context-src', { type: 'geojson', data: EMPTY_FC })
      map.addLayer({
        id: 'context-halo',
        type: 'line',
        source: 'context-src',
        paint: { 'line-color': '#FFFFFF', 'line-width': 5, 'line-opacity': 0.85 },
      })
      map.addLayer({
        id: 'context-line',
        type: 'line',
        source: 'context-src',
        paint: { 'line-color': '#1A3A52', 'line-width': 2.5, 'line-opacity': 1 },
      })
    })

    mapRef.current = map
    return () => { map.remove(); mapRef.current = null }
  }, [])

  // Load + merge data when entidad or election changes
  useEffect(() => {
    const map = mapRef.current
    if (!map || !entidadId || !electionName) return
    let cancelled = false

    Promise.all([
      fetchLayer('seccion', entidadId),
      fetchDensityPrecomputed(electionName, entidadId),
    ]).then(([geojson, densityData]) => {
      if (cancelled || !mapRef.current) return
      const m = mapRef.current

      const fc = geojson as GeoJSON.FeatureCollection
      const enriched: GeoJSON.FeatureCollection = {
        ...fc,
        features: fc.features.map((feat) => {
          const props = feat.properties || {}
          const entidad = props['ENTIDAD'] ?? props['entidad']
          const seccion = props['SECCION'] ?? props['seccion']
          const key = `${parseInt(String(entidad))}_${parseInt(String(seccion))}`
          const dn = densityData.data[key] ?? 0
          return { ...feat, properties: { ...props, density_normalized: dn } }
        }),
      }

      const waitForLoad = () => {
        if (!m.isStyleLoaded()) { setTimeout(waitForLoad, 100); return }

        const src = m.getSource('density-src') as maplibregl.GeoJSONSource | undefined
        src?.setData(enriched)

        // Zoom to municipality if selected, otherwise fit to all sections
        const targetBbox = municipioBboxRef.current
        if (targetBbox) {
          m.fitBounds(targetBbox as maplibregl.LngLatBoundsLike, {
            padding: { top: 24, bottom: 24, left: 24, right: 24 },
            maxZoom: 15,
            duration: 800,
          })
          return
        }
        const bbox = computeBBox(enriched)
        if (bbox[0] !== Infinity) {
          m.fitBounds(bbox as maplibregl.LngLatBoundsLike, {
            padding: { top: 40, bottom: 40, left: 40, right: 40 },
            maxZoom: 11,
            duration: 800,
          })
        }
      }
      waitForLoad()
    }).catch(console.error)

    return () => { cancelled = true }
  }, [entidadId, electionName])

  // Draw context boundary: municipality outline when selected, state outline otherwise
  useEffect(() => {
    const map = mapRef.current
    if (!map || !entidadId) return
    let cancelled = false

    const applyBoundary = (fc: GeoJSON.FeatureCollection) => {
      if (cancelled) return
      const apply = () => {
        if (!mapRef.current) return
        if (!mapRef.current.isStyleLoaded()) { setTimeout(apply, 100); return }
        const src = mapRef.current.getSource('context-src') as maplibregl.GeoJSONSource | undefined
        src?.setData(fc)
      }
      apply()
    }

    if (municipioId) {
      fetchLayer('municipio', entidadId).then((raw) => {
        const fc = raw as GeoJSON.FeatureCollection
        const feat = fc.features.find(
          (f) => Number(f.properties?.MUNICIPIO) === municipioId
        )
        if (feat) applyBoundary({ type: 'FeatureCollection', features: [feat] })
      }).catch(console.error)
    } else {
      fetchLayer('entidad', entidadId).then((raw) => {
        applyBoundary(raw as GeoJSON.FeatureCollection)
      }).catch(console.error)
    }

    return () => { cancelled = true }
  }, [municipioId, entidadId])

  // Update opacity filter when densityMin changes (no data reload)
  useEffect(() => {
    const map = mapRef.current
    if (!map) return
    const minNorm = densityMin / 100

    const apply = () => {
      if (!map.isStyleLoaded()) { setTimeout(apply, 100); return }
      map.setPaintProperty('density-fill', 'fill-opacity', [
        'case',
        ['>=', ['get', 'density_normalized'], minNorm],
        0.85,
        0,
      ] as maplibregl.ExpressionSpecification)
    }
    apply()
  }, [densityMin])

  return (
    <div
      ref={containerRef}
      style={{ width: '100%', height: '100%', borderRadius: 8, overflow: 'hidden' }}
    />
  )
}
