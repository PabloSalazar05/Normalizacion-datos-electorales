import { useEffect, useRef } from 'react'
import maplibregl from 'maplibre-gl'
import 'maplibre-gl/dist/maplibre-gl.css'
import { fetchElectoralJoin, fetchLayer } from '../../api/layersApi'
import { buildQuantileChoroplethExpression } from '../../utils/choropleth'
import type { LayerName } from '../../types/layers'

const BASEMAP_STYLE = 'https://tiles.openfreemap.org/styles/liberty'
const EMPTY_FC: GeoJSON.FeatureCollection = { type: 'FeatureCollection', features: [] }

interface Props {
  entidadId: number
  layerName: LayerName   // 'seccion' | 'municipio' | 'distrito_federal'
  electionName: string
  variable: string       // e.g. 'MORENA_PCT'
  fillColor: string      // hex color for the choropleth
  municipioBbox?: [number, number, number, number] | null
  municipioId?: number | null
}

/** Compute bounding box from a FeatureCollection. */
function computeBBox(fc: GeoJSON.FeatureCollection): [number, number, number, number] {
  let minLng = Infinity, minLat = Infinity, maxLng = -Infinity, maxLat = -Infinity
  function walk(val: unknown) {
    if (Array.isArray(val)) {
      if (typeof val[0] === 'number') {
        minLng = Math.min(minLng, val[0] as number)
        minLat = Math.min(minLat, val[1] as number)
        maxLng = Math.max(maxLng, val[0] as number)
        maxLat = Math.max(maxLat, val[1] as number)
      } else { val.forEach(walk) }
    }
  }
  for (const f of fc.features) {
    if (f.geometry) walk((f.geometry as GeoJSON.Polygon).coordinates)
  }
  return [minLng, minLat, maxLng, maxLat]
}

export function StateMapEmbed({ entidadId, layerName, electionName, variable, fillColor, municipioBbox, municipioId }: Props) {
  const containerRef = useRef<HTMLDivElement>(null)
  const mapRef = useRef<maplibregl.Map | null>(null)
  // Keep refs so the one-time init effect can read current values
  const entidadIdRef = useRef(entidadId)
  const municipioBboxRef = useRef(municipioBbox)
  useEffect(() => { entidadIdRef.current = entidadId }, [entidadId])
  useEffect(() => { municipioBboxRef.current = municipioBbox }, [municipioBbox])

  // Initialise map once
  useEffect(() => {
    if (!containerRef.current) return

    const map = new maplibregl.Map({
      container: containerRef.current,
      style: BASEMAP_STYLE,
      center: [-102, 23.5],
      zoom: 5,
      attributionControl: false,
    })
    map.addControl(new maplibregl.NavigationControl({ showCompass: false }), 'top-right')

    map.on('load', () => {
      map.addSource('choropleth-src', { type: 'geojson', data: EMPTY_FC })
      map.addLayer({
        id: 'choropleth-fill',
        type: 'fill',
        source: 'choropleth-src',
        paint: { 'fill-color': '#cccccc', 'fill-opacity': 0.8 },
      })
      map.addLayer({
        id: 'choropleth-line',
        type: 'line',
        source: 'choropleth-src',
        paint: { 'line-color': '#1A3A52', 'line-width': 0.5, 'line-opacity': 0.7 },
      })

      // Context boundary outline (municipality or state)
      map.addSource('context-src', { type: 'geojson', data: EMPTY_FC })
      map.addLayer({
        id: 'context-halo',
        type: 'line',
        source: 'context-src',
        paint: { 'line-color': '#FFFFFF', 'line-width': 5, 'line-opacity': 0.85 },
      })
      map.addLayer({
        id: 'context-line',
        type: 'line',
        source: 'context-src',
        paint: { 'line-color': '#1A3A52', 'line-width': 2.5, 'line-opacity': 1 },
      })

      // Pre-position immediately (no animation) so the user never sees
      // the national default view while electoral data loads.
      // If a municipality is already selected, zoom to it; otherwise zoom to state.
      const muniBbox = municipioBboxRef.current
      if (muniBbox) {
        mapRef.current?.fitBounds(muniBbox as maplibregl.LngLatBoundsLike, {
          padding: { top: 24, bottom: 24, left: 24, right: 24 },
          maxZoom: 15,
          duration: 0,
        })
      } else {
        const id = entidadIdRef.current
        if (id) {
          fetchLayer('entidad', id).then((fc) => {
            if (!mapRef.current) return
            const bbox = computeBBox(fc as GeoJSON.FeatureCollection)
            if (bbox[0] !== Infinity) {
              mapRef.current.fitBounds(bbox as maplibregl.LngLatBoundsLike, {
                padding: { top: 40, bottom: 40, left: 40, right: 40 },
                maxZoom: 11,
                duration: 0,
              })
            }
          }).catch(console.error)
        }
      }
    })

    mapRef.current = map
    return () => { map.remove(); mapRef.current = null }
  }, [])

  // When the municipality bbox changes, fly to it (or back to state if cleared)
  useEffect(() => {
    const map = mapRef.current
    if (!map) return
    if (municipioBbox) {
      map.fitBounds(municipioBbox as maplibregl.LngLatBoundsLike, {
        padding: { top: 24, bottom: 24, left: 24, right: 24 },
        maxZoom: 15,
        duration: 800,
      })
    } else if (entidadId) {
      fetchLayer('entidad', entidadId).then((fc) => {
        if (!mapRef.current) return
        const bbox = computeBBox(fc as GeoJSON.FeatureCollection)
        if (bbox[0] !== Infinity) {
          mapRef.current.fitBounds(bbox as maplibregl.LngLatBoundsLike, {
            padding: { top: 40, bottom: 40, left: 40, right: 40 },
            maxZoom: 11,
            duration: 800,
          })
        }
      }).catch(console.error)
    }
  }, [municipioBbox, entidadId])

  // Load data when inputs change
  useEffect(() => {
    const map = mapRef.current
    if (!map || !entidadId || !electionName || !variable) return

    let cancelled = false

    fetchElectoralJoin(layerName, {
      election_name: electionName,
      entidad_ids: [entidadId],
    }).then((fc) => {
      if (cancelled || !mapRef.current) return
      const m = mapRef.current

      const waitForLoad = () => {
        if (!m.isStyleLoaded()) { setTimeout(waitForLoad, 100); return }

        const src = m.getSource('choropleth-src') as maplibregl.GeoJSONSource | undefined
        src?.setData(fc as GeoJSON.FeatureCollection)

        // Compute quartile breakpoints from actual data for a perceptually distinct scale
        const vals = (fc as GeoJSON.FeatureCollection).features
          .map((f) => Number(f.properties?.[variable] ?? 0))
          .filter((v) => v > 0)
          .sort((a, b) => a - b)
        const at = (p: number) => vals[Math.floor(vals.length * p)] ?? 0
        const breakpoints: [number, number, number, number] = [
          at(0.25), at(0.50), at(0.75), Math.max(at(0.98), 0.01),
        ]
        const colorExpr = buildQuantileChoroplethExpression(variable, fillColor, breakpoints)
        m.setPaintProperty('choropleth-fill', 'fill-color', colorExpr as maplibregl.ExpressionSpecification)

        // Fly to municipality bounds if one is selected, otherwise state bounds
        const targetBbox = municipioBboxRef.current
        if (targetBbox) {
          m.fitBounds(targetBbox as maplibregl.LngLatBoundsLike, {
            padding: { top: 24, bottom: 24, left: 24, right: 24 },
            maxZoom: 15,
            duration: 800,
          })
        } else {
          const bbox = computeBBox(fc as GeoJSON.FeatureCollection)
          if (bbox[0] !== Infinity) {
            m.fitBounds(bbox as maplibregl.LngLatBoundsLike, {
              padding: { top: 40, bottom: 40, left: 40, right: 40 },
              maxZoom: 11,
              duration: 800,
            })
          }
        }
      }
      waitForLoad()
    }).catch(console.error)

    return () => { cancelled = true }
  }, [entidadId, layerName, electionName, variable, fillColor])

  // Draw context boundary: municipality outline when selected, state outline otherwise
  useEffect(() => {
    const map = mapRef.current
    if (!map || !entidadId) return
    let cancelled = false

    const applyBoundary = (fc: GeoJSON.FeatureCollection) => {
      if (cancelled) return
      const apply = () => {
        if (!mapRef.current) return
        if (!mapRef.current.isStyleLoaded()) { setTimeout(apply, 100); return }
        const src = mapRef.current.getSource('context-src') as maplibregl.GeoJSONSource | undefined
        src?.setData(fc)
      }
      apply()
    }

    if (municipioId) {
      fetchLayer('municipio', entidadId).then((raw) => {
        const fc = raw as GeoJSON.FeatureCollection
        const feat = fc.features.find(
          (f) => Number(f.properties?.MUNICIPIO) === municipioId
        )
        if (feat) applyBoundary({ type: 'FeatureCollection', features: [feat] })
      }).catch(console.error)
    } else {
      fetchLayer('entidad', entidadId).then((raw) => {
        applyBoundary(raw as GeoJSON.FeatureCollection)
      }).catch(console.error)
    }

    return () => { cancelled = true }
  }, [municipioId, entidadId])

  return (
    <div
      ref={containerRef}
      style={{ width: '100%', height: '100%', borderRadius: 8, overflow: 'hidden' }}
    />
  )
}
