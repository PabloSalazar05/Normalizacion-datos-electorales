import { useEffect, useState } from 'react'
import { useMapStore } from '../../store/mapStore'
import { useWorkingLayersStore } from '../../store/workingLayersStore'
import { fetchElections } from '../../api/electionsApi'
import {
  fetchSpatialVariables,
  fetchLISA,
  type LISAResult,
  type GranularityType,
} from '../../api/analysisApi'
import { createLISALayer } from '../../api/workingLayersApi'
import { LISAMapEmbed, CLUSTER_COLORS } from './LISAMapEmbed'
import './MoransPanel.css'
import './LISAPanel.css'

const GRANULARITY_OPTIONS: { value: GranularityType; label: string }[] = [
  { value: 'section',          label: 'Sección' },
  { value: 'municipio',        label: 'Municipio' },
  { value: 'distrito_federal', label: 'Distrito Federal' },
]

const STATES_BY_ID: Record<number, string> = {
  1:'Aguascalientes', 2:'Baja California', 3:'Baja California Sur',
  4:'Campeche', 5:'Coahuila', 6:'Colima', 7:'Chiapas', 8:'Chihuahua',
  9:'Ciudad de México', 10:'Durango', 11:'Guanajuato', 12:'Guerrero',
  13:'Hidalgo', 14:'Jalisco', 15:'Estado de México', 16:'Michoacán',
  17:'Morelos', 18:'Nayarit', 19:'Nuevo León', 20:'Oaxaca', 21:'Puebla',
  22:'Querétaro', 23:'Quintana Roo', 24:'San Luis Potosí', 25:'Sinaloa',
  26:'Sonora', 27:'Tabasco', 28:'Tamaulipas', 29:'Tlaxcala', 30:'Veracruz',
  31:'Yucatán', 32:'Zacatecas',
}

const CLUSTER_LABELS: Record<string, string> = {
  HH: 'Hot Spot (HH)',
  LL: 'Cold Spot (LL)',
  HL: 'Outlier Alta–Baja (HL)',
  LH: 'Outlier Baja–Alta (LH)',
  NS: 'No significativo',
}

export function LISAPanel() {
  const selectedEntidad = useMapStore((s) => s.selectedEntidad)
  const selectedMunicipio = useMapStore((s) => s.selectedMunicipio)
  const selectedMunicipioBbox = useMapStore((s) => s.selectedMunicipioBbox)
  const electionName = useMapStore((s) => s.electionName)
  const setElectionName = useMapStore((s) => s.setElectionName)

  const [elections, setElections] = useState<string[]>([])
  const [granularity, setGranularity] = useState<GranularityType>('section')
  const [variables, setVariables] = useState<string[]>([])
  const [selectedVariable, setSelectedVariable] = useState<string>('')
  const [significance, setSignificance] = useState<number>(0.05)
  const upsertLayer   = useWorkingLayersStore((s) => s.upsertLayer)
  const setActiveView = useMapStore((s) => s.setActiveView)

  const [loading, setLoading]   = useState(false)
  const [error, setError]       = useState<string | null>(null)
  const [result, setResult]     = useState<LISAResult | null>(null)
  const [saving, setSaving]     = useState(false)
  const [saveError, setSaveError] = useState<string | null>(null)

  // Load elections on mount
  useEffect(() => {
    fetchElections()
      .then((data) => setElections([...new Set(data.map((e) => e.election_name))]))
      .catch(console.error)
  }, [])

  // Load variables when election or state changes
  useEffect(() => {
    const entidad = selectedEntidad ?? 1
    fetchSpatialVariables(electionName, entidad)
      .then((data) => {
        setVariables(data.percentage_variables)
        if (data.percentage_variables.length > 0 && !data.percentage_variables.includes(selectedVariable)) {
          setSelectedVariable(data.percentage_variables[0])
        }
      })
      .catch(console.error)
  }, [electionName, selectedEntidad])

  async function handleAnalyze() {
    if (!selectedVariable) return
    if (!selectedEntidad) {
      setError('Selecciona un estado en la barra lateral para calcular LISA.')
      return
    }
    setLoading(true)
    setError(null)
    setResult(null)
    try {
      const analysis_level: 'state' | 'municipality' =
        selectedMunicipio ? 'municipality' : 'state'
      const res = await fetchLISA({
        election_name: electionName,
        variable: selectedVariable,
        analysis_level,
        entidad_id: selectedEntidad,
        municipio_id: selectedMunicipio ?? undefined,
        granularity,
        significance,
      })
      setResult(res)
    } catch (e: unknown) {
      setError(e instanceof Error ? e.message : 'Error desconocido')
    } finally {
      setLoading(false)
    }
  }

  async function handleSaveLayer() {
    if (!result || !selectedEntidad) return
    setSaving(true)
    setSaveError(null)
    try {
      const analysis_level: 'state' | 'municipality' = selectedMunicipio ? 'municipality' : 'state'
      // Pass pre-computed features from the existing result to avoid re-running LISA
      const fc = result.geojson as { features?: unknown[] }
      const meta = await createLISALayer({
        election_name:    electionName,
        variable:         selectedVariable,
        entidad_id:       selectedEntidad,
        granularity,
        analysis_level,
        significance,
        geojson_features: fc?.features ?? [],
        n_significant:    result.n_significant,
        n_observations:   result.n_observations,
        cluster_counts:   result.cluster_counts as Record<string, number>,
      })
      upsertLayer(meta)
      setActiveView('layers')
    } catch (e: unknown) {
      setSaveError(e instanceof Error ? e.message : 'Error al guardar')
    } finally {
      setSaving(false)
    }
  }

  const stateName = selectedEntidad
    ? STATES_BY_ID[selectedEntidad] ?? `Estado ${selectedEntidad}`
    : null
  const scopeLabel = selectedMunicipio && stateName
    ? `${stateName} — Municipio ${selectedMunicipio}`
    : stateName ?? 'Selecciona un estado'

  const totalSig = result ? result.n_significant : 0
  const totalObs = result ? result.n_observations : 0
  const pctSig = totalObs > 0 ? ((totalSig / totalObs) * 100).toFixed(1) : '—'

  return (
    <div className="analysis-layout">
      {/* ── Controls ───────────────────────────────────────── */}
      <aside className="analysis-controls">
        <div className="controls-header">
          <div className="controls-title">LISA Clusters</div>
          <div className="controls-subtitle">Autocorrelación espacial local</div>
        </div>

        <div className="control-group">
          <label className="control-label">Elección</label>
          <select
            className="control-select"
            value={electionName}
            onChange={(e) => setElectionName(e.target.value)}
          >
            {elections.map((n) => <option key={n} value={n}>{n}</option>)}
          </select>
        </div>

        <div className="control-group">
          <label className="control-label">Granularidad</label>
          <div className="radio-group">
            {GRANULARITY_OPTIONS.map((opt) => (
              <label key={opt.value} className="radio-label">
                <input
                  type="radio"
                  name="lisa-granularity"
                  value={opt.value}
                  checked={granularity === opt.value}
                  onChange={() => setGranularity(opt.value)}
                />
                {opt.label}
              </label>
            ))}
          </div>
        </div>

        <div className="control-group">
          <label className="control-label">Variable</label>
          <select
            className="control-select"
            value={selectedVariable}
            onChange={(e) => setSelectedVariable(e.target.value)}
          >
            {variables.length === 0 && <option value="">Cargando…</option>}
            {variables.map((v) => (
              <option key={v} value={v}>{v.replace('_PCT', '')}</option>
            ))}
          </select>
        </div>

        <div className="control-group">
          <label className="control-label">Significancia (α)</label>
          <select
            className="control-select"
            value={significance}
            onChange={(e) => setSignificance(Number(e.target.value))}
          >
            <option value={0.01}>0.01 (99 %)</option>
            <option value={0.05}>0.05 (95 %) — recomendado</option>
            <option value={0.10}>0.10 (90 %)</option>
          </select>
        </div>

        <div className="scope-badge">
          <span className="scope-icon">📍</span>
          <span>{scopeLabel}</span>
        </div>

        <button
          className="analyze-btn"
          onClick={handleAnalyze}
          disabled={loading || !selectedVariable || !selectedEntidad}
        >
          {loading ? <span className="spinner" /> : null}
          {loading ? 'Calculando…' : 'Calcular LISA'}
        </button>

        {/* Cluster legend (always visible) */}
        <div className="lisa-legend">
          <div className="lisa-legend-title">Tipos de Cluster</div>
          {Object.entries(CLUSTER_LABELS).map(([type, label]) => (
            <div key={type} className="lisa-legend-row">
              <span
                className="lisa-legend-dot"
                style={{ background: CLUSTER_COLORS[type] }}
              />
              <span className="lisa-legend-label">{label}</span>
              {result && (
                <span className="lisa-legend-count">
                  {result.cluster_counts[type as keyof typeof result.cluster_counts] ?? 0}
                </span>
              )}
            </div>
          ))}
        </div>
      </aside>

      {/* ── Results ────────────────────────────────────────── */}
      <section className="analysis-results">
        <div className="embed-map-area">
          {!selectedEntidad ? (
            <div className="results-empty">
              <div className="empty-icon">🔥</div>
              <div className="empty-title">Selecciona un estado</div>
              <div className="empty-text">
                LISA requiere análisis a nivel estatal. Selecciona un estado en la barra
                lateral y presiona <strong>Calcular LISA</strong>.
              </div>
            </div>
          ) : loading ? (
            <div className="results-empty">
              <div className="loading-ring" />
              <div className="empty-title">Calculando clusters…</div>
              <div className="empty-text">El análisis LISA puede tardar 30–60 segundos.</div>
            </div>
          ) : (
            <LISAMapEmbed result={result} entidadId={selectedEntidad} municipioBbox={selectedMunicipioBbox} municipioId={selectedMunicipio} />
          )}
        </div>

        {/* Stats strip */}
        {(result || error) && !loading && (
          <div className="stats-strip">
            {error && (
              <div className="results-error">
                <div className="error-icon">⚠️</div>
                <div className="error-text">{error}</div>
              </div>
            )}

            {result && (
              <>
                <div className="metric-row">
                  <div className="metric-cell">
                    <div className="metric-label">Observaciones</div>
                    <div className="metric-value">{result.n_observations.toLocaleString()}</div>
                    <div className="metric-hint">Unidades analizadas</div>
                  </div>
                  <div className="metric-cell cell-success">
                    <div className="metric-label">Significativas</div>
                    <div className="metric-value">{result.n_significant.toLocaleString()}</div>
                    <div className="metric-hint">{pctSig} % del total</div>
                  </div>
                  <div className="metric-cell">
                    <div className="metric-label">Hot Spots (HH)</div>
                    <div className="metric-value" style={{ color: CLUSTER_COLORS.HH }}>
                      {result.cluster_counts.HH}
                    </div>
                    <div className="metric-hint">Concentración alta</div>
                  </div>
                  <div className="metric-cell">
                    <div className="metric-label">Cold Spots (LL)</div>
                    <div className="metric-value" style={{ color: CLUSTER_COLORS.LL }}>
                      {result.cluster_counts.LL}
                    </div>
                    <div className="metric-hint">Concentración baja</div>
                  </div>
                  <div className="metric-cell">
                    <div className="metric-label">Outliers (HL+LH)</div>
                    <div className="metric-value" style={{ color: '#b45309' }}>
                      {result.cluster_counts.HL + result.cluster_counts.LH}
                    </div>
                    <div className="metric-hint">Discontinuidades</div>
                  </div>
                </div>

                <div style={{ padding: '10px 20px 14px' }}>
                  {saveError && (
                    <div style={{ color: '#b91c1c', fontSize: 12, marginBottom: 6 }}>{saveError}</div>
                  )}
                  <button
                    className="analyze-btn"
                    onClick={handleSaveLayer}
                    disabled={saving}
                    style={{ width: '100%' }}
                  >
                    {saving ? '⏳ Guardando…' : '🗂 Generar capa de trabajo'}
                  </button>
                </div>
              </>
            )}
          </div>
        )}
      </section>
    </div>
  )
}
