import { useEffect, useRef } from 'react'
import maplibregl from 'maplibre-gl'
import 'maplibre-gl/dist/maplibre-gl.css'
import { fetchLayer } from '../../api/layersApi'
import type { LISAResult } from '../../api/analysisApi'

const BASEMAP_STYLE = 'https://tiles.openfreemap.org/styles/liberty'
const EMPTY_FC: GeoJSON.FeatureCollection = { type: 'FeatureCollection', features: [] }

// LISA cluster colour palette (Anselin 1995 convention)
export const CLUSTER_COLORS: Record<string, string> = {
  HH: '#d7191c',   // Hot spot     — deep red
  LL: '#2c7bb6',   // Cold spot    — deep blue
  HL: '#fdae61',   // Spatial outlier (high–low) — orange
  LH: '#abd9e9',   // Spatial outlier (low–high) — light blue
  NS: '#d3d3d3',   // Not significant — grey
}

const CLUSTER_FILL_EXPR: maplibregl.ExpressionSpecification = [
  'match',
  ['get', 'cluster_type'],
  'HH', CLUSTER_COLORS.HH,
  'LL', CLUSTER_COLORS.LL,
  'HL', CLUSTER_COLORS.HL,
  'LH', CLUSTER_COLORS.LH,
  CLUSTER_COLORS.NS,
]

function computeBBox(fc: GeoJSON.FeatureCollection): [number, number, number, number] {
  let minLng = Infinity, minLat = Infinity, maxLng = -Infinity, maxLat = -Infinity
  function walk(val: unknown) {
    if (Array.isArray(val)) {
      if (typeof val[0] === 'number') {
        minLng = Math.min(minLng, val[0] as number)
        minLat = Math.min(minLat, val[1] as number)
        maxLng = Math.max(maxLng, val[0] as number)
        maxLat = Math.max(maxLat, val[1] as number)
      } else { val.forEach(walk) }
    }
  }
  for (const f of fc.features) {
    if (f.geometry) walk((f.geometry as GeoJSON.Polygon).coordinates)
  }
  return [minLng, minLat, maxLng, maxLat]
}

interface Props {
  result: LISAResult | null
  entidadId?: number | null
  municipioBbox?: [number, number, number, number] | null
  municipioId?: number | null
}

export function LISAMapEmbed({ result, entidadId, municipioBbox, municipioId }: Props) {
  const containerRef = useRef<HTMLDivElement>(null)
  const mapRef = useRef<maplibregl.Map | null>(null)
  const popupRef = useRef<maplibregl.Popup | null>(null)
  // Keep refs so the one-time init effect can read current values
  const entidadIdRef = useRef(entidadId)
  const municipioBboxRef = useRef(municipioBbox)
  useEffect(() => { entidadIdRef.current = entidadId }, [entidadId])
  useEffect(() => { municipioBboxRef.current = municipioBbox }, [municipioBbox])

  // Initialise map once
  useEffect(() => {
    if (!containerRef.current) return

    const map = new maplibregl.Map({
      container: containerRef.current,
      style: BASEMAP_STYLE,
      center: [-102, 23.5],
      zoom: 5,
      attributionControl: false,
    })
    map.addControl(new maplibregl.NavigationControl({ showCompass: false }), 'top-right')

    map.on('load', () => {
      map.addSource('lisa-src', { type: 'geojson', data: EMPTY_FC })

      // Pre-position immediately so user never sees the national default.
      // Zoom to municipality if selected, otherwise zoom to state.
      const muniBbox = municipioBboxRef.current
      if (muniBbox) {
        mapRef.current?.fitBounds(muniBbox as maplibregl.LngLatBoundsLike, {
          padding: { top: 24, bottom: 24, left: 24, right: 24 },
          maxZoom: 15,
          duration: 0,
        })
      } else {
        const id = entidadIdRef.current
        if (id) {
          fetchLayer('entidad', id).then((fc) => {
            if (!mapRef.current) return
            const bbox = computeBBox(fc as GeoJSON.FeatureCollection)
            if (bbox[0] !== Infinity) {
              mapRef.current.fitBounds(bbox as maplibregl.LngLatBoundsLike, {
                padding: { top: 40, bottom: 40, left: 40, right: 40 },
                maxZoom: 11,
                duration: 0,
              })
            }
          }).catch(console.error)
        }
      }

      map.addLayer({
        id: 'lisa-fill',
        type: 'fill',
        source: 'lisa-src',
        paint: {
          'fill-color': CLUSTER_FILL_EXPR,
          'fill-opacity': [
            'case',
            ['==', ['get', 'cluster_type'], 'NS'], 0.25,
            0.80,
          ],
        },
      })
      map.addLayer({
        id: 'lisa-line',
        type: 'line',
        source: 'lisa-src',
        paint: { 'line-color': '#333333', 'line-width': 0.4, 'line-opacity': 0.5 },
      })

      // Context boundary outline
      map.addSource('context-src', { type: 'geojson', data: EMPTY_FC })
      map.addLayer({
        id: 'context-halo',
        type: 'line',
        source: 'context-src',
        paint: { 'line-color': '#FFFFFF', 'line-width': 5, 'line-opacity': 0.85 },
      })
      map.addLayer({
        id: 'context-line',
        type: 'line',
        source: 'context-src',
        paint: { 'line-color': '#1A3A52', 'line-width': 2.5, 'line-opacity': 1 },
      })

      // Hover popup
      const popup = new maplibregl.Popup({
        closeButton: false,
        closeOnClick: false,
        className: 'lisa-popup',
      })
      popupRef.current = popup

      map.on('mousemove', 'lisa-fill', (e) => {
        map.getCanvas().style.cursor = 'pointer'
        const feat = e.features?.[0]
        if (!feat) return
        const p = feat.properties as Record<string, unknown>
        const ct = String(p.cluster_type ?? 'NS')
        const li = Number(p.local_i ?? 0).toFixed(4)
        const pv = Number(p.p_value ?? 1).toFixed(4)
        const labelMap: Record<string, string> = {
          HH: 'Hot Spot (HH)', LL: 'Cold Spot (LL)',
          HL: 'Outlier HL', LH: 'Outlier LH', NS: 'No significativo',
        }
        popup
          .setLngLat(e.lngLat)
          .setHTML(
            `<div class="lisa-popup-inner">
              <div class="lisa-popup-type" style="color:${CLUSTER_COLORS[ct] ?? '#999'}">${labelMap[ct] ?? ct}</div>
              <div class="lisa-popup-row"><span>Local I</span><span>${li}</span></div>
              <div class="lisa-popup-row"><span>P-valor</span><span>${pv}</span></div>
            </div>`
          )
          .addTo(map)
      })
      map.on('mouseleave', 'lisa-fill', () => {
        map.getCanvas().style.cursor = ''
        popup.remove()
      })
    })

    mapRef.current = map
    return () => { map.remove(); mapRef.current = null }
  }, [])

  // When municipality bbox or entidadId changes, fly to the appropriate bounds.
  // Municipality takes priority; falls back to state. Only triggers when no result
  // is displayed (result has its own fitBounds logic).
  useEffect(() => {
    const map = mapRef.current
    if (!map) return
    if (municipioBbox) {
      map.fitBounds(municipioBbox as maplibregl.LngLatBoundsLike, {
        padding: { top: 24, bottom: 24, left: 24, right: 24 },
        maxZoom: 15,
        duration: 800,
      })
    } else if (entidadId && !result) {
      fetchLayer('entidad', entidadId).then((fc) => {
        if (!mapRef.current) return
        const bbox = computeBBox(fc as GeoJSON.FeatureCollection)
        if (bbox[0] !== Infinity) {
          mapRef.current.fitBounds(bbox as maplibregl.LngLatBoundsLike, {
            padding: { top: 40, bottom: 40, left: 40, right: 40 },
            maxZoom: 11,
            duration: 800,
          })
        }
      }).catch(console.error)
    }
  }, [municipioBbox, entidadId])

  // Update data when result changes
  useEffect(() => {
    const map = mapRef.current
    if (!map) return

    const waitForLoad = () => {
      if (!map.isStyleLoaded()) { setTimeout(waitForLoad, 100); return }

      const src = map.getSource('lisa-src') as maplibregl.GeoJSONSource | undefined
      if (!result) {
        src?.setData(EMPTY_FC)
        return
      }

      const fc = result.geojson as unknown as GeoJSON.FeatureCollection
      src?.setData(fc)

      // Fit to the result's own bbox (which is already scoped to municipality
      // if analysis was run at municipality level)
      const bbox = computeBBox(fc)
      if (bbox[0] !== Infinity) {
        map.fitBounds(bbox as maplibregl.LngLatBoundsLike, {
          padding: { top: 24, bottom: 24, left: 24, right: 24 },
          maxZoom: 15,
          duration: 800,
        })
      }
    }
    waitForLoad()
  }, [result])

  // Draw context boundary: municipality outline when selected, state outline otherwise
  useEffect(() => {
    const map = mapRef.current
    if (!map || !entidadId) return
    let cancelled = false

    const applyBoundary = (fc: GeoJSON.FeatureCollection) => {
      if (cancelled) return
      const apply = () => {
        if (!mapRef.current) return
        if (!mapRef.current.isStyleLoaded()) { setTimeout(apply, 100); return }
        const src = mapRef.current.getSource('context-src') as maplibregl.GeoJSONSource | undefined
        src?.setData(fc)
      }
      apply()
    }

    if (municipioId) {
      fetchLayer('municipio', entidadId).then((raw) => {
        const fc = raw as GeoJSON.FeatureCollection
        const feat = fc.features.find(
          (f) => Number(f.properties?.MUNICIPIO) === municipioId
        )
        if (feat) applyBoundary({ type: 'FeatureCollection', features: [feat] })
      }).catch(console.error)
    } else if (entidadId) {
      fetchLayer('entidad', entidadId).then((raw) => {
        applyBoundary(raw as GeoJSON.FeatureCollection)
      }).catch(console.error)
    }

    return () => { cancelled = true }
  }, [municipioId, entidadId])

  return (
    <div
      ref={containerRef}
      style={{ width: '100%', height: '100%', borderRadius: 8, overflow: 'hidden' }}
    />
  )
}
