import { useEffect, useState } from 'react'
import { useMapStore } from '../../store/mapStore'
import { useWorkingLayersStore } from '../../store/workingLayersStore'
import { fetchElections } from '../../api/electionsApi'
import {
  fetchSpatialVariables,
  fetchMoranI,
  type MoranResult,
  type GranularityType,
} from '../../api/analysisApi'
import { createMoranLayer } from '../../api/workingLayersApi'
import { StateMapEmbed } from './StateMapEmbed'
import { PARTY_COLORS } from '../../utils/partyColors'
import type { LayerName } from '../../types/layers'
import './MoransPanel.css'

// Map Moran's granularity values to layer API names
const GRANULARITY_TO_LAYER: Record<GranularityType, LayerName> = {
  section: 'seccion',
  municipio: 'municipio',
  distrito_federal: 'distrito_federal',
}

const GRANULARITY_OPTIONS: { value: GranularityType; label: string }[] = [
  { value: 'section',           label: 'Sección' },
  { value: 'municipio',         label: 'Municipio' },
  { value: 'distrito_federal',  label: 'Distrito Federal' },
]

const STATES_BY_ID: Record<number, string> = {
  1:'Aguascalientes', 2:'Baja California', 3:'Baja California Sur',
  4:'Campeche', 5:'Coahuila', 6:'Colima', 7:'Chiapas', 8:'Chihuahua',
  9:'Ciudad de México', 10:'Durango', 11:'Guanajuato', 12:'Guerrero',
  13:'Hidalgo', 14:'Jalisco', 15:'Estado de México', 16:'Michoacán',
  17:'Morelos', 18:'Nayarit', 19:'Nuevo León', 20:'Oaxaca', 21:'Puebla',
  22:'Querétaro', 23:'Quintana Roo', 24:'San Luis Potosí', 25:'Sinaloa',
  26:'Sonora', 27:'Tabasco', 28:'Tamaulipas', 29:'Tlaxcala', 30:'Veracruz',
  31:'Yucatán', 32:'Zacatecas',
}

function fmt(n: number | undefined, decimals = 4): string {
  if (n == null) return '—'
  return Number(n).toFixed(decimals)
}

export function MoransPanel() {
  const selectedEntidad = useMapStore((s) => s.selectedEntidad)
  const selectedMunicipio = useMapStore((s) => s.selectedMunicipio)
  const selectedMunicipioBbox = useMapStore((s) => s.selectedMunicipioBbox)
  const electionName = useMapStore((s) => s.electionName)
  const setElectionName = useMapStore((s) => s.setElectionName)

  const [elections, setElections] = useState<string[]>([])
  const [granularity, setGranularity] = useState<GranularityType>('section')
  const [variables, setVariables] = useState<string[]>([])
  const [selectedVariable, setSelectedVariable] = useState<string>('')
  const upsertLayer    = useWorkingLayersStore((s) => s.upsertLayer)
  const setActiveView  = useMapStore((s) => s.setActiveView)

  const [loading, setLoading]           = useState(false)
  const [error, setError]               = useState<string | null>(null)
  const [result, setResult]             = useState<MoranResult | null>(null)
  const [showDetails, setShowDetails]   = useState(false)
  const [saving, setSaving]             = useState(false)
  const [saveError, setSaveError]       = useState<string | null>(null)

  // Load elections on mount
  useEffect(() => {
    fetchElections()
      .then((data) => setElections([...new Set(data.map((e) => e.election_name))]))
      .catch(console.error)
  }, [])

  // Load spatial variables when election or state changes
  useEffect(() => {
    const entidad = selectedEntidad ?? 1
    fetchSpatialVariables(electionName, entidad)
      .then((data) => {
        setVariables(data.percentage_variables)
        if (data.percentage_variables.length > 0 && !data.percentage_variables.includes(selectedVariable)) {
          setSelectedVariable(data.percentage_variables[0])
        }
      })
      .catch(console.error)
  }, [electionName, selectedEntidad])

  async function handleAnalyze() {
    if (!selectedVariable) return
    setLoading(true)
    setError(null)
    setResult(null)
    try {
      let analysis_level: 'national' | 'state' | 'municipality'
      if (selectedEntidad && selectedMunicipio) {
        analysis_level = 'municipality'
      } else if (selectedEntidad) {
        analysis_level = 'state'
      } else {
        analysis_level = 'national'
      }
      const res = await fetchMoranI({
        election_name: electionName,
        variable: selectedVariable,
        analysis_level,
        entidad_id: selectedEntidad ?? undefined,
        municipio_id: selectedMunicipio ?? undefined,
        granularity,
      })
      setResult(res)
    } catch (e: unknown) {
      setError(e instanceof Error ? e.message : 'Error desconocido')
    } finally {
      setLoading(false)
    }
  }

  async function handleSaveLayer() {
    if (!result) return
    setSaving(true)
    setSaveError(null)
    try {
      let analysis_level: 'national' | 'state' | 'municipality'
      if (selectedEntidad && selectedMunicipio) analysis_level = 'municipality'
      else if (selectedEntidad) analysis_level = 'state'
      else analysis_level = 'national'

      const meta = await createMoranLayer({
        election_name:  electionName,
        variable:       selectedVariable,
        entidad_id:     selectedEntidad ?? undefined,
        granularity,
        analysis_level,
        moran_i:        result.moran_i,
        p_value:        result.p_value,
        significant:    result.significant,
        z_score:        result.z_score,
        n_observations: result.n_observations,
      })
      upsertLayer(meta)
      setActiveView('layers')
    } catch (e: unknown) {
      setSaveError(e instanceof Error ? e.message : 'Error al guardar')
    } finally {
      setSaving(false)
    }
  }

  const stateName = selectedEntidad
    ? STATES_BY_ID[selectedEntidad] ?? `Estado ${selectedEntidad}`
    : null
  const scopeLabel = selectedMunicipio && stateName
    ? `${stateName} — Municipio ${selectedMunicipio}`
    : stateName ?? 'Nacional'

  return (
    <div className="analysis-layout">
      {/* ── Controls panel ─────────────────────────────────────── */}
      <aside className="analysis-controls">
        <div className="controls-header">
          <div className="controls-title">Análisis Espacial</div>
          <div className="controls-subtitle">Índice de Moran's I</div>
        </div>

        <div className="control-group">
          <label className="control-label">Elección</label>
          <select
            className="control-select"
            value={electionName}
            onChange={(e) => setElectionName(e.target.value)}
          >
            {elections.map((n) => <option key={n} value={n}>{n}</option>)}
          </select>
        </div>

        <div className="control-group">
          <label className="control-label">Granularidad</label>
          <div className="radio-group">
            {GRANULARITY_OPTIONS.map((opt) => (
              <label key={opt.value} className="radio-label">
                <input
                  type="radio"
                  name="granularity"
                  value={opt.value}
                  checked={granularity === opt.value}
                  onChange={() => setGranularity(opt.value)}
                />
                {opt.label}
              </label>
            ))}
          </div>
        </div>

        <div className="control-group">
          <label className="control-label">Variable</label>
          <select
            className="control-select"
            value={selectedVariable}
            onChange={(e) => setSelectedVariable(e.target.value)}
          >
            {variables.length === 0 && <option value="">Cargando…</option>}
            {variables.map((v) => (
              <option key={v} value={v}>{v.replace('_PCT', '')}</option>
            ))}
          </select>
        </div>

        <div className="scope-badge">
          <span className="scope-icon">📍</span>
          <span>{scopeLabel}</span>
        </div>

        <button
          className="analyze-btn"
          onClick={handleAnalyze}
          disabled={loading || !selectedVariable}
        >
          {loading ? <span className="spinner" /> : null}
          {loading ? 'Calculando…' : 'Analizar'}
        </button>
      </aside>

      {/* ── Results area: map fills space, stats strip at bottom ──── */}
      <section className="analysis-results">

        {/* Map area — always fills the available height */}
        <div className="embed-map-area">
          {selectedEntidad != null ? (
            <StateMapEmbed
              entidadId={selectedEntidad}
              layerName={GRANULARITY_TO_LAYER[granularity]}
              electionName={electionName}
              variable={selectedVariable || 'MORENA_PCT'}
              fillColor={PARTY_COLORS[selectedVariable?.replace('_PCT', '') ?? ''] ?? '#1B9A8E'}
              municipioBbox={selectedMunicipioBbox}
              municipioId={selectedMunicipio}
            />
          ) : (
            <div className="results-empty">
              {loading
                ? <><div className="loading-ring" /><div className="empty-title">Calculando Moran's I…</div><div className="empty-text">El análisis nacional puede tardar 1–3 minutos.</div></>
                : <><div className="empty-icon">📐</div><div className="empty-title">Listo para analizar</div><div className="empty-text">Selecciona un estado en la barra lateral o analiza a nivel nacional.</div></>
              }
            </div>
          )}
        </div>

        {/* Compact stats strip — only visible when there's a result or error */}
        {(result || error || (loading && selectedEntidad != null)) && (
          <div className="stats-strip">
            {error && (
              <div className="results-error">
                <div className="error-icon">⚠️</div>
                <div className="error-text">{error}</div>
              </div>
            )}

            {loading && (
              <div className="metric-row" style={{ justifyContent: 'center', padding: '14px 20px', gap: 10 }}>
                <div className="loading-ring" style={{ width: 24, height: 24, borderWidth: 3 }} />
                <span style={{ fontSize: 14, color: 'var(--slate)' }}>Calculando…</span>
              </div>
            )}

            {result && !loading && (
              <>
                {/* 4 metrics in a compact horizontal row */}
                <div className="metric-row">
                  <div className="metric-cell">
                    <div className="metric-label">Moran's I</div>
                    <div className="metric-value">{fmt(result.moran_i)}</div>
                    <div className="metric-hint">–1 disperso · 0 · +1 agrupado</div>
                  </div>
                  <div className="metric-cell">
                    <div className="metric-label">Z-Score</div>
                    <div className="metric-value">{fmt(result.z_score, 3)}</div>
                    <div className="metric-hint">Desv. estándar</div>
                  </div>
                  <div className="metric-cell">
                    <div className="metric-label">P-Valor</div>
                    <div className="metric-value">{fmt(result.p_value, 4)}</div>
                    <div className="metric-hint">Sig. si &lt; 0.05</div>
                  </div>
                  <div className={`metric-cell ${result.significant ? 'cell-success' : 'cell-neutral'}`}>
                    <div className="metric-label">Significativo</div>
                    <div className="metric-value metric-badge">
                      {result.significant ? '✅ Sí' : '❌ No'}
                    </div>
                    <div className="metric-hint">α = 0.05</div>
                  </div>
                </div>

                <div className="strip-body">
                  <div className="interpretation-box">
                    <div className="interpretation-title">Interpretación</div>
                    <p className="interpretation-text">{result.interpretation}</p>
                  </div>

                  <div className="details-section">
                    <button
                      className="details-toggle"
                      onClick={() => setShowDetails((v) => !v)}
                    >
                      {showDetails ? '▼' : '▶'} Detalles técnicos
                    </button>
                    {showDetails && (
                      <div className="details-grid">
                        <div className="detail-row">
                          <span className="detail-key">Observaciones</span>
                          <span className="detail-val">{result.n_observations?.toLocaleString()}</span>
                        </div>
                        <div className="detail-row">
                          <span className="detail-key">Vecinos promedio</span>
                          <span className="detail-val">{fmt(result.mean_neighbors, 2)}</span>
                        </div>
                        <div className="detail-row">
                          <span className="detail-key">Islas (sin vecinos)</span>
                          <span className="detail-val">{result.islands}</span>
                        </div>
                        <div className="detail-row">
                          <span className="detail-key">I esperado (H₀)</span>
                          <span className="detail-val">{fmt(result.expected_i, 6)}</span>
                        </div>
                        <div className="detail-row">
                          <span className="detail-key">Variable</span>
                          <span className="detail-val">{selectedVariable}</span>
                        </div>
                      </div>
                    )}
                  </div>

                  <div style={{ padding: '10px 20px 14px' }}>
                    {saveError && (
                      <div style={{ color: '#b91c1c', fontSize: 12, marginBottom: 6 }}>{saveError}</div>
                    )}
                    <button
                      className="analyze-btn"
                      onClick={handleSaveLayer}
                      disabled={saving}
                      style={{ width: '100%' }}
                    >
                      {saving ? '⏳ Guardando…' : '🗂 Generar capa de trabajo'}
                    </button>
                  </div>
                </div>
              </>
            )}
          </div>
        )}
      </section>
    </div>
  )
}
