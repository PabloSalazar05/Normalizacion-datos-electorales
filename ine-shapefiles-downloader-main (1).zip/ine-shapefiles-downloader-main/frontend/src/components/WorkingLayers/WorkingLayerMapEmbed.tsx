import { useEffect, useRef, useState } from 'react'
import maplibregl from 'maplibre-gl'
import 'maplibre-gl/dist/maplibre-gl.css'
import { fetchWorkingLayerGeoJSON } from '../../api/workingLayersApi'
import type { WorkingLayerMeta } from '../../api/workingLayersApi'

const BASEMAP_STYLE = 'https://tiles.openfreemap.org/styles/liberty'
const EMPTY_FC: GeoJSON.FeatureCollection = { type: 'FeatureCollection', features: [] }

const TYPE_COLORS: Record<string, string> = {
  moran:        '#1B9A8E',
  density:      '#FF8C00',
  combined:     '#8B5CF6',
  intersection: '#1A3A52',
}

const CLUSTER_COLORS: Record<string, string> = {
  HH: '#e63c3c',
  LL: '#3c6fe6',
  HL: '#e8941e',
  LH: '#5bb8f5',
  NS: '#cccccc',
}

// Module-level GeoJSON cache — persists across renders
const _geojsonCache = new Map<string, GeoJSON.FeatureCollection>()

interface Props {
  visibleLayers: WorkingLayerMeta[]
}

// ── Colour expression builder (same logic as before, extracted) ───────────────

function buildColorExpr(
  layer: WorkingLayerMeta,
  fc: GeoJSON.FeatureCollection,
): maplibregl.ExpressionSpecification {
  if (layer.type === 'lisa') {
    return [
      'match', ['get', 'lisa_cluster_type'],
      'HH', CLUSTER_COLORS.HH,
      'LL', CLUSTER_COLORS.LL,
      'HL', CLUSTER_COLORS.HL,
      'LH', CLUSTER_COLORS.LH,
      CLUSTER_COLORS.NS,
    ]
  }

  if (layer.type === 'intersection') {
    // Use LISA cluster colors if available, otherwise teal
    if (_hasCol(fc, 'lisa_cluster_type') || _hasCol(fc, 'lisa_cluster_type_lisa')) {
      const col = _hasCol(fc, 'lisa_cluster_type') ? 'lisa_cluster_type' : 'lisa_cluster_type_lisa'
      return [
        'match', ['get', col],
        'HH', CLUSTER_COLORS.HH,
        'LL', CLUSTER_COLORS.LL,
        'HL', CLUSTER_COLORS.HL,
        'LH', CLUSTER_COLORS.LH,
        TYPE_COLORS.intersection,
      ]
    }
    return TYPE_COLORS.intersection as unknown as maplibregl.ExpressionSpecification
  }

  if (layer.type === 'density') {
    const densityGradient: maplibregl.ExpressionSpecification = [
      'interpolate', ['linear'],
      ['coalesce', ['get', 'density_normalized'], 0],
      0,    '#ffeda0',
      0.25, '#feb24c',
      0.5,  '#fc4e2a',
      0.75, '#bd0026',
      1,    '#800026',
    ]
    if (_hasCol(fc, 'above_density_threshold')) {
      return [
        'case',
        ['==', ['get', 'above_density_threshold'], true],
        densityGradient,
        '#d8d8d8',
      ]
    }
    return densityGradient
  }

  if (layer.type === 'moran') {
    return [
      'case',
      ['==', ['get', 'moran_significant'], true], TYPE_COLORS.moran,
      '#e0e0e0',
    ]
  }

  // combined
  const hasLisa    = _hasCol(fc, 'lisa_cluster_type_lisa')
  const hasDensity = _hasCol(fc, 'above_density_threshold_density')

  if (hasLisa && hasDensity) {
    return [
      'case',
      ['all',
        ['==', ['coalesce', ['get', 'above_density_threshold_density'], false], true],
        ['in', ['get', 'lisa_cluster_type_lisa'], ['literal', ['HH', 'LL', 'HL', 'LH']]],
      ],
      ['match', ['get', 'lisa_cluster_type_lisa'],
        'HH', CLUSTER_COLORS.HH,
        'LL', CLUSTER_COLORS.LL,
        'HL', CLUSTER_COLORS.HL,
        'LH', CLUSTER_COLORS.LH,
        CLUSTER_COLORS.NS,
      ],
      '#d8d8d8',
    ]
  }
  if (hasDensity) {
    return [
      'case',
      ['==', ['get', 'above_density_threshold_density'], true], '#FF8C00',
      '#d8d8d8',
    ]
  }
  if (hasLisa) {
    return [
      'match', ['get', 'lisa_cluster_type_lisa'],
      'HH', CLUSTER_COLORS.HH, 'LL', CLUSTER_COLORS.LL,
      'HL', CLUSTER_COLORS.HL, 'LH', CLUSTER_COLORS.LH,
      CLUSTER_COLORS.NS,
    ]
  }
  return TYPE_COLORS.combined as unknown as maplibregl.ExpressionSpecification
}

function buildOpacityExpr(
  fc: GeoJSON.FeatureCollection,
  high: number,
  low: number,
): maplibregl.ExpressionSpecification | number {
  const col = _hasCol(fc, 'above_density_threshold')
    ? 'above_density_threshold'
    : _hasCol(fc, 'above_density_threshold_density')
      ? 'above_density_threshold_density'
      : null
  if (col) {
    return ['case', ['==', ['coalesce', ['get', col], false], true], high, low]
  }
  return high
}

// ── Section key helpers ───────────────────────────────────────────────────────

function getSectionKey(props: Record<string, unknown>): string | null {
  const entidad = props['ID_ENTIDAD'] ?? props['ENTIDAD']
  const seccion = props['SECCION']
  if (entidad == null || seccion == null) return null
  return `${Math.round(Number(entidad))}_${Math.round(Number(seccion))}`
}

function isSignificant(props: Record<string, unknown>, type: string): boolean {
  if (type === 'lisa') {
    const cluster = props['lisa_cluster_type'] as string
    return ['HH', 'LL', 'HL', 'LH'].includes(cluster)
  }
  if (type === 'density') return props['above_density_threshold'] === true
  if (type === 'moran') return props['moran_significant'] === true
  return true // combined / intersection: all features are significant
}

function computeIntersectionFeatures(
  layers: WorkingLayerMeta[],
): GeoJSON.Feature[] {
  if (layers.length < 2) return []

  const keysets: Set<string>[] = layers.map((wl) => {
    const fc = _geojsonCache.get(wl.id)
    if (!fc) return new Set<string>()
    const s = new Set<string>()
    for (const feat of fc.features) {
      const props = feat.properties ?? {}
      const key = getSectionKey(props as Record<string, unknown>)
      if (key && isSignificant(props as Record<string, unknown>, wl.type)) {
        s.add(key)
      }
    }
    return s
  })

  // Intersection of all key sets
  let common = keysets[0]
  for (let i = 1; i < keysets.length; i++) {
    const next = new Set<string>()
    for (const k of common) if (keysets[i].has(k)) next.add(k)
    common = next
  }

  if (common.size === 0) return []

  // Return first layer's geometries for matching keys
  const baseFC = _geojsonCache.get(layers[0].id)!
  return baseFC.features.filter((f) => {
    const key = getSectionKey((f.properties ?? {}) as Record<string, unknown>)
    return key != null && common.has(key)
  })
}

// ── Hatch pattern ─────────────────────────────────────────────────────────────

function addHatchImage(map: maplibregl.Map): void {
  const size = 16
  const canvas = document.createElement('canvas')
  canvas.width = size
  canvas.height = size
  const ctx = canvas.getContext('2d')!
  ctx.clearRect(0, 0, size, size)
  ctx.strokeStyle = 'rgba(20, 20, 50, 0.85)'
  ctx.lineWidth = 2
  // Forward diagonal lines
  for (let offset = -size; offset <= size * 2; offset += 8) {
    ctx.beginPath()
    ctx.moveTo(offset, 0)
    ctx.lineTo(offset + size, size)
    ctx.stroke()
  }
  const imgData = ctx.getImageData(0, 0, size, size)
  if (!map.hasImage('hatch-pattern')) {
    map.addImage('hatch-pattern', imgData, { pixelRatio: 2 })
  }
}

// ── Main component ─────────────────────────────────────────────────────────────

export function WorkingLayerMapEmbed({ visibleLayers }: Props) {
  const containerRef  = useRef<HTMLDivElement>(null)
  const mapRef        = useRef<maplibregl.Map | null>(null)
  const [mapLoaded, setMapLoaded] = useState(false)
  const loadedIds     = useRef<Set<string>>(new Set())
  const [loadingIds, setLoadingIds] = useState<Set<string>>(new Set())
  const [error, setError] = useState<string | null>(null)
  const [intersectionCount, setIntersectionCount] = useState(0)

  // ── Map init (once) ─────────────────────────────────────────────
  useEffect(() => {
    if (!containerRef.current) return
    const map = new maplibregl.Map({
      container: containerRef.current,
      style:     BASEMAP_STYLE,
      center:    [-102, 23.5],
      zoom:      4.5,
      attributionControl: false,
    })
    map.addControl(new maplibregl.NavigationControl({ showCompass: false }), 'top-right')

    map.on('load', () => {
      addHatchImage(map)

      // Intersection overlay source + layers (always present, starts empty)
      map.addSource('wl-intersection', { type: 'geojson', data: EMPTY_FC })
      map.addLayer({
        id:     'wl-intersection-fill',
        type:   'fill',
        source: 'wl-intersection',
        paint: {
          'fill-pattern':  'hatch-pattern',
          'fill-opacity':  0.9,
        },
      })
      map.addLayer({
        id:     'wl-intersection-line',
        type:   'line',
        source: 'wl-intersection',
        paint: {
          'line-color':   '#1A3A52',
          'line-width':   2,
          'line-opacity': 0.9,
        },
      })

      // Popup for all wl-fill-* layers
      const popup = new maplibregl.Popup({
        closeButton: false,
        closeOnClick: false,
        maxWidth: '320px',
      })

      map.on('mousemove', (e) => {
        const layers = map.getStyle().layers
          .map((l) => l.id)
          .filter((id) => id.startsWith('wl-fill-'))
        if (layers.length === 0) return

        const features = map.queryRenderedFeatures(e.point, { layers })
        if (!features.length) { popup.remove(); map.getCanvas().style.cursor = ''; return }

        map.getCanvas().style.cursor = 'pointer'
        const props = features[0].properties ?? {}
        const rows = Object.entries(props)
          .filter(([k]) => !k.startsWith('__'))
          .slice(0, 12)
          .map(([k, v]) =>
            `<div class="popup-row"><span class="popup-key">${k}</span><span class="popup-val">${v ?? '—'}</span></div>`,
          )
          .join('')
        popup.setLngLat(e.lngLat).setHTML(`<div class="popup-table">${rows}</div>`).addTo(map)
      })

      map.on('mouseleave', () => { popup.remove(); map.getCanvas().style.cursor = '' })

      setMapLoaded(true)
    })

    mapRef.current = map
    return () => { map.remove(); mapRef.current = null }
  }, [])

  // ── Sync visible layers to MapLibre ────────────────────────────
  useEffect(() => {
    const map = mapRef.current
    if (!map || !mapLoaded) return

    const visibleIds = new Set(visibleLayers.map((l) => l.id))

    // Remove layers that are no longer visible
    for (const id of [...loadedIds.current]) {
      if (!visibleIds.has(id)) {
        if (map.getLayer(`wl-line-${id}`)) map.removeLayer(`wl-line-${id}`)
        if (map.getLayer(`wl-fill-${id}`)) map.removeLayer(`wl-fill-${id}`)
        if (map.getSource(`wl-src-${id}`))  map.removeSource(`wl-src-${id}`)
        loadedIds.current.delete(id)
      }
    }

    // Add layers that are newly visible
    const toLoad = visibleLayers.filter((l) => !loadedIds.current.has(l.id))

    if (toLoad.length === 0) {
      // All needed layers are already loaded — just update intersection
      refreshIntersection(map, visibleLayers)
      fitBounds(map, visibleLayers)
      return
    }

    setLoadingIds((prev) => {
      const next = new Set(prev)
      toLoad.forEach((l) => next.add(l.id))
      return next
    })
    setError(null)

    Promise.all(
      toLoad.map(async (wl) => {
        if (!_geojsonCache.has(wl.id)) {
          const fc = await fetchWorkingLayerGeoJSON(wl.id)
          _geojsonCache.set(wl.id, fc)
        }
        return wl
      }),
    )
      .then((loaded) => {
        if (!mapRef.current) return
        const m = mapRef.current

        for (const wl of loaded) {
          if (loadedIds.current.has(wl.id)) continue // guard double-add
          const fc = _geojsonCache.get(wl.id)!

          m.addSource(`wl-src-${wl.id}`, { type: 'geojson', data: fc as GeoJSON.FeatureCollection })

          // Insert below the intersection overlay
          const beforeId = m.getLayer('wl-intersection-fill') ? 'wl-intersection-fill' : undefined

          m.addLayer({
            id:     `wl-fill-${wl.id}`,
            type:   'fill',
            source: `wl-src-${wl.id}`,
            paint:  {
              'fill-color':   buildColorExpr(wl, fc),
              'fill-opacity': buildOpacityExpr(fc, 0.72, 0.22),
            },
          }, beforeId)

          m.addLayer({
            id:     `wl-line-${wl.id}`,
            type:   'line',
            source: `wl-src-${wl.id}`,
            paint:  { 'line-color': '#1A3A52', 'line-width': 0.5, 'line-opacity': 0.6 },
          }, beforeId)

          loadedIds.current.add(wl.id)
        }

        refreshIntersection(m, visibleLayers)
        fitBounds(m, visibleLayers)

        setLoadingIds((prev) => {
          const next = new Set(prev)
          loaded.forEach((l) => next.delete(l.id))
          return next
        })
      })
      .catch((e: unknown) => {
        setError(e instanceof Error ? e.message : 'Error cargando capa')
        setLoadingIds(new Set())
      })

    // eslint-disable-next-line react-hooks/exhaustive-deps
  }, [mapLoaded, visibleLayers.map((l) => l.id).join(',')])

  function refreshIntersection(map: maplibregl.Map, layers: WorkingLayerMeta[]) {
    const src = map.getSource('wl-intersection') as maplibregl.GeoJSONSource | undefined
    if (!src) return

    // Only compute if all needed GeoJSONs are cached
    const allCached = layers.every((l) => _geojsonCache.has(l.id))
    if (layers.length >= 2 && allCached) {
      const features = computeIntersectionFeatures(layers)
      setIntersectionCount(features.length)
      src.setData({ type: 'FeatureCollection', features })
    } else {
      setIntersectionCount(0)
      src.setData(EMPTY_FC)
    }
  }

  function fitBounds(map: maplibregl.Map, layers: WorkingLayerMeta[]) {
    let minLng = Infinity, maxLng = -Infinity, minLat = Infinity, maxLat = -Infinity
    for (const wl of layers) {
      const fc = _geojsonCache.get(wl.id)
      if (!fc) continue
      for (const f of fc.features) {
        walkCoords(f.geometry as GeoJSON.Geometry | null, (lng, lat) => {
          if (lng < minLng) minLng = lng
          if (lng > maxLng) maxLng = lng
          if (lat < minLat) minLat = lat
          if (lat > maxLat) maxLat = lat
        })
      }
    }
    if (minLng !== Infinity) {
      map.fitBounds([[minLng, minLat], [maxLng, maxLat]], { padding: 40, maxZoom: 14, duration: 800 })
    }
  }

  const isLoading = loadingIds.size > 0

  return (
    <div style={{ position: 'absolute', inset: 0 }}>
      <div ref={containerRef} style={{ width: '100%', height: '100%', borderRadius: 8 }} />

      {isLoading && (
        <div style={{
          position: 'absolute', inset: 0, display: 'flex', alignItems: 'center',
          justifyContent: 'center', background: 'rgba(255,255,255,0.7)', borderRadius: 8,
        }}>
          <div className="loading-ring" />
        </div>
      )}

      {error && (
        <div style={{
          position: 'absolute', inset: 0, display: 'flex', flexDirection: 'column',
          alignItems: 'center', justifyContent: 'center', padding: 24, textAlign: 'center',
        }}>
          <div style={{ fontSize: 24 }}>⚠️</div>
          <div style={{ color: '#b91c1c', marginTop: 8, fontSize: 13 }}>{error}</div>
        </div>
      )}

      {/* Intersection badge */}
      {intersectionCount > 0 && !isLoading && (
        <div style={{
          position: 'absolute', bottom: 12, left: 12,
          background: 'rgba(26,58,82,0.92)', color: '#fff',
          padding: '6px 12px', borderRadius: 8, fontSize: 12, fontWeight: 600,
          boxShadow: '0 2px 8px rgba(0,0,0,0.3)',
          display: 'flex', alignItems: 'center', gap: 6,
        }}>
          <span style={{
            display: 'inline-block', width: 12, height: 12,
            background: 'repeating-linear-gradient(45deg,#fff 0,#fff 2px,transparent 2px,transparent 6px)',
            border: '1px solid #fff', borderRadius: 2,
          }} />
          {intersectionCount} sección{intersectionCount !== 1 ? 'es' : ''} en intersección
        </div>
      )}
    </div>
  )
}

// ── Utilities ──────────────────────────────────────────────────────────────────

function _hasCol(fc: GeoJSON.FeatureCollection, col: string): boolean {
  return (fc.features[0]?.properties ?? {})[col] !== undefined
}

function walkCoords(
  geom: GeoJSON.Geometry | null,
  cb: (lng: number, lat: number) => void,
): void {
  if (!geom) return
  if (geom.type === 'Point') {
    cb(geom.coordinates[0], geom.coordinates[1])
  } else if (geom.type === 'LineString' || geom.type === 'MultiPoint') {
    for (const c of geom.coordinates) cb(c[0], c[1])
  } else if (geom.type === 'Polygon' || geom.type === 'MultiLineString') {
    for (const ring of geom.coordinates) for (const c of ring) cb(c[0], c[1])
  } else if (geom.type === 'MultiPolygon') {
    for (const poly of geom.coordinates) for (const ring of poly) for (const c of ring) cb(c[0], c[1])
  }
}
