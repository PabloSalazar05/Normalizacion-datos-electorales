import { useState } from 'react'
import { useWorkingLayersStore } from '../../store/workingLayersStore'
import {
  deleteWorkingLayer,
  renameWorkingLayer,
  combineLayers,
  downloadWorkingLayerExcel,
  createIntersectionLayer,
  type WorkingLayerMeta,
} from '../../api/workingLayersApi'
import { WorkingLayerMapEmbed } from './WorkingLayerMapEmbed'
import './WorkingLayerManager.css'

const TYPE_LABEL: Record<string, string> = {
  moran:        "Moran's I",
  lisa:         'LISA',
  density:      'Densidad',
  combined:     'Combinada',
  intersection: 'Intersección',
}

export function WorkingLayerManager() {
  const {
    layers, selectedIds, visibleIds,
    removeLayer, upsertLayer, toggleSelected, clearSelected, toggleVisible,
  } = useWorkingLayersStore()

  const [combineLoading, setCombineLoading]         = useState(false)
  const [combineError, setCombineError]             = useState<string | null>(null)
  const [intersectLoading, setIntersectLoading]     = useState(false)
  const [intersectError, setIntersectError]         = useState<string | null>(null)
  const [renamingId, setRenamingId]                 = useState<string | null>(null)
  const [renameValue, setRenameValue]               = useState('')
  const [exportingId, setExportingId]               = useState<string | null>(null)

  const visibleLayers = layers.filter((l) => visibleIds.includes(l.id))

  // ── Actions ──────────────────────────────────────────────────

  async function handleDelete(id: string) {
    try {
      await deleteWorkingLayer(id)
      removeLayer(id)
    } catch (e) {
      console.error('Delete failed:', e)
    }
  }

  function startRename(layer: WorkingLayerMeta) {
    setRenamingId(layer.id)
    setRenameValue(layer.name)
  }

  async function commitRename(id: string) {
    if (!renameValue.trim()) { setRenamingId(null); return }
    try {
      const updated = await renameWorkingLayer(id, renameValue.trim())
      upsertLayer(updated)
    } catch (e) {
      console.error('Rename failed:', e)
    } finally {
      setRenamingId(null)
    }
  }

  async function handleCombine() {
    if (selectedIds.length < 2) return
    setCombineLoading(true)
    setCombineError(null)
    try {
      const combined = await combineLayers(selectedIds)
      upsertLayer(combined)
      clearSelected()
    } catch (e: unknown) {
      setCombineError(e instanceof Error ? e.message : 'Error al combinar')
    } finally {
      setCombineLoading(false)
    }
  }

  async function handleIntersect() {
    if (visibleIds.length < 2) return
    setIntersectLoading(true)
    setIntersectError(null)
    try {
      const result = await createIntersectionLayer(visibleIds)
      upsertLayer(result)
    } catch (e: unknown) {
      setIntersectError(e instanceof Error ? e.message : 'Error al intersectar')
    } finally {
      setIntersectLoading(false)
    }
  }

  async function handleExport(layer: WorkingLayerMeta) {
    setExportingId(layer.id)
    try {
      await downloadWorkingLayerExcel(layer.id, layer.name)
    } catch (e) {
      console.error('Export failed:', e)
    } finally {
      setExportingId(null)
    }
  }

  // ── Render ───────────────────────────────────────────────────

  return (
    <div className="wl-layout">
      {/* ── Sidebar: layer list ─────────────────────────────── */}
      <aside className="wl-sidebar">
        <div className="wl-sidebar-header">
          <div className="wl-sidebar-title">Capas de trabajo</div>
          <div className="wl-sidebar-subtitle">
            {layers.length === 0
              ? 'Sin capas generadas'
              : `${layers.length} capa${layers.length !== 1 ? 's' : ''}`}
            {visibleIds.length > 0 && (
              <span style={{ marginLeft: 6, color: '#1B9A8E' }}>
                · {visibleIds.length} visible{visibleIds.length !== 1 ? 's' : ''}
              </span>
            )}
          </div>
        </div>

        <div className="wl-layer-list">
          {layers.length === 0 ? (
            <div className="wl-empty">
              <div className="wl-empty-icon">🗂️</div>
              <div>Genera capas desde las pestañas de análisis (Moran's I, LISA Clusters, Densidad).</div>
            </div>
          ) : (
            layers.map((layer) => {
              const isSelected  = selectedIds.includes(layer.id)
              const isVisible   = visibleIds.includes(layer.id)
              const isRenaming  = renamingId === layer.id
              const isExporting = exportingId === layer.id

              return (
                <div
                  key={layer.id}
                  className={`wl-card${isSelected ? ' selected' : ''}${isVisible ? ' displayed' : ''}`}
                >
                  <div className="wl-card-top">
                    <input
                      type="checkbox"
                      className="wl-card-checkbox"
                      checked={isSelected}
                      onChange={() => toggleSelected(layer.id)}
                      onClick={(e) => e.stopPropagation()}
                    />
                    <span className={`wl-type-badge wl-type-${layer.type}`}>
                      {TYPE_LABEL[layer.type] ?? layer.type}
                    </span>

                    {isRenaming ? (
                      <input
                        className="wl-card-name-input"
                        value={renameValue}
                        autoFocus
                        onChange={(e) => setRenameValue(e.target.value)}
                        onBlur={() => commitRename(layer.id)}
                        onKeyDown={(e) => {
                          if (e.key === 'Enter') commitRename(layer.id)
                          if (e.key === 'Escape') setRenamingId(null)
                        }}
                      />
                    ) : (
                      <span
                        className="wl-card-name"
                        title={layer.name}
                        onDoubleClick={() => startRename(layer)}
                      >
                        {layer.name}
                      </span>
                    )}
                  </div>

                  <div className="wl-card-meta">
                    <span>{layer.election_name}</span>
                    <span>{layer.variable.replace('_PCT', '')}</span>
                    <span>{layer.feature_count.toLocaleString('es-MX')} features</span>
                  </div>

                  <div className="wl-card-actions">
                    <button
                      className={`wl-action-btn primary${isVisible ? ' active' : ''}`}
                      onClick={() => toggleVisible(layer.id)}
                      title={isVisible ? 'Ocultar en mapa' : 'Ver en mapa'}
                    >
                      {isVisible ? '👁 Ocultar' : '🗺 Ver'}
                    </button>

                    <button
                      className="wl-action-btn"
                      onClick={() => startRename(layer)}
                      title="Renombrar"
                    >
                      ✏️ Renombrar
                    </button>

                    <button
                      className="wl-action-btn"
                      onClick={() => handleExport(layer)}
                      disabled={isExporting}
                      title="Exportar a Excel"
                    >
                      {isExporting ? '⏳' : '⬇'} Excel
                    </button>

                    <button
                      className="wl-action-btn danger"
                      onClick={() => handleDelete(layer.id)}
                      title="Eliminar capa"
                    >
                      🗑 Eliminar
                    </button>
                  </div>
                </div>
              )
            })
          )}
        </div>

        {/* Bottom toolbar */}
        <div className="wl-toolbar">
          {/* Intersection — only when ≥2 layers are visible */}
          {visibleIds.length >= 2 && (
            <div style={{ marginBottom: 6 }}>
              {intersectError && (
                <div className="wl-combine-error" style={{ marginBottom: 4 }}>{intersectError}</div>
              )}
              <button
                className="wl-combine-btn"
                style={{ background: 'var(--teal-primary, #1B9A8E)' }}
                onClick={handleIntersect}
                disabled={intersectLoading}
                title="Guardar las secciones marcadas (hachuras) como nueva capa de trabajo"
              >
                {intersectLoading
                  ? '⏳ Calculando…'
                  : `⊗ Guardar intersección (${visibleIds.length} capas)`}
              </button>
            </div>
          )}

          {/* Combine — attribute join of checked layers */}
          {selectedIds.length > 0 && (
            <div className="wl-toolbar-hint">
              {selectedIds.length} capa{selectedIds.length !== 1 ? 's' : ''} seleccionada{selectedIds.length !== 1 ? 's' : ''}
            </div>
          )}
          <button
            className="wl-combine-btn"
            onClick={handleCombine}
            disabled={selectedIds.length < 2 || combineLoading}
            title={selectedIds.length < 2 ? 'Selecciona ≥ 2 capas para combinar' : undefined}
          >
            {combineLoading ? '⏳ Combinando…' : '⊕ Combinar capas seleccionadas'}
          </button>
          {combineError && <div className="wl-combine-error">{combineError}</div>}
          {selectedIds.length < 2 && layers.length >= 1 && (
            <div className="wl-toolbar-hint">Marca ≥ 2 capas para habilitar combinar</div>
          )}
        </div>
      </aside>

      {/* ── Map area ────────────────────────────────────────── */}
      <div className="wl-map-area">
        {visibleLayers.length > 0 ? (
          <WorkingLayerMapEmbed visibleLayers={visibleLayers} />
        ) : (
          <div className="wl-map-placeholder">
            <div className="wl-map-placeholder-icon">🗺️</div>
            <div className="wl-map-placeholder-title">Sin capa activa</div>
            <div className="wl-map-placeholder-text">
              Haz clic en <strong>Ver</strong> en cualquier capa para visualizarla.
              <br />
              Activa <strong>dos o más capas</strong> para ver las secciones que se intersectan (hachuras)
              y guardar esa intersección como nueva capa.
            </div>
          </div>
        )}
      </div>
    </div>
  )
}
