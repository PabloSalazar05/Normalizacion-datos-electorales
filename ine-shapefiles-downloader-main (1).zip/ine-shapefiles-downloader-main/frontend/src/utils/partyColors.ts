// Party colors matching dashboard/src/dashboard/theme.py
export const PARTY_COLORS: Record<string, string> = {
  MORENA: '#9B1C1C',
  PAN: '#003F8A',
  PRI: '#CC0000',
  PRD: '#FFCC00',
  PVEM: '#5DA130',
  PT: '#8B0000',
  MC: '#FF6600',
}

export const MAJOR_PARTIES = Object.keys(PARTY_COLORS)

export function getPartyColor(party: string): string {
  return PARTY_COLORS[party.toUpperCase()] ?? '#1B9A8E'
}

/** Hex → [r, g, b] in 0-255 range */
function hexToRgb(hex: string): [number, number, number] {
  const c = hex.replace('#', '')
  return [
    parseInt(c.slice(0, 2), 16),
    parseInt(c.slice(2, 4), 16),
    parseInt(c.slice(4, 6), 16),
  ]
}

/**
 * Interpolate between white (#fff) and the party color based on pct (0-100).
 * Returns a CSS rgb() string.
 */
export function partyPctToColor(party: string, pct: number): string {
  const hex = getPartyColor(party)
  const [r2, g2, b2] = hexToRgb(hex)
  const t = Math.max(0, Math.min(1, pct / 100))
  const r = Math.round(255 + (r2 - 255) * t)
  const g = Math.round(255 + (g2 - 255) * t)
  const b = Math.round(255 + (b2 - 255) * t)
  return `rgb(${r},${g},${b})`
}
