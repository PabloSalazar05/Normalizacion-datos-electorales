/**
 * chartPopup.ts
 * Builds an inline HTML/SVG horizontal bar chart for MapLibre popups.
 */

import { PARTY_COLORS } from './partyColors'

const FALLBACK_COLOR = '#9ca3af'
const MAX_PARTIES = 9
const MIN_PCT = 0.5

/** Return party color, falling back to first coalition component. */
function partyColor(party: string): string {
  if (PARTY_COLORS[party]) return PARTY_COLORS[party]
  for (const part of party.split('-')) {
    if (PARTY_COLORS[part]) return PARTY_COLORS[part]
  }
  return FALLBACK_COLOR
}

function esc(s: string): string {
  return String(s)
    .replace(/&/g, '&amp;')
    .replace(/</g, '&lt;')
    .replace(/>/g, '&gt;')
    .replace(/"/g, '&quot;')
}

/**
 * Build a compact horizontal bar chart HTML string suitable for a MapLibre popup.
 *
 * @param title  - popup heading (e.g. "Sección 1404" or "Municipio 3 — Oaxaca")
 * @param pctData - flat record of properties; only keys ending in "_PCT" are used
 */
export function buildChartHTML(
  title: string,
  pctData: Record<string, number | null | undefined>,
): string {
  const parties = Object.entries(pctData)
    .filter(([k, v]) => k.endsWith('_PCT') && v != null && (v as number) >= MIN_PCT)
    .map(([k, v]) => ({ party: k.replace('_PCT', ''), pct: v as number }))
    .sort((a, b) => b.pct - a.pct)
    .slice(0, MAX_PARTIES)

  if (parties.length === 0) {
    return (
      `<div style="min-width:200px;font-size:13px;font-weight:700;color:#1A3A52">` +
      esc(title) +
      `</div>`
    )
  }

  const maxPct = parties[0].pct

  // Layout constants (px)
  const LW = 80   // label column width
  const BW = 118  // max bar width
  const VW = 40   // value column width
  const W  = LW + BW + VW
  const RH = 22   // row height

  const rows = parties
    .map(({ party, pct }, i) => {
      const y  = i * RH
      const bw = Math.max(2, Math.round((pct / maxPct) * BW))
      const color = partyColor(party)
      const label = party.length > 11 ? party.slice(0, 10) + '…' : party
      return (
        `<text x="0" y="${y + 15}" font-size="11.5" fill="#374151" ` +
        `font-family="system-ui,sans-serif" font-weight="500">${esc(label)}</text>` +
        `<rect x="${LW}" y="${y + 4}" width="${bw}" height="14" fill="${color}" rx="2" opacity="0.88"/>` +
        `<text x="${LW + BW + 4}" y="${y + 15}" font-size="11" fill="#6b7280" ` +
        `font-family="system-ui,sans-serif">${pct.toFixed(1)}%</text>`
      )
    })
    .join('')

  const svgH = parties.length * RH

  return (
    `<div style="min-width:${W + 12}px;max-width:${W + 12}px">` +
    `<p style="margin:0 0 7px;font-size:13px;font-weight:700;color:#1A3A52;` +
    `padding-bottom:5px;border-bottom:1px solid #e5e7eb;white-space:nowrap;` +
    `overflow:hidden;text-overflow:ellipsis">${esc(title)}</p>` +
    `<svg width="${W}" height="${svgH}" style="display:block;overflow:visible">${rows}</svg>` +
    `</div>`
  )
}
