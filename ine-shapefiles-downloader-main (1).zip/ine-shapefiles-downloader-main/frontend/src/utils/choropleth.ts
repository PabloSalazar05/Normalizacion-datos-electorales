import type { ExpressionSpecification } from 'maplibre-gl'
import { PARTY_COLORS } from './partyColors'

/** Lighten a hex color toward white. amount=0 → original, amount=1 → white. */
function lightenHex(hex: string, amount: number): string {
  const c = hex.replace('#', '')
  const r = parseInt(c.slice(0, 2), 16)
  const g = parseInt(c.slice(2, 4), 16)
  const b = parseInt(c.slice(4, 6), 16)
  const lr = Math.round(r + (255 - r) * amount)
  const lg = Math.round(g + (255 - g) * amount)
  const lb = Math.round(b + (255 - b) * amount)
  return `#${lr.toString(16).padStart(2, '0')}${lg.toString(16).padStart(2, '0')}${lb.toString(16).padStart(2, '0')}`
}

/**
 * Build a MapLibre 'interpolate' fill-color expression for a single party PCT column.
 * Colors range from white (0%) to the party's brand color (100%).
 */
export function buildSinglePartyExpression(
  partyPctColumn: string,
  partyHexColor: string,
): ExpressionSpecification {
  return [
    'interpolate',
    ['linear'],
    ['coalesce', ['get', partyPctColumn], 0],
    0, '#ffffff',
    50, partyHexColor + '88',  // semi-transparent midpoint
    100, partyHexColor,
  ] as ExpressionSpecification
}

/**
 * Build a 5-class quantile choropleth using data-driven breakpoints.
 * Each class gets an equal share of the actual data range, producing visually
 * distinct bands regardless of how clustered the values are.
 *
 * breakpoints: [p25, p50, p75, p98] computed from the actual feature values.
 *
 * Class colors (light → dark using party brand color):
 *   < p25  : very light gray-white
 *   < p50  : light (65% lightened party color)
 *   < p75  : medium-light (35% lightened)
 *   < p98  : medium (10% lightened)
 *   ≥ p98  : full party brand color
 */
export function buildQuantileChoroplethExpression(
  partyPctColumn: string,
  partyHexColor: string,
  breakpoints: [number, number, number, number],
): ExpressionSpecification {
  const [b1, b2, b3, b4] = breakpoints
  // Guard: if all breakpoints collapse to 0 fall back to simple expression
  if (b1 === 0 && b4 === 0) return buildSinglePartyExpression(partyPctColumn, partyHexColor)
  return [
    'step',
    ['coalesce', ['get', partyPctColumn], 0],
    '#f0f0f0',                          // < b1 : near-white
    b1, lightenHex(partyHexColor, 0.65), // b1–b2 : very light party color
    b2, lightenHex(partyHexColor, 0.38), // b2–b3 : light party color
    b3, lightenHex(partyHexColor, 0.15), // b3–b4 : medium party color
    b4, partyHexColor,                   // ≥ b4  : full party color
  ] as ExpressionSpecification
}

/**
 * Build a MapLibre 'case' fill-color expression that colors each polygon by
 * the party with the highest PCT value (winner-takes-all).
 *
 * Falls back to #cccccc when no PCT values are present.
 */
export function buildWinnerExpression(
  partyColumns: string[],
): ExpressionSpecification {
  if (partyColumns.length === 0) {
    return '#cccccc' as unknown as ExpressionSpecification
  }

  // Build a 'case' expression: check each party in descending order by value
  // Strategy: use 'step' approach with 'max' to find the winner
  // We build: if MORENA_PCT >= all others → MORENA color, etc.
  // This is done with nested 'case' conditions.

  const cases: ExpressionSpecification[] = []

  for (const pctCol of partyColumns) {
    const party = pctCol.replace('_PCT', '')
    const color = PARTY_COLORS[party] ?? '#888888'

    // Condition: this party's PCT is >= all others
    const otherCols = partyColumns.filter(c => c !== pctCol)
    const conditions: ExpressionSpecification[] = otherCols.map(other => [
      '>=',
      ['coalesce', ['get', pctCol], 0],
      ['coalesce', ['get', other], 0],
    ] as ExpressionSpecification)

    const allCondition: ExpressionSpecification =
      conditions.length === 0
        ? ['literal', true] as unknown as ExpressionSpecification
        : conditions.length === 1
          ? conditions[0]
          : (['all', ...conditions] as unknown as ExpressionSpecification)

    cases.push(allCondition, color as unknown as ExpressionSpecification)
  }

  return ['case', ...cases, '#cccccc'] as unknown as ExpressionSpecification
}

/**
 * Return the list of PCT column names found in the first feature of a collection.
 */
export function getPctColumns(features: GeoJSON.Feature[]): string[] {
  if (!features.length) return []
  const props = features[0].properties ?? {}
  return Object.keys(props).filter(k => k.endsWith('_PCT'))
}
