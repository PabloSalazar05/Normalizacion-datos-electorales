/** Compute bounding box from a FeatureCollection or single Feature. */
export function computeBBox(
  fc: GeoJSON.FeatureCollection | GeoJSON.Feature,
): [number, number, number, number] {
  let minLng = Infinity, minLat = Infinity, maxLng = -Infinity, maxLat = -Infinity

  function walk(val: unknown) {
    if (Array.isArray(val)) {
      if (typeof val[0] === 'number') {
        minLng = Math.min(minLng, val[0] as number)
        minLat = Math.min(minLat, val[1] as number)
        maxLng = Math.max(maxLng, val[0] as number)
        maxLat = Math.max(maxLat, val[1] as number)
      } else {
        val.forEach(walk)
      }
    }
  }

  const features = fc.type === 'FeatureCollection' ? fc.features : [fc as GeoJSON.Feature]
  for (const f of features) {
    if (f.geometry) walk((f.geometry as GeoJSON.Polygon).coordinates)
  }
  return [minLng, minLat, maxLng, maxLat]
}
