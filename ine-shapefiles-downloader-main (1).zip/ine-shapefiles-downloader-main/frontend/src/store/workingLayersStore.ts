import { create } from 'zustand'
import type { WorkingLayerMeta } from '../api/workingLayersApi'

interface WorkingLayersStore {
  /** Full list of layer metadata (no GeoJSON) */
  layers: WorkingLayerMeta[]

  /** IDs checked for combine / export */
  selectedIds: string[]

  /** IDs of layers currently visible on the map (multi-layer) */
  visibleIds: string[]

  /** Actions */
  setLayers: (layers: WorkingLayerMeta[]) => void
  upsertLayer: (layer: WorkingLayerMeta) => void
  removeLayer: (id: string) => void

  toggleSelected: (id: string) => void
  clearSelected: () => void

  toggleVisible: (id: string) => void
  setVisibleIds: (ids: string[]) => void
}

export const useWorkingLayersStore = create<WorkingLayersStore>((set) => ({
  layers:      [],
  selectedIds: [],
  visibleIds:  [],

  setLayers: (layers) => set({ layers }),

  upsertLayer: (layer) =>
    set((s) => {
      const idx = s.layers.findIndex((l) => l.id === layer.id)
      if (idx >= 0) {
        const next = [...s.layers]
        next[idx] = layer
        return { layers: next }
      }
      return { layers: [...s.layers, layer] }
    }),

  removeLayer: (id) =>
    set((s) => ({
      layers:      s.layers.filter((l) => l.id !== id),
      selectedIds: s.selectedIds.filter((sid) => sid !== id),
      visibleIds:  s.visibleIds.filter((vid) => vid !== id),
    })),

  toggleSelected: (id) =>
    set((s) =>
      s.selectedIds.includes(id)
        ? { selectedIds: s.selectedIds.filter((sid) => sid !== id) }
        : { selectedIds: [...s.selectedIds, id] },
    ),

  clearSelected: () => set({ selectedIds: [] }),

  toggleVisible: (id) =>
    set((s) =>
      s.visibleIds.includes(id)
        ? { visibleIds: s.visibleIds.filter((vid) => vid !== id) }
        : { visibleIds: [...s.visibleIds, id] },
    ),

  setVisibleIds: (ids) => set({ visibleIds: ids }),
}))
