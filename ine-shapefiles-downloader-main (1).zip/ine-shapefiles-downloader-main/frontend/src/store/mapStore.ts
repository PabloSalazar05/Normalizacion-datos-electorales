import { create } from 'zustand'
import type { LayerName } from '../types/layers'

export type ActiveView = 'map' | 'morans' | 'lisa' | 'density' | 'layers'

interface MapStore {
  // View routing
  activeView: ActiveView

  // Layer state — multiple layers can be active (checkboxes)
  layersReady: boolean
  activeLayers: LayerName[]   // first element = primary (gets choropleth fill)
  layerOpacity: number        // shared opacity for the primary fill
  showLabels: boolean

  // Election / party state
  electionName: string
  partyFilter: string | null   // null = ganador por partido
  selectedEntidad: number | null
  selectedMunicipio: number | null
  selectedDistritoFederal: number | null
  selectedDistritoLocal: number | null

  // Persistent bbox of the selected municipality (kept until municipality is cleared)
  // Used by analysis embed maps to pre-position at municipality level.
  selectedMunicipioBbox: [number, number, number, number] | null

  // National sections mode — show all sections coloured by winner in national view
  showNationalSections: boolean

  // Map navigation
  flyToBbox: [number, number, number, number] | null

  // Actions
  setActiveView: (view: ActiveView) => void
  setLayersReady: (ready: boolean) => void
  setActiveLayers: (layers: LayerName[]) => void
  toggleLayer: (layer: LayerName) => void
  setLayerOpacity: (opacity: number) => void
  setShowLabels: (show: boolean) => void
  setElectionName: (name: string) => void
  setPartyFilter: (party: string | null) => void
  setSelectedEntidad: (id: number | null) => void
  setSelectedMunicipio: (id: number | null) => void
  setSelectedDistritoFederal: (id: number | null) => void
  setSelectedDistritoLocal: (id: number | null) => void
  setSelectedMunicipioBbox: (bbox: [number, number, number, number] | null) => void
  setShowNationalSections: (show: boolean) => void
  setFlyToBbox: (bbox: [number, number, number, number] | null) => void
}

// Only tabs that are strictly state-only get reset when deselecting
const ANALYSIS_VIEWS: ActiveView[] = ['morans', 'lisa']

export const useMapStore = create<MapStore>((set) => ({
  activeView: 'map',
  layersReady: false,
  activeLayers: ['seccion'],
  layerOpacity: 0.75,
  showLabels: false,
  electionName: 'PRES_2024',
  partyFilter: null,
  selectedEntidad: null,
  selectedMunicipio: null,
  selectedDistritoFederal: null,
  selectedDistritoLocal: null,
  selectedMunicipioBbox: null,
  showNationalSections: false,
  flyToBbox: null,

  setActiveView: (view) => set({ activeView: view }),
  setLayersReady: (ready) => set({ layersReady: ready }),
  setActiveLayers: (layers) => set({ activeLayers: layers }),
  toggleLayer: (layer) =>
    set((s) => {
      const has = s.activeLayers.includes(layer)
      if (has) {
        // Keep at least one layer active
        if (s.activeLayers.length === 1) return s
        return { activeLayers: s.activeLayers.filter((l) => l !== layer) }
      }
      return { activeLayers: [...s.activeLayers, layer] }
    }),
  setLayerOpacity: (opacity) => set({ layerOpacity: opacity }),
  setShowLabels: (show) => set({ showLabels: show }),
  setElectionName: (name) => set({ electionName: name }),
  setPartyFilter: (party) => set({ partyFilter: party }),
  setSelectedEntidad: (id) =>
    set((s) => ({
      selectedEntidad: id,
      // Only clear sub-selections when navigating to a DIFFERENT (or null) state.
      selectedMunicipio: id !== s.selectedEntidad ? null : s.selectedMunicipio,
      selectedDistritoFederal: id !== s.selectedEntidad ? null : s.selectedDistritoFederal,
      selectedDistritoLocal: id !== s.selectedEntidad ? null : s.selectedDistritoLocal,
      selectedMunicipioBbox: id !== s.selectedEntidad ? null : s.selectedMunicipioBbox,
      // When deselecting state, reset to map view if on an analysis-only tab
      activeView:
        id == null && ANALYSIS_VIEWS.includes(s.activeView) ? 'map' : s.activeView,
    })),
  setSelectedMunicipio: (id) => set({
    selectedMunicipio: id,
    selectedDistritoFederal: null,
    selectedDistritoLocal: null,
    ...(id == null ? { selectedMunicipioBbox: null } : {}),
  }),
  setSelectedDistritoFederal: (id) => set({
    selectedDistritoFederal: id,
    selectedMunicipio: null,
    selectedDistritoLocal: null,
    selectedMunicipioBbox: null,
  }),
  setSelectedDistritoLocal: (id) => set({
    selectedDistritoLocal: id,
    selectedMunicipio: null,
    selectedDistritoFederal: null,
    selectedMunicipioBbox: null,
  }),
  setSelectedMunicipioBbox: (bbox) => set({ selectedMunicipioBbox: bbox }),
  setShowNationalSections: (show) => set({ showNationalSections: show }),
  setFlyToBbox: (bbox) => set({ flyToBbox: bbox }),
}))
