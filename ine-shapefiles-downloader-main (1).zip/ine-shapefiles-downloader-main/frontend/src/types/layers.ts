export type LayerName =
  | 'seccion'
  | 'municipio'
  | 'distrito_federal'
  | 'distrito_local'
  | 'entidad'

export interface LayerConfig {
  display_name: string
  shapefile_source: 'peepjf' | 'nacional'
  shapefile_name: string
  simplification_tolerance: number
  label_column: string
  enabled: boolean
}

export interface LayersConfigResponse {
  version: number
  layers: Record<LayerName, LayerConfig>
}

export interface LayerStatus {
  ready: boolean
  progress: { processed: number; total: number }
}

export interface ElectoralJoinRequest {
  election_name: string
  entidad_ids?: number[]
  party?: string
}

export interface ElectoralFeature extends GeoJSON.Feature {
  properties: Record<string, string | number | null>
}

export interface ElectoralCollection extends GeoJSON.FeatureCollection {
  features: ElectoralFeature[]
  warnings?: string[]
}
