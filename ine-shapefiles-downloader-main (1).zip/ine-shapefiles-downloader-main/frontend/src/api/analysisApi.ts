export type GranularityType = 'section' | 'municipio' | 'distrito_federal'

// ── Moran's I ─────────────────────────────────────────────────────

export interface MoranRequest {
  election_name: string
  variable: string
  analysis_level: 'national' | 'state' | 'municipality'
  entidad_id?: number
  municipio_id?: number
  granularity: GranularityType
  weights_type?: string
  permutations?: number
}

export interface MoranResult {
  election_name: string
  entidad_id: number
  moran_i: number
  z_score: number
  p_value: number
  significant: boolean
  interpretation: string
  n_observations: number
  mean_neighbors: number
  islands: number
  expected_i: number
}

export interface SpatialVariables {
  percentage_variables: string[]
  other_numeric_variables: string[]
  total_numeric_columns: number
}

export async function fetchSpatialVariables(
  electionName: string,
  entidadId: number,
): Promise<SpatialVariables> {
  const res = await fetch(`/api/spatial/variables/${electionName}/${entidadId}`)
  if (!res.ok) throw new Error(`Variables fetch failed: ${res.status}`)
  return res.json()
}

export async function fetchMoranI(req: MoranRequest): Promise<MoranResult> {
  const res = await fetch('/api/spatial/moran', {
    method: 'POST',
    headers: { 'Content-Type': 'application/json' },
    body: JSON.stringify(req),
  })
  if (!res.ok) {
    const err = await res.json().catch(() => ({}))
    throw new Error(err.detail ?? `Moran's I request failed: ${res.status}`)
  }
  return res.json()
}

// ── Local Moran's I (LISA) ────────────────────────────────────────

export type LISAClusterType = 'HH' | 'LL' | 'HL' | 'LH' | 'NS'

export interface LISARequest {
  election_name: string
  variable: string
  analysis_level: 'national' | 'state' | 'municipality'
  entidad_id?: number
  municipio_id?: number
  granularity: GranularityType
  weights_type?: 'queen' | 'rook'
  permutations?: number
  significance?: number
}

export interface LISAResult {
  election_name: string
  entidad_id: number
  entidad_name: string
  variable: string
  granularity: string
  n_observations: number
  n_significant: number
  mean_neighbors: number
  islands: number
  cluster_counts: Record<LISAClusterType, number>
  geojson: Record<string, unknown>
}

export async function fetchLISA(req: LISARequest): Promise<LISAResult> {
  const res = await fetch('/api/spatial/lisa', {
    method: 'POST',
    headers: { 'Content-Type': 'application/json' },
    body: JSON.stringify(req),
  })
  if (!res.ok) {
    const err = await res.json().catch(() => ({}))
    throw new Error(err.detail ?? `LISA request failed: ${res.status}`)
  }
  return res.json()
}

// ── Electoral Density ─────────────────────────────────────────────

export interface DensityRequest {
  election_name: string
  analysis_level: 'national' | 'state'
  granularity: GranularityType
  entidad_id?: number
  density_min?: number
  style?: 'interactive' | 'static'
}

export interface DensityMapResponse {
  content: string
  content_type: string
  encoding: string
}

export interface DensityPrecomputedResponse {
  election_name: string
  entidad_id: number | null
  data: Record<string, number>
}

export async function fetchDensityPrecomputed(
  electionName: string,
  entidadId?: number,
): Promise<DensityPrecomputedResponse> {
  const params = new URLSearchParams({ election_name: electionName })
  if (entidadId !== undefined) params.set('entidad_id', String(entidadId))
  const res = await fetch(`/api/viz/density-precomputed?${params}`)
  if (!res.ok) {
    const err = await res.json().catch(() => ({}))
    throw new Error(err.detail ?? `Density precomputed request failed: ${res.status}`)
  }
  return res.json()
}

export async function fetchDensityMap(req: DensityRequest): Promise<DensityMapResponse> {
  const res = await fetch('/api/viz/density-map', {
    method: 'POST',
    headers: { 'Content-Type': 'application/json' },
    body: JSON.stringify(req),
  })
  if (!res.ok) {
    const err = await res.json().catch(() => ({}))
    throw new Error(err.detail ?? `Density map request failed: ${res.status}`)
  }
  return res.json()
}

// ── Cumulative Electoral Density ─────────────────────────────────

export type CumulativeLevelType = 'national' | 'state' | 'municipal'

export interface CumulativeDensityRequest {
  election_name: string
  analysis_level: CumulativeLevelType
  entidad_id?: number
  municipio_id?: number
  threshold?: number
  party?: string
  focus_bbox?: [number, number, number, number] | null  // [minLng, minLat, maxLng, maxLat]
}

export interface CumulativeStatsResponse {
  total_secciones: number
  secciones_in_threshold: number
  pct_secciones: number
  geographic_concentration: number
  top_municipios: Array<{ entidad_id: number; municipio: number; secciones: number }>
  top_estados: Array<{ entidad_id: number; secciones: number }>
}

export async function fetchCumulativeDensityMap(
  req: CumulativeDensityRequest,
): Promise<DensityMapResponse> {
  const res = await fetch('/api/viz/density-cumulative', {
    method: 'POST',
    headers: { 'Content-Type': 'application/json' },
    body: JSON.stringify(req),
  })
  if (!res.ok) {
    const err = await res.json().catch(() => ({}))
    throw new Error(err.detail ?? `Cumulative density map request failed: ${res.status}`)
  }
  return res.json()
}

export async function fetchCumulativeStats(
  req: CumulativeDensityRequest,
): Promise<CumulativeStatsResponse> {
  const res = await fetch('/api/viz/density-cumulative/stats', {
    method: 'POST',
    headers: { 'Content-Type': 'application/json' },
    body: JSON.stringify(req),
  })
  if (!res.ok) {
    const err = await res.json().catch(() => ({}))
    throw new Error(err.detail ?? `Cumulative density stats request failed: ${res.status}`)
  }
  return res.json()
}

export async function downloadDensityExport(params: {
  election_name: string
  entidad_id: number
  granularity: 'section' | 'municipio'
  threshold_pct: number
}): Promise<void> {
  const res = await fetch('/api/viz/density-export', {
    method: 'POST',
    headers: { 'Content-Type': 'application/json' },
    body: JSON.stringify(params),
  })
  if (!res.ok) {
    const err = await res.json().catch(() => ({}))
    throw new Error(err.detail ?? `Export failed: ${res.status}`)
  }
  const blob = await res.blob()
  const url = URL.createObjectURL(blob)
  const a = document.createElement('a')
  a.href = url
  a.download = `densidad_${params.election_name}_${params.granularity}_${params.threshold_pct}pct.xlsx`
  a.click()
  URL.revokeObjectURL(url)
}
