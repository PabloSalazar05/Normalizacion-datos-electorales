const BASE = '/api/data'

async function get<T>(url: string): Promise<T> {
  const res = await fetch(url)
  if (!res.ok) throw new Error(`${res.status} ${res.statusText}`)
  return res.json()
}

export interface ElectionMeta {
  election_name: string
  election_date?: string
}

export function fetchElections(): Promise<ElectionMeta[]> {
  return get<ElectionMeta[]>(`${BASE}/elections`)
}
