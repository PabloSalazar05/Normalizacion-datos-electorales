import type {
  LayerName,
  LayerStatus,
  LayersConfigResponse,
  ElectoralJoinRequest,
  ElectoralCollection,
} from '../types/layers'

const BASE = '/api/layers'

async function get<T>(url: string): Promise<T> {
  const res = await fetch(url)
  if (!res.ok) throw new Error(`${res.status} ${res.statusText} — ${url}`)
  return res.json()
}

async function post<T>(url: string, body: unknown): Promise<T> {
  const res = await fetch(url, {
    method: 'POST',
    headers: { 'Content-Type': 'application/json' },
    body: JSON.stringify(body),
  })
  if (!res.ok) throw new Error(`${res.status} ${res.statusText} — ${url}`)
  return res.json()
}

export function fetchLayerStatus(): Promise<LayerStatus> {
  return get<LayerStatus>(`${BASE}/status`)
}

export function fetchLayerConfig(): Promise<LayersConfigResponse> {
  return get<LayersConfigResponse>(`${BASE}/config`)
}

export function fetchLayer(
  layerName: LayerName,
  entidadId?: number,
): Promise<GeoJSON.FeatureCollection> {
  const params = entidadId != null ? `?entidad_id=${entidadId}` : ''
  return get<GeoJSON.FeatureCollection>(`${BASE}/${layerName}${params}`)
}

export function fetchLayerLabels(
  layerName: LayerName,
  entidadId?: number,
): Promise<GeoJSON.FeatureCollection> {
  const params = entidadId != null ? `?entidad_id=${entidadId}` : ''
  return get<GeoJSON.FeatureCollection>(`${BASE}/${layerName}/labels${params}`)
}

/**
 * Fetch pre-computed party PCT aggregations for a layer + election combination.
 * Returns a flat dict: { featureKey → { PARTY_PCT: number } }
 * where featureKey = "ENTIDAD_MUNICIPIO" (or "ENTIDAD_SECCION", etc.)
 * Results are memoised server-side — repeat calls are instant.
 */
export function fetchPrecomputedElectoral(
  layerName: LayerName,
  electionName: string,
  entidadId?: number,
): Promise<Record<string, Record<string, number | null>>> {
  const params = new URLSearchParams({ election_name: electionName })
  if (entidadId != null) params.set('entidad_id', String(entidadId))
  return get<{ data: Record<string, Record<string, number | null>> }>(
    `${BASE}/${layerName}/precomputed?${params}`,
  ).then((r) => r.data ?? {})
}

export function fetchElectoralJoin(
  layerName: LayerName,
  request: ElectoralJoinRequest,
): Promise<ElectoralCollection> {
  return post<ElectoralCollection>(`${BASE}/${layerName}/electoral-join`, request)
}
