/**
 * API client for /api/working-layers endpoints.
 */

export type WorkingLayerType = 'moran' | 'lisa' | 'density' | 'combined' | 'intersection'

export interface WorkingLayerMeta {
  id: string
  name: string
  type: WorkingLayerType
  election_name: string
  variable: string
  entidad_id: number | null
  entidad_name: string | null
  granularity: string
  created_at: string
  feature_count: number
  metadata: Record<string, unknown>
}

// ── Param shapes passed to POST /api/working-layers ──────────────────────────

export interface MoranLayerParams {
  election_name:  string
  variable:       string
  entidad_id?:    number
  granularity:    string
  analysis_level: string
  moran_i:        number
  p_value:        number
  significant:    boolean
  z_score:        number
  n_observations: number
}

export interface LISALayerParams {
  election_name:    string
  variable:         string
  entidad_id:       number
  granularity:      string
  analysis_level:   string
  significance:     number
  // Pre-computed fields — avoid re-running the expensive LISA computation
  geojson_features?: unknown[]
  n_significant?:   number
  n_observations?:  number
  cluster_counts?:  Record<string, number>
}

export interface DensityLayerParams {
  election_name: string
  entidad_id:    number
  granularity:   string
  threshold_pct: number
  municipio_id?: number
}

// ── API functions ─────────────────────────────────────────────────────────────

async function _checkOk(res: Response): Promise<void> {
  if (!res.ok) {
    const err = await res.json().catch(() => ({}))
    throw new Error((err as { detail?: string }).detail ?? `Request failed: ${res.status}`)
  }
}

export async function listWorkingLayers(): Promise<WorkingLayerMeta[]> {
  const res = await fetch('/api/working-layers')
  await _checkOk(res)
  return res.json()
}

export async function getWorkingLayer(id: string): Promise<WorkingLayerMeta> {
  const res = await fetch(`/api/working-layers/${id}`)
  await _checkOk(res)
  return res.json()
}

export async function deleteWorkingLayer(id: string): Promise<void> {
  const res = await fetch(`/api/working-layers/${id}`, { method: 'DELETE' })
  await _checkOk(res)
}

export async function renameWorkingLayer(id: string, name: string): Promise<WorkingLayerMeta> {
  const res = await fetch(`/api/working-layers/${id}/rename`, {
    method: 'PATCH',
    headers: { 'Content-Type': 'application/json' },
    body: JSON.stringify({ name }),
  })
  await _checkOk(res)
  return res.json()
}

export async function fetchWorkingLayerGeoJSON(id: string): Promise<GeoJSON.FeatureCollection> {
  const res = await fetch(`/api/working-layers/${id}/geojson`)
  await _checkOk(res)
  return res.json()
}

export async function combineLayers(layerIds: string[], name?: string): Promise<WorkingLayerMeta> {
  const res = await fetch('/api/working-layers/combine', {
    method: 'POST',
    headers: { 'Content-Type': 'application/json' },
    body: JSON.stringify({ layer_ids: layerIds, name }),
  })
  await _checkOk(res)
  return res.json()
}

export async function downloadWorkingLayerExcel(id: string, filename: string): Promise<void> {
  const res = await fetch(`/api/working-layers/${id}/export`)
  await _checkOk(res)
  const blob = await res.blob()
  const url = URL.createObjectURL(blob)
  const a = document.createElement('a')
  a.href = url
  a.download = filename.endsWith('.xlsx') ? filename : `${filename}.xlsx`
  a.click()
  URL.revokeObjectURL(url)
}

export async function createMoranLayer(
  params: MoranLayerParams,
  name?: string,
): Promise<WorkingLayerMeta> {
  const res = await fetch('/api/working-layers', {
    method: 'POST',
    headers: { 'Content-Type': 'application/json' },
    body: JSON.stringify({ type: 'moran', name, params }),
  })
  await _checkOk(res)
  return res.json()
}

export async function createLISALayer(
  params: LISALayerParams,
  name?: string,
): Promise<WorkingLayerMeta> {
  const res = await fetch('/api/working-layers', {
    method: 'POST',
    headers: { 'Content-Type': 'application/json' },
    body: JSON.stringify({ type: 'lisa', name, params }),
  })
  await _checkOk(res)
  return res.json()
}

export async function createDensityLayer(
  params: DensityLayerParams,
  name?: string,
): Promise<WorkingLayerMeta> {
  const res = await fetch('/api/working-layers', {
    method: 'POST',
    headers: { 'Content-Type': 'application/json' },
    body: JSON.stringify({ type: 'density', name, params }),
  })
  await _checkOk(res)
  return res.json()
}

export async function createIntersectionLayer(
  layerIds: string[],
  name?: string,
): Promise<WorkingLayerMeta> {
  const res = await fetch('/api/working-layers', {
    method: 'POST',
    headers: { 'Content-Type': 'application/json' },
    body: JSON.stringify({ type: 'intersection', name, params: { layer_ids: layerIds } }),
  })
  await _checkOk(res)
  return res.json()
}
