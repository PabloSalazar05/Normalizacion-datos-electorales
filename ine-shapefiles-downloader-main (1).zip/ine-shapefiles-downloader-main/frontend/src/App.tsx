import { useLayerStatus } from './hooks/useLayerStatus'
import { LayerLoadingScreen } from './components/Loading/LayerLoadingScreen'
import { MapView } from './components/Map/MapView'
import { LeftSidebar } from './components/Sidebar/LeftSidebar'
import { RightPanel } from './components/Controls/RightPanel'
import { ViewTabs } from './components/Controls/ViewTabs'
import { MoransPanel } from './components/Analysis/MoransPanel'
import { LISAPanel } from './components/Analysis/LISAPanel'
import { DensityPanel } from './components/Analysis/DensityPanel'
import { WorkingLayerManager } from './components/WorkingLayers/WorkingLayerManager'
import { useMapStore } from './store/mapStore'
import './App.css'

export default function App() {
  const { ready, progress } = useLayerStatus()
  const activeView = useMapStore((s) => s.activeView)

  if (!ready) {
    return <LayerLoadingScreen progress={progress} />
  }

  return (
    <div className="app-layout">
      <LeftSidebar />

      <div className="app-content">
        <ViewTabs />
        <main className="app-main">
          {activeView === 'map'     && <MapView />}
          {activeView === 'morans'  && <MoransPanel />}
          {activeView === 'lisa'    && <LISAPanel />}
          {activeView === 'density' && <DensityPanel />}
          {activeView === 'layers'  && <WorkingLayerManager />}
        </main>
      </div>

      {activeView === 'map' && <RightPanel />}
    </div>
  )
}
