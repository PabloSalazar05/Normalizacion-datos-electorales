import { useState, useEffect, useRef } from 'react'
import { fetchElectoralJoin } from '../api/layersApi'
import type { ElectoralCollection, LayerName } from '../types/layers'

/**
 * Fetches electoral join data for the active layer and election.
 * Re-fetches whenever electionName or layerName changes.
 */
export function useElectoralLayer(
  layerName: LayerName,
  electionName: string,
  entidadIds?: number[],
  enabled = true,
): {
  data: ElectoralCollection | null
  loading: boolean
  error: string | null
} {
  const [data, setData] = useState<ElectoralCollection | null>(null)
  const [loading, setLoading] = useState(false)
  const [error, setError] = useState<string | null>(null)
  const abortRef = useRef<AbortController | null>(null)

  useEffect(() => {
    if (!electionName || !enabled) return

    // Cancel previous in-flight request
    abortRef.current?.abort()
    const ctrl = new AbortController()
    abortRef.current = ctrl

    setLoading(true)
    setError(null)

    fetchElectoralJoin(layerName, { election_name: electionName, entidad_ids: entidadIds })
      .then((result) => {
        if (!ctrl.signal.aborted) {
          setData(result)
        }
      })
      .catch((err) => {
        if (!ctrl.signal.aborted) {
          setError(err.message ?? 'Unknown error')
        }
      })
      .finally(() => {
        if (!ctrl.signal.aborted) setLoading(false)
      })

    return () => ctrl.abort()
  }, [layerName, electionName, JSON.stringify(entidadIds), enabled])

  return { data, loading, error }
}
