import { useEffect, useRef } from 'react'
import { fetchLayerStatus } from '../api/layersApi'
import { useMapStore } from '../store/mapStore'
import type { LayerStatus } from '../types/layers'

const POLL_INTERVAL_MS = 2000

/**
 * Polls GET /api/layers/status every 2 seconds until ready=true.
 * Updates the global Zustand store once layers are available.
 */
export function useLayerStatus(): { ready: boolean; progress: LayerStatus['progress'] } {
  const layersReady = useMapStore((s) => s.layersReady)
  const setLayersReady = useMapStore((s) => s.setLayersReady)
  const progressRef = useRef<LayerStatus['progress']>({ processed: 0, total: 0 })

  useEffect(() => {
    if (layersReady) return

    let intervalId: ReturnType<typeof setInterval>

    const poll = async () => {
      try {
        const status = await fetchLayerStatus()
        progressRef.current = status.progress
        if (status.ready) {
          clearInterval(intervalId)
          setLayersReady(true)
        }
      } catch {
        // Server may not be ready yet; keep polling silently
      }
    }

    poll()
    intervalId = setInterval(poll, POLL_INTERVAL_MS)
    return () => clearInterval(intervalId)
  }, [layersReady, setLayersReady])

  return { ready: layersReady, progress: progressRef.current }
}
