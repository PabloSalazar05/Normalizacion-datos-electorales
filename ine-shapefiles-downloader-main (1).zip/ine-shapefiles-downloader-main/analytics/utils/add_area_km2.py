"""
Add Area (km²) Preprocessing
==============================

Reads all SECCION.shp shapefiles, computes section area in km²,
and writes one Parquet per state to data/processed/area_km2/.

Run from the project root:
    uv run python analytics/utils/add_area_km2.py
"""

from pathlib import Path
import geopandas as gpd

PROJECT_ROOT = Path(__file__).parents[2]
SHAPEFILE_BASE = PROJECT_ROOT / "data" / "geo" / "shapefiles_peepjf"
OUTPUT_DIR = PROJECT_ROOT / "data" / "processed" / "area_km2"


def main():
    OUTPUT_DIR.mkdir(parents=True, exist_ok=True)

    shp_files = sorted(SHAPEFILE_BASE.rglob("SECCION.shp"))
    if not shp_files:
        raise FileNotFoundError(f"No SECCION.shp files found under {SHAPEFILE_BASE}")

    print(f"Found {len(shp_files)} SECCION shapefiles")

    for shp_path in shp_files:
        # Derive entidad_id from the folder name (e.g. "10_Durango" → 10).
        # The ENTIDAD column in the shapefile data is unreliable (many files have
        # ENTIDAD=2 regardless of the actual state), so we trust the folder name.
        folder_name = shp_path.parent.parent.name  # e.g. "10_Durango"
        try:
            entidad_id = int(folder_name.split("_")[0])
        except (ValueError, IndexError):
            print(f"  SKIP {shp_path} — cannot parse entidad_id from folder '{folder_name}'")
            continue

        gdf = gpd.read_file(shp_path)

        if "SECCION" not in gdf.columns:
            print(f"  SKIP {shp_path} — no SECCION column")
            continue

        # Override ENTIDAD with the folder-derived value (shapefile data is unreliable)
        gdf["ENTIDAD"] = entidad_id

        # Reproject to UTM for accurate area measurement
        gdf_utm = gdf.to_crs(gdf.estimate_utm_crs())
        gdf_utm["area_km2"] = gdf_utm.geometry.area / 1_000_000

        out_df = gdf_utm[["ENTIDAD", "SECCION", "area_km2"]].copy()
        out_path = OUTPUT_DIR / f"{entidad_id:02d}_seccion_area.parquet"
        out_df.to_parquet(out_path, index=False)
        print(f"  [{entidad_id:02d}] {len(out_df)} sections → {out_path.name}")

    written = len(list(OUTPUT_DIR.glob("*.parquet")))
    print(f"\nDone. {written} Parquet files written to {OUTPUT_DIR}")


if __name__ == "__main__":
    main()
