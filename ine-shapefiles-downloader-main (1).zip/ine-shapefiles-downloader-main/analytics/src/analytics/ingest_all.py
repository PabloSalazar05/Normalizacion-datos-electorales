"""
ingest_all.py — Batch electoral data ingestion pipeline
========================================================

Processes all known electoral CSV files into the SQLite database in one shot.
Run this once after cloning the repo (with CSVs already in data/raw/electoral/).

Usage:
    uv run python -m analytics.ingest_all [--dry-run] [--skip-existing]

Options:
    --dry-run       Print what would be processed without writing to the DB.
    --skip-existing Skip elections that already have at least one table in the DB.
    --election NAME Process only the specified election name (can be repeated).

Examples:
    # Process everything
    uv run python -m analytics.ingest_all

    # Preview without writing
    uv run python -m analytics.ingest_all --dry-run

    # Skip elections already in the DB (safe to re-run after partial failure)
    uv run python -m analytics.ingest_all --skip-existing

    # Process only 2024 elections
    uv run python -m analytics.ingest_all --election PRES_2024 --election DIP_FED_2024
"""

from __future__ import annotations

import argparse
import sqlite3
import sys
import time
from dataclasses import dataclass
from pathlib import Path

import pandas as pd

# ── Project root (repo root, two levels above this file) ─────────────────────
_HERE = Path(__file__).resolve().parent          # analytics/src/analytics/
_REPO = _HERE.parents[2]                          # repo root (ine-shapefiles-downloader/)
_DATA = _REPO / "data"
_DB   = _DATA / "processed" / "electoral_data.db"


# ── Election registry ─────────────────────────────────────────────────────────
@dataclass
class Election:
    name: str        # election_name passed to orchestrator (e.g. "PRES_2024")
    csv:  Path       # relative path from repo root


ELECTIONS: list[Election] = [
    # ── 2024 ──────────────────────────────────────────────────────────────────
    Election(
        name="PRES_2024",
        csv=_DATA / "raw/electoral/2024/20240603_2005_PREP_PRES/PRES_2024.csv",
    ),
    Election(
        name="DIP_FED_2024",
        csv=_DATA / "raw/electoral/2024/20240603_2005_PREP_DIP_FED/DIP_FED_2024.csv",
    ),
    Election(
        name="SEN_2024",
        csv=_DATA / "raw/electoral/2024/20240603_2005_PREP_SEN/SEN_2024.csv",
    ),
    # ── 2021 ──────────────────────────────────────────────────────────────────
    Election(
        name="DIP_FED_2021",
        csv=_DATA / "raw/electoral/2021/20210611_1000_CW_diputaciones/diputaciones.csv",
    ),
    # ── 2018 ──────────────────────────────────────────────────────────────────
    Election(
        name="PRES_2018",
        csv=_DATA / "raw/electoral/2018/20180708_2130_CW_presidencia/presidencia.csv",
    ),
    Election(
        name="DIP_FED_2018",
        csv=_DATA / "raw/electoral/2018/20180708_2130_CW_diputaciones/diputaciones.csv",
    ),
    Election(
        name="SEN_2018",
        csv=_DATA / "raw/electoral/2018/20180708_2130_CW_senadurias/senadurias.csv",
    ),
]


# ── Helpers ───────────────────────────────────────────────────────────────────

def _elections_in_db() -> set[str]:
    """Return election names that already have at least one table in the DB."""
    if not _DB.exists():
        return set()
    with sqlite3.connect(_DB) as conn:
        rows = conn.execute(
            "SELECT name FROM sqlite_master WHERE type='table' AND name LIKE 'election_%'"
        ).fetchall()
    names: set[str] = set()
    for (tbl,) in rows:
        # table format: election_{name}_{entidad:02d}
        parts = tbl.split("_")
        if len(parts) >= 3:
            # reconstruct election name: skip first token ("election") and last ("NN")
            names.add("_".join(parts[1:-1]).upper())
    return names


def _build_national_table(election: Election) -> None:
    """
    Concatenate all per-entidad tables for an election into a single national
    table (election_{name}_all) and export a CSV to data/processed/electoral/.
    Skips entidades whose table is missing without failing.
    """
    frames = []
    with sqlite3.connect(_DB) as conn:
        for entidad_id in range(1, 33):
            tbl = f"election_{election.name.lower()}_{entidad_id:02d}"
            exists = conn.execute(
                "SELECT 1 FROM sqlite_master WHERE type='table' AND name=?", (tbl,)
            ).fetchone()
            if not exists:
                continue
            df = pd.read_sql_query(f"SELECT * FROM {tbl}", conn)
            frames.append(df)

    if not frames:
        print(f"  ⚠  No entidad tables found for {election.name}, skipping national build.")
        return

    df_all = pd.concat(frames, ignore_index=True)

    national_table = f"election_{election.name.lower()}_all"
    with sqlite3.connect(_DB) as conn:
        df_all.to_sql(national_table, conn, if_exists="replace", index=False)

    csv_dir = _DATA / "processed" / "electoral"
    csv_dir.mkdir(parents=True, exist_ok=True)
    csv_path = csv_dir / f"{election.name.lower()}_all.csv"
    df_all.to_csv(csv_path, index=False, encoding="utf-8")

    print(f"  ✓ National table → {national_table} ({len(df_all):,} rows)")
    print(f"  ✓ CSV            → {csv_path.relative_to(_REPO)}")


def _run_election(election: Election) -> bool:
    """
    Call the orchestrator for one election.  Returns True on success.
    The orchestrator is imported directly to avoid subprocess overhead and to
    reuse the same Python environment.
    """
    from analytics.clean_votes.orchestrator import CleanVotesOrchestrator

    print(f"\n{'─'*60}")
    print(f"  Processing: {election.name}")
    print(f"  CSV:        {election.csv.relative_to(_REPO)}")
    print(f"{'─'*60}")

    t0 = time.perf_counter()
    try:
        orch = CleanVotesOrchestrator()
        orch.process_electoral_file(
            file_path=str(election.csv),
            election_name=election.name,
            save_to_db=True,
        )
        elapsed = time.perf_counter() - t0
        print(f"  ✓ Done in {elapsed:.1f}s")
        return True
    except Exception as exc:
        elapsed = time.perf_counter() - t0
        print(f"  ✗ FAILED after {elapsed:.1f}s: {exc}", file=sys.stderr)
        return False


# ── Main ──────────────────────────────────────────────────────────────────────

def main() -> None:
    parser = argparse.ArgumentParser(description="Ingest all electoral CSVs into SQLite.")
    parser.add_argument("--dry-run",       action="store_true",
                        help="Print what would run without writing to the DB.")
    parser.add_argument("--skip-existing", action="store_true",
                        help="Skip elections already present in the DB.")
    parser.add_argument("--election",      action="append", dest="only",
                        metavar="NAME",
                        help="Process only this election name (repeatable).")
    args = parser.parse_args()

    # Filter by --election if provided
    elections = ELECTIONS
    if args.only:
        only = {n.upper() for n in args.only}
        elections = [e for e in elections if e.name.upper() in only]
        if not elections:
            print(f"No elections matched: {args.only}", file=sys.stderr)
            sys.exit(1)

    # Warn about missing CSVs before starting
    missing_csv = [e for e in elections if not e.csv.exists()]
    if missing_csv:
        print("\nWarning — CSV files not found (will be skipped):")
        for e in missing_csv:
            print(f"  {e.name}: {e.csv.relative_to(_REPO)}")

    # Skip existing
    already_done: set[str] = set()
    if args.skip_existing:
        already_done = _elections_in_db()
        if already_done:
            print(f"\nAlready in DB (--skip-existing): {', '.join(sorted(already_done))}")

    # Determine what to run
    to_run = [
        e for e in elections
        if e.csv.exists() and e.name not in already_done
    ]

    if not to_run:
        print("\nNothing to process.")
        return

    print(f"\n{'='*60}")
    print(f"  Elections to process: {len(to_run)}")
    for e in to_run:
        print(f"    • {e.name}")
    print(f"{'='*60}")

    if args.dry_run:
        print("\n[dry-run] No data written.")
        return

    # Run each election
    t_total = time.perf_counter()
    succeeded, failed = [], []

    for election in to_run:
        ok = _run_election(election)
        (succeeded if ok else failed).append(election.name)
        if ok:
            _build_national_table(election)

    # Summary
    elapsed_total = time.perf_counter() - t_total
    print(f"\n{'='*60}")
    print(f"  Finished in {elapsed_total:.1f}s")
    print(f"  Succeeded: {len(succeeded)}  —  {', '.join(succeeded) or '—'}")
    if failed:
        print(f"  Failed:    {len(failed)}  —  {', '.join(failed)}", file=sys.stderr)
    print(f"{'='*60}\n")

    if failed:
        sys.exit(1)


if __name__ == "__main__":
    main()
